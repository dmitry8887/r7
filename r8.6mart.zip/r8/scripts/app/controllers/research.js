﻿"use strict";

r8.controllers.Research = class extends simple.Controller {
  get properties() {
    return { route: "App$Research", hash: "research", view: ()=> "Research", name: "Research" };
  }

	constructor({ resolver }) {
		super({
			resolver,
			getContainer: ({ created, stateContainer }) => {
				if (created !== true) {
					stateContainer.querySelector("#app_view_container").innerHTML =
						"Research";  //simple.Utils.getHtmlImportText({ name: "Labs" });
				}
				return stateContainer.querySelector("#app_view_container");
			},
			elements: {},
			states: []
		});
	}

  enter() {
	  if (!this.initialized) {
		  this.init();
	  }
  }

  leave() {
  }
}