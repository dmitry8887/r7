$.List = class {
    static init({ element }) {
        //debugger;
    }

    static get({ element }) {
        
        //debugger;
    }

    static set({ element, value, initial }) {
        if (initial){
            // debugger;
        }
        else{
            debugger;
        }
    }

    static export({ mode }) {
        if (mode == "Binding") {
            const { get, set } = $.List;
            return { get, set };
        }
        else {
            throw "Not Implemented";
        }
    }
}