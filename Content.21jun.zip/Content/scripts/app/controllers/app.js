﻿"use strict";

r8.controllers = {};

// TODO: app menu z-index should be greather than apps's one
const AppController = class extends simple.Controller {
  constructor({ context }) {
    super({
      name: "App",
      elements: {
        AppOverlay: { id: "app_overlay" },
        AppOverlayText: { id: "app_overlay_text" },
        AppMenu: {
          id: "app_menu",
          init: ({ container }) => simple.List.init({
            container,
            template: ({ item }) => simple.Dom.evalTemplate({ name: "App.MenuItem", context: item }),
            items: r8.metadata.menuItems()
          })
        },
        AppMenuOverlay: { id: "app_menu_overlay" },
        AppAppsOverlay: { id: "app_apps_overlay" },
        AppUserActivities: { id: "app_user_activities" },
        AppUserActivitiesOverlay: { id: "app_user_activities_overlay" },
        UserName: { id: "user_name" },
        AppMenuUserName: { id: "app_menu_user_name" },
        AppAuthenticateOverlay: {
          id: "app_authenticate_overlay",
          init: ({ container }) => {
            simple.Authentication.init({
              container,
              handle: ({ name, value, cancel }) => {
                if (cancel) {
                  return simple.Application.cancel();
                }

                return this.run({
                  handle: () => {
                    return new Promise((resolve) => {
                      const action = {
                        Login: r8.services.authentication.login,
                        Register: r8.services.authentication.register,
                        Restore: r8.services.authentication.restore
                      }[name];
                      action(value).then(resolve);
                    });
                  },
                  options: { text: "Authenticating..." }
                });
              }
            });
          }
        },
        AppMenuLogin: { id: "app_menu_login" },
        AppMenuLogout: { id: "app_menu_logout" },
        UserLogout: { id: "user_logout" },
        AppGuest: { id: "app_guest" },
        AppUser: { id: "app_user" },
        AppMenuLauncher: { id: "app_menu_launcher" },
        AppViewHeader: { id: "app_view_header" },
        AppAppsBack: { id: "app_apps_back" },
        AppAppsLauncher: { id: "app_apps_launcher" },
        AppMenuBack: { id: "app_menu_back" },
        AppTheme: {
          id: "app_theme",
          init: ({ container }) => {
            const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;
            const { theme } = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

            simple.RadioList.init({
              container,
              items: r8.metadata.themes(),
              selectedId: theme,
              on: ({ id }) => {
                simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });

                setTheme({ theme: id });

                simple.Application.apply();
              }
            });

            simple.RadioList.setSelectedId({ container, id: theme });
          }
        }
      },
      states: {
        User: {
          enter: () => {
            const { userName } = r8.services.app.getUser();
            ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name }).innerHTML = userName);
          },
          leave: () => ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name }).innerHTML = "Guest")
        },
        Overlay: {
          reEntryAction: "Allow",
          enter: ({ value }) => {
            const { text } = value;
            this.getElement({ name: "AppOverlayText" }).innerHTML = text;
          }
        },
        UserActivities: { reEntryAction: "Ignore" },
        Apps: { reEntryAction: "Ignore" }
      },
      commands: {
        Authenticate: {
          handle: ({ allowGuestLogin }) => this.authenticate({ allowGuestLogin }).then(() => simple.Application.apply())
        },
        Logout: {
          handle: () => {
            r8.services.app.removeUser();
            this.execute({ batch: { descriptors: ["User$Leave"] } });
          }
        }
      },
      context,
      root: true,
      routes: [
        { hash: "#me", handle: () => this.getUserAcitivities() }
      ]
    });
  }

  getUserAcitivities() {
    this.execute({ batch: { descriptors: ["UserActivities$Enter"] } });

    return r8.services.user.acitivities().then(result => {
      return Promise.resolve();
    });
  }

  create({ app }) {
    return { container: app };
  }

  destroy() {
    throw "Not Implemented";
  }

  run({ handle, options }) {
    return new Promise((resolve) => {
      this.busy({ options });

      handle().then(result => {
        this.free();
        resolve(result);
      });
    });
  }

  init() {
    super.init();

    this.execute({ batch: { descriptors: [r8.services.app.authenticated() ? "User$Enter" : "User$Leave"], transient: true } });
  }

  authenticate({ allowGuestLogin }) {
    // pass authenticated as a parameters when do Auth.init and check that internally(?)
    if (r8.services.app.authenticated()) {
      return Promise.resolve();
    }

    this.execute({ batch: { descriptors: ["Authenticate$Enter"] } });

    return simple.Authentication.authenticate({
      container: this.getElement({ name: "AppAuthenticateOverlay" }),
      appState: this.context.appState,
      allowGuestLogin
    }).then(result => {
      if (result) {
        // wasn't a guest login
        const { userName, token } = result;
        r8.services.app.setUser({ user: { userName, token } });

        this.execute({ batch: { descriptors: ["User$Enter"], transient: true } });
      }

      simple.Application.apply();
    });
  }

  busy({ options }) {
    this.execute({ batch: { states: [{ descriptor: "Overlay$Enter", value: options }], transient: true } });
  }

  free() {
    this.execute({ batch: { descriptors: ["Overlay$Leave"], transient: true } });
  }

  export() {
    return { run: this.run.bind(this), authenticate: this.authenticate.bind(this) };
  }
};