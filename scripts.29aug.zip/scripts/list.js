$.List = class {
    static get({ element }) {
        debugger;
    }

    static set({ element, value, initial }) {
        debugger;
        
        // debugger;
        // const data = [{ Name: "1" }, { Name: "2" }];
    }

    static update({ item }) {

    }

    static export({ mode }) {
        if (mode == "Binding") {
            const { get, set } = $.List;
            return { get, set };
        }
        else {
            throw "Not Implemented";
        }
    }
}