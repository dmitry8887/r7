﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Http;
using r8.Models;
using r8.Services;

namespace r8.Controllers
{
  public class RegisterController : ApiController
  {
    private static readonly string ConnectionString =
      ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    [HttpPost]
    public RegistrationResult Register(Registration registration)
    {
      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        if (UserServices.UserExists(registration, connection))
        {
          return new RegistrationResult()
          {
            Success = false,
            Errors = new List<string>() { "User Name or Email are already in use." }
          };
        }

        registration.Ip = Utils.GetCallerIp();
        registration.CreatedDate = DateTime.UtcNow;

        int appUserId = UserServices.CreateAppUser(registration, connection);

        var session = UserServices.CreateAppUserSession(appUserId, connection);

        connection.Close();

        return new RegistrationResult()
        {
          Success = true,
          UserName = registration.UserName,
          Token = session.Token
        };
      }
    }
  }
}