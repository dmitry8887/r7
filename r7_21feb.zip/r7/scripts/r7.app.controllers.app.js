﻿r7.app.controllers.app = new function () {
    this.route = "app";

    var init = function () {
        r7.lib.menu.init({
            launcher: $("#menu_launcher"),
            container: $("#app_overlay")
        });
    };

    this.enter = function (context) {
        var from = this.from;

        return new window.Promise(function (resolve, reject) {
            try {
                if (!this.from) {
                    init();
                }

                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function (context) {
        var to = this.to;

        return new window.Promise(function (resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
};