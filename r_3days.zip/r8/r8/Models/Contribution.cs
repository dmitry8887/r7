﻿using System;
using System.Web.Security.AntiXss;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace r8.Models
{
    public class Contribution
    {
        [JsonProperty(PropertyName = "id")]
        public int Id
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "typeId")]
        public int TypeId
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "type")]
        public string Type
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "names")]
        public string Names
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "from")]
        public int From
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "to")]
        public int To
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "tags")]
        public string Tags { get; set; }

        [JsonProperty(PropertyName = "riskEstimate")]
        public string RiskEstimate
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "direction")]
        public string Direction
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "directionId")]
        public int? DirectionId
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "stopLoss")]
        public decimal? StopLoss { get; set; }

        [JsonProperty(PropertyName = "open")]
        public decimal? Open { get; set; }

        [JsonProperty(PropertyName = "takeProfit")]
        public decimal? TakeProfit { get; set; }

        [JsonProperty(PropertyName = "volume")]
        public decimal? Volume { get; set; }

        [JsonProperty(PropertyName = "volumeEstimate")]
        public string VolumeEstimate { get; set; }

        [JsonProperty(PropertyName = "leverage")]
        public decimal? Leverage { get; set; }

        [JsonProperty(PropertyName = "leverageEstimate")]
        public string LeverageEstimate { get; set; }

        [JsonProperty(PropertyName = "close")]
        public decimal? Close
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "closeDate")]
        public DateTime CloseDate
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "closeMode")]
        public string CloseMode
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "closeModeId")]
        public int? CloseModeId
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "comment")]
        public string Comment
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "createdDate")]
        public DateTime? CreatedDate
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "createdDateMinutes")]
        public int CreatedDateMinutes
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "userId")]
        public int? UserId
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "userName")]
        public string UserName
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "ip")]
        public string Ip
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "postCount")]
        public int PostCount
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "likeCount")]
        public int LikeCount
        {
            get;
            set;
        }

        [JsonProperty(PropertyName = "discussion")]
        public List<Post> Discussion
        {
            get;
            set;
        }

        public Contribution Sanitize()
        {
            Names = AntiXssEncoder.HtmlEncode(Names, false);
            Tags = AntiXssEncoder.HtmlEncode(Tags, false);
            Comment = AntiXssEncoder.HtmlEncode(Comment, false);
            Direction = AntiXssEncoder.HtmlEncode(Direction, false);
            RiskEstimate = AntiXssEncoder.HtmlEncode(RiskEstimate, false);
            VolumeEstimate = AntiXssEncoder.HtmlEncode(VolumeEstimate, false);
            LeverageEstimate = AntiXssEncoder.HtmlEncode(LeverageEstimate, false);
            CloseMode = AntiXssEncoder.HtmlEncode(CloseMode, false);
            UserName = AntiXssEncoder.HtmlEncode(UserName, false);
            Ip = AntiXssEncoder.HtmlEncode(Ip, false);
            UserName = AntiXssEncoder.HtmlEncode(UserName, false);

            return this;
        }

        Contribution Map()
        {
            throw new NotImplementedException();
        }
    }
}