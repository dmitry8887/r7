﻿var fxrig = fxrig || {};
fxrig.apps = new function() {
    var appIdPrefix = "app_";

    var appVisible = function (visibleArgs) {
        var appNames = visibleArgs.appNames;
        var name = visibleArgs.name; // current

        var result = false;

        appNames = appNames.split("|");

        for (var i = 0; i < appNames.length; i++) {
            var appName = appNames[i];

            if (appName.substring(appName.length - 1, appName.length) === "*") {

                appName = appName.substring(0, appName.length - 1);

                if (name.indexOf(appName) === 0) {
                    result = true;
                    break;
                }
            }
            else {
                if (name === appName) {
                    result = true;
                    break;
                }
            }
        }

        return result;
    };

    var getDiff = function (getDiffArgs) {
        var apps = getDiffArgs.apps;
        var from = getDiffArgs.from;
        var to = getDiffArgs.to;
        
        var removeApps = [];
        if (from) {
            removeApps = _.filter(apps, function (app) {
                return appVisible({ appNames: app.names, name: from }) && !appVisible({ appNames: app.names, name: to });
            });
        }

        var addApps = _.filter(apps, function (app) {
            if (from) {
                return appVisible({ appNames: app.names, name: to }) && !appVisible({ appNames: app.names, name: from });
            }
            else {
                return appVisible({ appNames: app.names, name: to });
            }
        });

        return { remove: removeApps, add: _.sortBy(addApps, function (app) { return app.rank; }) };
    };

    var add = function (addArgs) {
        var $container = addArgs.container;
        var instanceId = addArgs.instanceId;
        var app = addArgs.app;
        
        var appHtml = app.cacheName ?
            fxrig.state.getCacheItem({ appName: "fxrig", name: app.cacheName }) :
            app.html;

        var html = "<div id='{0}'><div class='m-p5'>::{1}</div><div>{2}</div></div>".format(appIdPrefix + app.id, app.header, appHtml);
        
        var $level = $("#level{0}_apps".format(app.level), addArgs.container).prepend(html);
        var $app = $("#" + appIdPrefix + app.id, $level);
        
        if (app.script) {
            var script = app.script();

            // todo: decouple by adding appContainer to navigator and container to appContainer
            script.send = function (message) {
                return fxrig.router.send($("#app_container"), message);
            };

            var init = script.init.bind(_.assign(script, { container: $container, appId: app.id }));
            init();

            $container.state().receives = $container.state().receives || [];

            script.receive.appName = app.id;

            var receive = script.receive.bind({ container: $container, appId: app.id });
            $container.state().receives.push({ appId: app.id, receive: receive });
        }

        var state = $("#container", $app).state();
        state.instanceId = instanceId;
        
    }; // todo: should be register?

    var remove = function (removeArgs) {
        var $container = removeArgs.container;
        var state = $container.state();

        var app = removeArgs.app;
        var $app = $("#" + appIdPrefix + app.id, $container);
        
        _.remove(state.receives, { appId: app.id });

        $app.remove();
    };

    this.ensure = function (ensureArgs) {
        var $container = ensureArgs.container;
        $container.state({ send: ensureArgs.send, receive: ensureArgs.receive });

        var diff = getDiff({ apps: fxrig.services.cache.apps, from: ensureArgs.transition.from, to: ensureArgs.transition.to });
        
        var i;

        for (i = 0; i < diff.remove.length; i++) {
            remove({ container: $container, app: diff.remove[i] });
        }

        for (i = 0; i < diff.add.length; i++) {
            add({ container: $container, instanceId: ensureArgs.instanceId, app: diff.add[i] });
        }
    };

    this.send = function (container, message) {
        var receives = container.state().receives || [];
        for (var i = 0; i < receives.length; i++) {
            receives[i].receive(message);
        }
    };

    //this.init = function (initArgs) {
    //    initArgs.container.state({ interceptors: initArgs.interceptors });
    //};
};