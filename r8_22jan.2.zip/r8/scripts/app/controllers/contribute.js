﻿"use strict";

r8.controllers.Contribute = class extends simple.Stateful {
  get routing() {
    return { route: "App$Contribute", "default": true, hash: "contribute" };
  }

  constructor(resolver) {
    super({
      elements: {
        DateFrom: "date_from",
        DateTo: "date_to",
        Names: "names"
      },
      states: []
    });

    this._resolver = resolver;
  }

  get resolver() {
    return this._resolver;
  }

  get appContainer() {
    return this._appContainer();
  }

  enter() {
    const resolver = this.resolver;
    const appContainer = resolver.appContainer();
    appContainer.querySelector("#view").innerHTML = simple.Cache.getHtml({ name: "r8.views.contribute" });

    const container = resolver.container();

    if (this.initialized !== true) {
      this.init(this.resolver);

      const state = simple.Cache.getValue({
        name: "r8.state.contribute",
        defaultValue: {
          from: 24056640,
          to: 24145920,
          frame: 1440,
          names: ["GLTZUR*", "VNRODG", "DUSVJL"],
          tags: ["T1", "T3"]
        }
      });
        
      simple.Date.init({ container: this.getElement({ container, name: "DateFrom" }), value: state.from });
      simple.Date.init({ container: this.getElement({ container, name: "DateTo" }), value: state.to });
      simple.List.init({ container: this.getElement({ container, name: "Names" }), items: [1, 2, 3] });

      this.initialized = true;
    }

    //console.warn(transition);
  }

  leave() {
    //console.warn(transition);
  }

  static templates() {
    return [
      { name: "r8.views.contribute", url: "../html/app/views/contribute.html" }
    ];
  }
}