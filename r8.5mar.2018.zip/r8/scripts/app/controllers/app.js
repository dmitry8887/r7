﻿"use strict";

r8.controllers.App = class extends simple.Controller {
  get properties() {
    return { route: "App", name: "App" };
  }

  constructor({ resolver }) {
    super({
      resolver,
      getContainer: ({ stateContainer }) => stateContainer,
      elements:
      {
        AppOverlay: "app_overlay",
        //AppOverlayMessage: "app_overlay_message",
        //AppOverlayErrorMessage: "app_overlay_error_message",
        AppMenu: "app_menu",
        AppMenuOverlay: "app_menu_overlay",
        AppAppsOverlay: "app_apps_overlay",
        UserName: "user_name",
        AppMenuUserName: "app_menu_user_name",
        AppAuthenticateOverlay: "app_authenticate_overlay",
        AppMenuLogin: "app_menu_login",
        AppUser: "app_user",
        AppMenuLauncher: "app_menu_launcher",
        AppViewHeader: "app_view_header",
        AppAppsBack: "app_apps_back",
        AppAppsLauncher: "app_apps_launcher",
        AppMenuBack: "app_menu_back"
      },
      states: []
    });
  }

  enter(/*{ from, to }*/) {
    if (this.initialized !== true) {
      this.init();
      const stateContainer = this.getStateContainer();

      simple.List.init({
        container: this.getElement({ name: "AppMenu" }),
        stateContainer,
        template: (({ item }) => {
          return simple.Utils.interpolate({ name: "App.MenuItem", context: item });
        }),
        items: [
          { label: "Contribute", description: "Contribute Description" },
          { label: "Research", description: "Research Description" },
          { label: "Labs", description: "Labs Description" }
        ]
      });
      
      simple.Authentication.init({
        container: this.getElement({ name: "AppAuthenticateOverlay" }),
        stateContainer,
        on: ({ name, value }) => {
          switch (name) {
          case "Login":
            this.executeState({ batch: { descriptors: ["App$Overlay$Enter"] } });
            r8.services.app.authenticate({ user: value }).then(({ success }) => {
              this.executeState({ batch: { descriptors: ["App$Overlay$Leave"] } });
              if (success) {
                container.expandos.resolve({ continue: true }); // hack
              } else {
                alert("cannot login");
              }
            });

            break;
          }
        }
      });

      this.initialized = true;
    }
  }

  leave(/*{ from, to }*/) {
  }

  authenticate({ allowGuestLogin }) {
    this.executeState({ batch: { descriptors: ["App$Authenticate$Enter"] } });
    return simple.Authentication.authenticate({
      container: this.getElement({ name: "AppAuthenticateOverlay" }),
      stateContainer: this.getStateContainer(),
      allowGuestLogin
    }).then((result) => {
      this.executeState({ batch: { descriptors: ["App$Authenticate$Leave"] } });
      return result;
    });
  }

  busy() {
  }

  free() {
  }
}