$ = {};
$.Element = {};

$.Element.init = ({ element }) => {
    let expandos = element["expandos"];
    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element.expandos = Object.entries(element.dataset).reduce((previous, current) => {
        const [, value, parsedValue = JSON.parse(value)] = current;
        return Object.assign(previous, parsedValue);
    }, {});

    $.Element.getElements({ element }).forEach(element => {
        $.Element.init({ element });
    });
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.set = ({ element, data }) => {
    const { expandos } = element;

    const bindings = [];

    const path = Symbol("path");

    const buildPath = (first, second) => first ? [first, second].join(".") : second;

    const isObject = (value) => typeof value === "object";

    $.Element.getElements({ element }).forEach(element => {
        const { type, binding } = element.expandos;
        const component = $.Element.registry[type]();
        const { path } = binding;

        let pathBindings = binding[path];
        if (!pathBindings) {
            bindings[path] = [];
            pathBindings = bindings[path];
        }

        const id = element.id;
        const { get, set } = component.export({ mode: "Binding" });

        bindings[path].push({
            targetId: id,
            get: () => get({ element }),
            set: ({ value, initial }) => set({ element, value, initial })
        });
    });

    expandos.bindings = bindings;

    const boundTargets = [];

    const handler = ({ initial }) => ({
        get: (target, key) => {

            if (!initial
                && boundTargets.length > 0) {
                boundTargets.length = 0;
            }

            let value = target[key] || { [path]: buildPath(target[path], key) };

            if (isObject(value)) {
                return new Proxy(value, handler({ initial }));
            } else {
                return value;
            }
        },
        set: (target, key, value /*, receiver*/) => {
            target[key] = value;

            if (isObject(target)) {
                key = buildPath(target[path], key);
            }

            let binding = bindings[key];

            if (binding) {
                binding.forEach(({ set, targetId }) => {
                    boundTargets.push({ key, targetId });

                    console.error("+++Binding", { key, targetId, value });

                    set({ value, initial });

                    return true;
                });
            }
            else {
                // TODO: find the most derived one 
                const { key: parentBidningKey, value: parentBidning } = (Object.entries(bindings)
                    .map(([key, value]) => ({ key, value }))
                    .find(({ key: parentBindingKey }) => key.startsWith(parentBindingKey)) || {});


                if (parentBidning !== undefined) {
                    parentBidning.forEach(({ set, targetId }) => {

                        if (!boundTargets.some(boundTarget =>
                            boundTarget.key === parentBidningKey
                            && boundTarget.targetId === targetId)) {

                            console.error("+++ Binding (nested)", { key, targetId, value });
                            set({ value, initial });
                        }
                        else {
                            // console.error("Ignored Binding", { key, targetId, value });
                        }
                    });
                }
            }

            return true;
        }
    });

    const proxy = new Proxy({}, handler({ initial: true }));

    const getKvps = ({ object }) => {
        const kvps = [];

        const process = ({ object }) => {
            Object.entries(object).forEach(entry => {
                let [key, value] = entry;

                const isObjectValue = isObject(value);

                if (isObjectValue) {
                    value[path] = buildPath(object[path], key);

                    key = value[path];
                }
                else {
                    key = buildPath(object[path], key);
                }

                kvps.push({ key, value });

                if (isObjectValue) {
                    process({ object: value });
                }
            });
        };

        process({ object });

        return kvps;
    }

    getKvps({ object: data }).forEach(({ key, value }) => proxy[key] = value);

    return new Proxy(data, handler({ initial: false }));
};


// very good
$.Interactable = {};















































$.Element.registry = { "List": () => $.List };

