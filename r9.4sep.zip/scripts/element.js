$ = {};
$.Element = {};

$.Element.init = ({ element }) => {
    let expandos = element["expandos"];
    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element.expandos = Object.entries(element.dataset).reduce((previous, current) => {
        const [, value, parsedValue = JSON.parse(value)] = current;
        return Object.assign(previous, parsedValue);
    }, {});

    $.Element.getElements({ element }).forEach(element => {
        $.Element.init({ element });
    });
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

// TODO: more derived for the same session ignore
$.Element.set = ({ element, data }) => {
    const { expandos } = element;
    const bindings = [];

    const path = Symbol("path");
    const buildPath = (first, second) => first ? [first, second].join(".") : second;

    $.Element.getElements({ element }).forEach(element => {
        const { type, binding } = element.expandos;
        const component = $.Element.registry[type]();
        const { path } = binding;

        let pathBindings = binding[path];
        if (!pathBindings) {
            bindings[path] = [];
            pathBindings = bindings[path];
        }

        const id = element.id;
        const { get, set } = component.export({ mode: "Binding" });

        bindings[path].push({
            targetId: id,
            get: () => get({ element }),
            set: ({ value, initial }) => set({ element, value, initial })
        });
    });

    expandos.bindings = bindings;

    const handler = ({ initial }) => ({
        get: (target, key) => {

            // todo: experimental
            if (target[key] === undefined) {
                target[key] = {};
                target[key][path] = buildPath(target[path], key);
            }

            if (typeof target[key] === "object") {

                if (target[key] === undefined) {
                    debugger;
                }

                return new Proxy(target[key], handler({ initial }));
            } else {
                return target[key];
            }
        },
        set: (target, key, value, receiver) => {
            target[key] = value;

            if (typeof target === "object") {
                key = buildPath(target[path], key);
            }

            const pathBindings = bindings[key];

            if (pathBindings) {
                pathBindings.forEach(({ set }) => set({ value, initial }));
            }

            console.error(`setting '${key}' to '${JSON.stringify(value)}'`); //trap

            return true;
        }
    });

    const proxy = new Proxy({}, handler({ initial: true }));

    const getKvps = ({ object }) => {
        const kvps = [];

        const process = ({ object }) => {
            Object.entries(object).forEach(entry => {
                let [key, value] = entry;

                if (typeof value === "object") {
                    value[path] = buildPath(object[path], key);

                    key = value[path];
                }
                else {
                    key = buildPath(object[path], key);
                }

                kvps.push({ key, value });

                if (typeof value === "object") {
                    process({ object: value });
                }
            });
        };

        process({ object });

        return kvps;
    }

    getKvps({ object: data }).forEach(({ key, value }) => proxy[key] = value);

    return new Proxy(data, handler({ initial: false }));
};


// very good
$.Interactable = {};















































$.Element.registry = { "List": () => $.List };

