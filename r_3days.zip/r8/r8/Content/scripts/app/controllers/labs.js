﻿"use strict";

const LabsController = class extends simple.Controller {
  constructor({ resolver }) {
    super({
      name: "Labs",
      elements: {
        LabsDebug: { id: "labs_debug" }
      },
      routes: [
        { hash: "#labs", handle: () => this.debug() }
      ],
      resolver
    });
  }

  create({ element }) {
    const placeholderElement = simple.Element.getElement({ element, dataAttributeName: "data-element-slot" });
    const { content } = simple.Element.setInnerHtml({ element: placeholderElement, name: this.name });

    return content;
  }

  init() {
    debugger;
    super.init();

    this.getElement({ name: "LabsDebug" }).innerHTML = "Lab Debug";
  }
};