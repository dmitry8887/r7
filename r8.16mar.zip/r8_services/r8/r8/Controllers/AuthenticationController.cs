﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Web.Http;
using Dapper;
using r8.Models;

namespace r8.Controllers
{
  public class AuthenticationController : ApiController
  {
    private static readonly string ConnectionString =
      ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    [HttpPost]
    public LoginResult Login(Login login)
    {
      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        string sql = $@"SELECT Id as AppUserId, UserName 
            FROM dbo.[AppUser] with(nolock) 
            WHERE (upper(UserName) = upper('{login.UserNameOrEmail}') or upper(Email) = upper('{login.UserNameOrEmail}')) and Hash = '{login.Token}'";

        var queryResult = connection.Query<AppUser>(sql).FirstOrDefault() ?? new AppUser();
        var appUserId = queryResult.Id;
        var userName = queryResult.Name;

        var success = !string.IsNullOrEmpty(userName);
        AppUserSession session = new AppUserSession();

        if (success)
        {
          session = CreateAppUserSession(appUserId, connection);
        }

        LoginResult result = new LoginResult()
        {
          Success = success,
          UserName = userName,
          Token = session.Token,
          Errors = success ? null : new List<string>() { "Invalid Credentials" } // use codes
        };

        connection.Close();

        return result;
      }
    }

    [HttpPost]
    public RegistrationResult Register(Registration registration)
    {
      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        if (UserExists(registration, connection))
        {
          return new RegistrationResult()
          {
            Success = false,
            Errors = new List<string>() { "User Name or Email are already in use." }
          };
        }

        registration.Ip = Utils.GetCallerIp();
        registration.CreatedDate = DateTime.UtcNow;

        int appUserId = CreateAppUser(registration, connection);

        var session = CreateAppUserSession(appUserId, connection);

        connection.Close();

        return new RegistrationResult()
        {
          Success = true,
          UserName = registration.UserName,
          Token = session.Token
        };
      }
    }

    [HttpPost]
    public void Restore(string userNameOrLogin)
    {
      Debugger.Break();
    }

    private bool UserExists(Registration registration, SqlConnection connection)
    {
      // check is user name or email are in use
      string sql = $@"SELECT Id 
        FROM dbo.[AppUser] WITH(NOLOCK) 
        WHERE upper(UserName) = UPPER('{registration.UserName}') or UPPER(Email) = UPPER('{registration.Email}')";

      int appUserId = connection.Query<int>(sql).FirstOrDefault();
      return appUserId != 0;
    }

    private int CreateAppUser(Registration registration, SqlConnection connection)
    {
      return connection.Query<int>(Utils.GenerateInsertSql("dbo.[AppUser]", new[]
        {
          "UserName", "Email", "Hash", "Ip", "CreatedDate"
        }),
        registration).FirstOrDefault();
    }

    internal static bool TryGetAppUserId(string token, out int appUserId)
    {
      appUserId = 0;

      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        var sql = $"SELECT AppUserId FROM dbo.[AppUserSession] WITH(NOLOCK) WHERE Token = '{token}'";
        var queryResult = connection.Query<AppUser>(sql).FirstOrDefault();

        if (queryResult != null) appUserId = queryResult.Id;

        connection.Close();
      }

      return appUserId > 0;
    }

    private AppUserSession CreateAppUserSession(int appUserId, SqlConnection connection)
    {
      AppUserSession session = new AppUserSession()
      {
        AppUserId = appUserId,
        Token = Guid.NewGuid().ToString(),
        CreatedDate = DateTime.UtcNow,
        Ip = Utils.GetCallerIp(),
        Active = true
      };

      var deactiveSessionsSql = $"UPDATE dbo.[AppUserSession] SET Active = 0 WHERE AppUSerId = {appUserId}";
      connection.Execute(deactiveSessionsSql);

      connection.Query<int>(Utils.GenerateInsertSql("dbo.[AppUserSession]",
          new[]
          {
            "AppUserId", "Token", "Ip", "CreatedDate", "Active"
          }),
        session);

      return session;
    }
  }
}