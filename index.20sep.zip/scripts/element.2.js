$ = {
    Symbols: {
        expandos: Symbol("expandos")
    },
    isObject: (value) => typeof value === "object"
};

$.Element = {};
$.Element.init = ({ element }) => {
    const expandos = element[$.Symbols.expandos];
    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element.expandos = Object.entries(element.dataset).reduce((previous, current) => Object.assign(previous, JSON.parse(current[1])), {});

    $.Element.getElements({ element }).forEach(element => $.Element.init({ element }));
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.set = ({ element, data }) => {
    const bindings = [];

    const [path, parent] = ["path", "parent"].map(description => Symbol(description));



    const isObject = (value) => typeof value === "object";

    $.Element.getElements({ element }).forEach(element => {
        const { type, binding } = element.expandos;
        const component = $.Element.registry[type]();
        const { path } = binding;

        let pathBindings = binding[path];
        if (!pathBindings) {
            bindings[path] = [];
            pathBindings = bindings[path];
        }

        const id = element.id;
        const { get, set } = component.export({ mode: "Binding" });

        bindings[path].push({
            targetId: id,
            get: () => get({ element }),
            set: ({ value }) => set({ element, value })
        });
    });

    const boundTargets = [];

    const handler = ({ scope }) => ({
        get: (target, key) => {
            if (target[path] === undefined) {
                boundTargets.length = 0;
            }

            let value = target[key];

            if (!value) {
                value = {
                    [path]: buildPath(target[path], key),
                    [parent]: () => target
                };

                //
                target[key] = value;
            }

            if (isObject(value)) {
                if (bindings[target[path]]) {
                    scope = target;
                }

                return new Proxy(value, handler({ scope }));
            } else {
                return value;
            }
        },
        set: (target, key, value) => {
            const origianalKey = key;

            target[key] = value;

            if (isObject(target)) {
                key = buildPath(target[path], key);
            }

            let binding = bindings[key];

            if (binding) {
                binding.forEach(({ set, targetId }) => {
                    boundTargets.push({ key, targetId });

                    console.error("Nested Binding", { key, targetId, value });

                    set({ value });

                    return true;
                });
            }
            else {

                // downgrades
                // todo: handled paths can be kept right here in this branch

                // TODO: find the most derived one 
                const { key: parentBindingKey, value: parentBidning } = (Object.entries(bindings)
                    .map(([key, value]) => ({ key, value }))
                    .find(({ key: parentBindingKey }) => key.startsWith(parentBindingKey)) || {});

                if (parentBidning !== undefined) {
                    parentBidning.forEach(({ set, targetId }) => {

                        if (!boundTargets.some(boundTarget =>
                            boundTarget.key === parentBindingKey
                            && boundTarget.targetId === targetId)) {

                            console.error("+++ Binding (nested)", { key, targetId, value });

                            target = Object.assign(target, { [origianalKey]: value });

                            //debugger;
                            /*while (target[path] !== parentBindingKey) {
                                //debugger;
                                target = target[parent]();
                            }*/

                            //set({ value: target, scope });
                            set({ value: scope });
                        }
                        //else {
                        //console.error("Ignored Binding", { key, targetId, value });
                        //}
                    });
                }
            }

            return true;
        }
    });

    const getKvps = ({ object }) => {
        const kvps = [];

        const process = ({ object }) => {
            Object.entries(object).forEach(entry => {
                let [key, value] = entry;

                const isObjectValue = isObject(value);

                if (isObjectValue) {
                    value[path] = buildPath(object[path], key);
                    value[parent] = () => object;

                    key = value[path];
                }
                else {
                    key = buildPath(object[path], key);
                }

                kvps.push({ key, value });

                if (isObjectValue) {
                    process({ object: value });
                }
            });
        };

        process({ object });

        return kvps;
    }

    getKvps({ object: data }).forEach(({ key, value }) => (bindings[key] || []).forEach(({ set }) => set({ value })));

    return new Proxy(data, handler({ scope: data }));
};


$.Proxy = {};
$.Proxy.unwrap = ({ proxy }) => {
    const target = {};

    const isUnwrappable = (value) => typeof value === "object";

    const unwrap = ({ proxy, target }) => Object.entries(proxy).forEach(([key, value]) => {
        if (isUnwrappable(value)) {
            target[key] = Array.isArray(value) ? [] : {};

            unwrap({ wrapped: value, target: target[key] });
        }
        else {
            target[key] = value;
        }
    });

    unwrap({ proxy, target });

    return target;
};

$.Object = {};
$.Object.wrap = ({ target }) => {
    const handler = ({ isInitial, path, value });
    const scopeHandler = ({ scope }) => ({
        get: (target, key) => {
            debugger;
        },
        set: () => {
            debugger;
        }
    });

    const getPvps = ({ target }) => {
        const pvps = [];
        const buildPath = (first, second) => first ? [first, second].join(".") : second;

        const process = ({ target }) => {
            Object.entries(target).forEach(([key, value]) => {
                const isObject = $.isObject(value);

                if (isObject) {
                    value[path] = buildPath(object[path], key);
                    value[parent] = () => object;

                    key = value[path];
                }
                else {
                    key = buildPath(object[path], key);
                }

                pvps.push({ key, value });

                if (isObject) {
                    process({ object: value });
                }
            });
        };

        process({ target });

        return pvps;
    }




    return { proxy: new Proxy(target, scopeHandler), handler };
};

$.Proxy = {};
$.Proxy.unwrap = ({ proxy }) => {

};

$.Interactable = {};















































$.Element.registry = { "List": () => $.List };

