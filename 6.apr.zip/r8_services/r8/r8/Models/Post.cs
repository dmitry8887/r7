﻿using System;
using System.Web.Security.AntiXss;
using Newtonsoft.Json;

namespace r8.Models
{
  public class Post
  {
    [JsonProperty(PropertyName = "id")]
    public int Id
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "parentPostId")]
    public int ParentPostId
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "externalId")]
    public int ExternalId
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "comment")]
    public string Comment
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "userId")]
    // Internals
    public int UserId
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "userName")]
    public string UserName
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "createdDate")]
    public DateTime CreatedDate
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "ip")]
    public string Ip
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "createdDateMinutes")]
    public int CreatedDateMinutes { get; set; }

    [JsonProperty(PropertyName = "likeCount")]
    public int LikeCount
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "mine")]
    public bool Mine { get; set; }

    public Post Sanitize()
    {
      UserName = AntiXssEncoder.HtmlEncode(UserName, false);
      Comment = AntiXssEncoder.HtmlEncode(Comment, false);
      Ip = AntiXssEncoder.HtmlEncode(Ip, false);
      UserName = AntiXssEncoder.HtmlEncode(UserName, false);

      return this;
    }
  }
}