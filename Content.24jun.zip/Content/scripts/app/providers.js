﻿"use strict";

r8.providers = {};

// remove?
r8.QuotesProvider = new class extends simple.Provider {
	constructor() {
		super({
			name: "Quotes",
			fetch: r8.services.quotes.get,
			merge: ({ existingData, data }) => {
				if (!existingData) {
					return data;
				}

				debugger;
				throw "Not Implemented";
			},
			filter: ({ data, request }) => {
				const { from, to, frame } = request;
				const range = {};

				const filteredData = data.map(seria => {
					range[seria.name] = {};
					const nameRange = range[seria.name];

					const filteredPoints = seria.points.filter(point => {
						const match = point.o >= from && point.o <= to;
						if (match) {
							const m = point.m;
							nameRange.min = Math.min((nameRange.min || Number.POSITIVE_INFINITY), m);
							nameRange.max = Math.max((nameRange.max || Number.NEGATIVE_INFINITY), m);
						}

						return match;
					});

					return { name: seria.name, points: filteredPoints };
				});

				filteredData.forEach((seria) => {
					const nameRange = range[seria.name];
					seria.min = nameRange.min;
					seria.max = nameRange.max;

					seria.median = (seria.min + (seria.max - seria.min) / 2).toFixed(5); // TODO: cache metadata and use it
					seria.level = r8.metadata.getLevel({ change: 100 * (seria.max - seria.min) / seria.min, frame });

					//console.error("Level - " + seria.name, seria.level); // GLTZUR  is good
				});

				filteredData.names = request.names;
				filteredData.from = from;
				filteredData.to = to;
				filteredData.frame = frame;
				filteredData.median = filteredData.from + (filteredData.to - filteredData.from) / 2;

				return filteredData;
			}
		});
	}
};

r8.ContributionsProvider = new class extends simple.Provider {
	constructor() {
		super({
			name: "Contributions",
			fetch: r8.services.contributions.get,
			merge: ({ existingData, data }) => {

				// TODO: use Set to ensure qunique ids...
				if (existingData) {
					data = [...existingData, ...data];
				}

				return data;
			},
			filter: ({ data, request }) => {
				const getJIndex = (from1, to1, from2, to2) => {
					return 100;
				};

				data.forEach(contribution => {
					const from1 = 1, to1 = 2, from2 = 3, to2 = 4;
					contribution.jIndex = getJIndex({ from1, to1, from2, to2 });
				});

				return data;
			}
		});
	}
}

r8.PostsProvider = new class extends simple.Provider {
	constructor() {
		super({
			name: "Posts",
			fetch: r8.services.posts.get,
			merge: ({ data }) => data,
			filter: ({ data }) => {
				data.name = this.name;
				return data;
			}
		});
	}
}