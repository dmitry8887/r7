﻿using System.Collections.Generic;

namespace r8.Models
{
  public class ContributionsResult : List<Contribution>
  {
  }
}