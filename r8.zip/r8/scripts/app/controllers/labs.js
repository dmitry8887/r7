﻿"use strict";

r8.controllers.Labs = class extends simple.Stateful {
    get routing() {
        return { route: "App$Labs", hash: "labs" };
    }

    constructor({ container }) {
        super({ ownedElementIds:[], states: []});
    }

    enter({ transition }) {
        document.querySelector("#view").innerText = "Labs";

        //console.warn(transition);
    }

    leave({ transition }) {
        //console.warn(transition);
    };
}