﻿const r8 = {};
r8.controllers = {};
r8.bands = {};
r8.providers = {};

r8.routes =
    [
        {
            name: "ContributeChart",
            hash: "contribute/chart",
            handle: ({ container }) => {
                return r8.controllers.Contribute.create({ container });
            }
        },
        {
            hash: "contribute/contributions", handle: ({ container }) => { }
        },
        {
            hash: "contribute/contributions/{id}", handle: ({ container }) => { }
        },
        {
            hash: "contribute/contribution", handle: ({ container }) => { }
        },
        {
            hash: "labs", handle: ({ container }) => { }
        },
        {
            hash: "research", handle: ({ container }) => { }
        }
    ];

r8.routes.defaultName = "ContributeChart";
r8.routes.fallbackName = "ContributeChart";
