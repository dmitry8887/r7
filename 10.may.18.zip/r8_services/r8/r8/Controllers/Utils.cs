﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace r8.Controllers
{
  public static class Utils
  {
    public static string GenerateInsertSql(string tableName, IEnumerable<string> fieldNames)
    {
      var namnes = fieldNames as string[] ?? fieldNames.ToArray();

      var fieldNamesString = namnes.Select(t => "[" + t + "]").Aggregate((f, s) => f + "," + s);
      var fieldValuesString = namnes.Select(t => "@" + t).Aggregate((f, s) => f + "," + s);

      string sql = $"insert into {tableName} ({fieldNamesString}) values ({fieldValuesString}); select cast(SCOPE_IDENTITY() as int)";

      return sql;
    }

    public static bool TryGetAuthorizationToken(HttpRequestMessage requestMessage, out string token)
    {
      var authorizationHeader = requestMessage.Headers.Authorization;
      token = null;

      if (authorizationHeader != null)
      {
        token = authorizationHeader.Scheme;

        if (token == "null")
        {
          token = null;
        }
      }

      return !string.IsNullOrEmpty(token);
    }

    public static string GetCallerIp()
    {
      var current = HttpContext.Current;
      string ip = null;

      if (current != null && !current.Request.IsLocal)
      {
        ip = HttpContext.Current.Request.UserHostAddress;
      }

      return ip;
    }
  }
}