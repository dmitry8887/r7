﻿"use strict";

r8.controllers.Research = class extends simple.Controller {
	get properties() {
		return { route: "App$Research", hash: "research", view: () => "Research", name: "Research" };
	}

	constructor({ resolver }) {
		super({
			resolver,
			getContainer: ({ appContainer }) => {
				appContainer.querySelector("#app_view_container").innerHTML =
					simple.Utils.getHtmlImportText({ name: "Research" });

				return appContainer.querySelector("#app_view_container");
			},
			elements: {},
			states: []
		});
	}

	enter() {
		if (!this.initialized) {
			this.init();
		}
	}

	leave() {
		super.detach();
	}
}