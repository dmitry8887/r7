﻿"use strict";

const ResearchController = class extends simple.Controller {
  constructor({ context }) {
    super({
      name: "Research",
      routes:
        [
          {
            hash: "#research",
            handle: function () {
              return Promise.resolve();
            }
          }
        ],
      context
    });
  }

  create({ app }) {
    const container = simple.Dom.getElement({ container: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ container, name: this.name });
    return { container: container.children[0] };
  }

  enter() {
    if (!this.initialized) {
      this.init();
    }
  }

  init() {
  }
}