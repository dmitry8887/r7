﻿"use strict";

r8.controllers.Research = class extends simple.Stateful {
  get routing() {
    return { route: "App$Research", hash: "research" };
  }

  constructor(resolver) {
    super({ elements: [], states: [] });

    this._resolver = resolver;
  }

  get resolver() {
    return this._resolver;
  }

  enter() {
    document.querySelector("#view").innerText = "Research";

    //console.warn(transtion);
  }

  leave() {
    //console.warn(transtion);
  }

  static templates() {
    return [
      { name: "r8.views.research", url: "../html/app/views/research.html" }
    ];
  }
}