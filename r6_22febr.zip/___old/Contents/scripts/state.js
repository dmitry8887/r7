﻿var fxrig = fxrig || {};
fxrig.state = new function() {

    // make it reusable
    var getAppState = function(getAppStateArgs) {
        var appName = getAppStateArgs.appName;
        var appState = localStorage[appName];
        if (appState) {
            appState = JSON.parse(localStorage[appName]);
        }

        if (!appState) {
            appState = { name: appName, cache: {} }
        };

        localStorage[appName] = JSON.stringify(appState);
        return appState;
    };

    this.getAppState = function (appName) {
        return getAppState({ appName: appName });
    };

    this.get = function(getArgs) {
        var controller = getArgs.controller;
        var appName = controller.appName;
        var controllerName = fxrig.router.getControllerName({ route: controller.route });
        
        var getControllerState = function () {
            var appState = getAppState({ appName: appName });
            var controllerState = appState[controllerName];

            if (!controllerState) {
                controllerState = controller.getDefaultState();
                appState[controllerName] = controllerState;

                localStorage[appName] = JSON.stringify(appState);
            }

            return controllerState;
        };

        return getControllerState();
    };

    this.set = function(setStateArgs) {
        var controller = setStateArgs.controller;
        var appName = controller.appName;
        var controllerName = fxrig.router.getControllerName({ route: controller.route });
        var value = setStateArgs.value;

        var appState = JSON.parse(localStorage[appName]);
        appState[controllerName] = value;

        fxrig.state.setAppState(appState, appName);

        return value;
    };

    this.setAppState = function (appState, appName) {
        
        localStorage[appName] = JSON.stringify(appState);
    };

    this.setCache = function (setCacheArgs) {
        
        var appName = setCacheArgs.appName;
        var force = setCacheArgs.force;

        var appState = getAppState({ appName: appName });
        var cache = appState.cache;
        
        return window.Promise.all(setCacheArgs.items.map(function (item) { return fxrig.utils.get(item) }))
            .then(function (results) {

                console.info(appState);

                for (var i = 0; i < results.length; i++) {
                    var result = results[i];
                    if (!cache[result.name] || force) {
                        cache[result.name] = result.text;
                    }
                }
                
                localStorage[appName] = JSON.stringify(appState);
            });

        
    };

    this.getCacheItem = function(getCacheItemArgs) {
        return getAppState({ appName: getCacheItemArgs.appName }).cache[getCacheItemArgs.name];
    };
};