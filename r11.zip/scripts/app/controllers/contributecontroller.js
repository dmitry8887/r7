// 763
class ContributeController extends Controller {
    constructor(context) {
        super({
            name: "Contribute",
            elements: {
                Cache: {
                    id: "cache",
                    initialize: ({ target }) => {
                        const { store, bufferScreens, fetchScreens } = Element.expandos.get({ target, expandos: { store: {} } });

                        const cache = (({ store }) => ({
                            isEmpty: () => Objects.isEmpty({ target: store }),
                            reset: () => Objects.reset({ target: store }),
                            get: ({ areas }) => areas.reduce((previous, current) => {
                                previous[current] = store.data[current];
                                return previous;
                            }, {}),
                            set: ({ area, data }) => {
                                store.data = store.data || {};
                                store.data[area] = data;
                            },
                            store: () => store
                        }))({ store })

                        // TODO: make private function
                        const getParameters = ({ mode, areas, dates, ...rest }) => {
                            if (mode === "Reset") {
                                cache.reset();
                            }

                            const { fetchDates = { from: Number.POSITIVE_INFINITY, to: Number.NEGATIVE_INFINITY } } = cache.store();
                            const { from, to, buffer = (to - from) * bufferScreens, fetch = (to - from) * fetchScreens } = dates;

                            const bufferFrom = from - buffer;
                            const bufferTo = to + buffer;

                            let { from: fetchFrom, to: fetchTo } = fetchDates;

                            const prepend = bufferFrom < fetchFrom;
                            if (prepend) {
                                fetchFrom = from - fetch;
                            }

                            const append = bufferTo > fetchTo;
                            if (append) {
                                fetchTo = to + fetch;
                            }

                            return {
                                mode,
                                areas,
                                ...((prepend || append) && { fetch: { from: fetchFrom, to: fetchTo } }),
                                dates,
                                ...rest
                            };
                        };

                        const process = ({ mode, areas, fetch, dates, ...rest }) => {
                            const ensure = () => {
                                if (fetch) {
                                    const { App } = context.controllers;
                                    App.busy({ text: "Loading data..." });

                                    return Promise.all(areas.map(area => context.services.Data[area].fetch({ dates, ...rest })))
                                        .then(data => {
                                            debugger;
                                        });
                                }
                                return Promise.resolve({ data: cache.get({ areas }) });
                            };

                            const filter = ({ data }) => {

                            };

                            return ensure().then(filter).then(data => {


                                debugger;
                            });

                            /* return Promise.all(areas.map(area => {
                                return context.services.Data[area].request({ cache, feedback, ...parameters });
                            })).then(data => {

                                // TODO: add fetch & display here
                                data = data.reduce((previousValue, currentValue) => {
                                    const [entry] = Object.entries(currentValue);
                                    const [key, value] = entry;
                                    previousValue[key] = value;
                                    return previousValue;
                                }, {});

                                const { display, fetch } = parameters;
                                cache.set({ display, fetch });

                                return { data };
                            }); */
                        };

                        const handler = ({ data }) => {
                            Data.set({ target: this.$.Contribute, data, components: [Chart, List] });
                        };

                        DataCache.initialize({ target, getParameters, process, handler });
                    }
                },
                DateRange: {
                    id: "date_range",
                    initialize: ({ target }) => {
                        DateRange.initialize({
                            target, handler: ({ register }) => {
                                this.set({
                                    target,
                                    states: [{ descriptor: "Editor$Enter", value: { register } }], // TODO: id can be passed into enter({}) using event specific attributes
                                })
                            }

                        });
                    }
                },
                NameList: {
                    id: "name_list",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            getItems: ({ ids }) =>
                                context.services.Lookup.Names({ ids }),
                            format: ({ target, id }) => {
                                // TODO: create color binding
                                target = target.querySelector("#color"); // TODO: make it part of the setup
                                const { color } = context.services.Formatting.name({ name: id });
                                Element.show({ target });
                                Element.paint({ target, color });
                            },
                            handler: () => {
                                //if (super.isInState({ descriptor: "Editor$Enter" })) {
                                // TODO: request data
                                context.services.AppState.set({
                                    path: `controllers.${this.name} `,
                                    value: Data.get({ target: this.$.Contribute })
                                });
                                //}
                            }
                        });
                    }
                },
                TagList: {
                    id: "tag_list",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            getItems: ({ ids }) =>
                                context.services.Lookup.Tags({ ids }),
                            handler: () => {
                                //if (!super.isInState({ descriptor: "Editor$Enter" })) {
                                context.services.AppState.set({
                                    path: `controllers.${this.name} `,
                                    value: Data.get({ target: this.$.Contribute })
                                });
                                //}
                            }
                        });
                    }
                },
                NamePicker: {
                    id: "name_picker",
                    initialize: ({ target }) => {
                        Picker.initialize({
                            target, handler: ({ name, ids, selectedIds }) => {
                                switch (name) {
                                    case "apply":
                                        List.data.set({
                                            target: this.$.Names,
                                            ids,
                                            selectedIds,
                                            lookup: context.services.Lookup.get
                                        });
                                        this.set({ descriptors: ["Editor.Names$Leave"] });
                                        break;
                                    default:
                                        debugger;
                                        break;
                                }
                            }
                        });
                    }
                },
                TagPicker: {
                    id: "tag_picker",
                    initialize: ({ target }) => {
                        Picker.initialize({
                            target, handler: ({ name, ids, selectedIds }) => {
                                switch (name) {
                                    case "apply":
                                        List.data.set({
                                            target: this.$.Tags,
                                            ids, selectedIds, lookup: context.services.Lookup.get
                                        });
                                        this.set({ descriptors: ["Editor.Tags$Leave"] }); // TODO: watch history
                                        break;
                                }
                            }
                        });
                    }
                },
                ContributionDateRange: {
                    id: "contribution_date_range",
                    initialize: ({ target }) => {
                        DateRange.initialize({
                            target, handler: () => {
                            }
                        });
                    }
                },
                ContributionNamePicker: {
                    id: "contribution_name_picker",
                    initialize: ({ target }) => {
                        Picker.initialize({
                            target, handler: ({ name, ids, selectedIds }) => {
                                switch (name) {
                                    case "apply":
                                        List.data.set({
                                            target: this.$.ContributionNames,
                                            ids, selectedIds, lookup: context.services.Lookup.get
                                        });
                                        this.set({ descriptors: ["Contribution.Names$Leave"] });
                                        break;
                                    default:
                                        debugger;
                                        break;
                                }
                            }
                        });
                    }
                },
                ContributionTagPicker: {
                    id: "contribution_tag_picker",
                    initialize: ({ target }) => {
                        Picker.initialize({
                            target, handler: ({ name, ids, selectedIds }) => {
                                switch (name) {
                                    case "apply":
                                        List.data.set({
                                            target: this.$.ContributionTags,
                                            ids, selectedIds, lookup: context.services.Lookup.get
                                        });
                                        this.set({ descriptors: ["Contribution.Tags$Leave"] });
                                        break;
                                    default:
                                        debugger;
                                        break;
                                }
                            }
                        });
                    }
                },
                ContributionNames: {
                    id: "contribution_names",
                    initialize: ({ target }) => {
                        List.initialize({
                            target, handler: () => {
                                //debugger;
                            },
                            formattable: {
                                format: ({ target, id /*, part = Seria*/ }) => {
                                    target = target.querySelector("#formattable"); // TODO: make it part of the setup
                                    const { color } = context.services.Formatting.name({ name: id });
                                    Element.show({ target });
                                    Element.paint({ target, color });
                                }
                            }
                        });
                    }
                },
                ContributionTags: {
                    id: "contribution_tags",
                    initialize: ({ target }) => {
                        List.initialize({
                            target, handler: () => {
                                //debugger;
                            }
                        });
                    }
                },
                ContributionType: {
                    id: "contribution_type",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            handler: ({ selectedIds }) => {
                                const descriptor = selectedIds[0] === "Range"
                                    ? "ContributionRange$Enter"
                                    : "ContributionPoint$Enter";

                                super.set({ descriptors: [descriptor] });
                            }
                        });
                    }
                },
                ContributionRiskEstimate: {
                    id: "contribution_risk_estimate",
                    initialize: ({ target }) =>
                        Spinner.initialize({ target, items: context.services.Lookup.TShirtSizes() })
                },
                ContributionVolumeEstimate: {
                    id: "contribution_volume_estimate",
                    initialize: ({ target }) =>
                        Spinner.initialize({ target, items: context.services.Lookup.TShirtSizes() })
                },
                ContributionLeverageEstimate: {
                    id: "contribution_leverage_estimate",
                    initialize: ({ target }) =>
                        Spinner.initialize({ target, items: context.services.Lookup.TShirtSizes() })
                },
                ContributionClosureType: {
                    id: "contribution_closure_type",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            handler: (/*{ selectedIds }*/) => {
                                // debugger;
                            }
                        });
                    }
                },
                Mode: {
                    id: "mode",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            handler: ({ selectedIds }) => {
                                const showContributions = selectedIds.includes("List");
                                this.set({ descriptors: [["Contributions", showContributions ? "Enter" : "Leave"].join("$")] });
                            }
                        });
                    }
                },
                Chart: {
                    id: "chart",
                    initialize: ({ target }) => {
                        Chart.initialize({
                            target,
                            handler: ({ name, from, to }) => {
                                if (name === "Request") {
                                    DataCache.request({ target: this.$.Cache, dates: { from, to }, mode: "Partial" });
                                }
                            }
                        });
                    }
                },
                ChartFrame: {
                    id: "chart_frame",
                    initialize: ({ target }) =>
                        Spinner.initialize({ target, items: context.services.Lookup.Frames() })
                },
                ListFilters: {
                    id: "list_filters",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            handler: () =>
                                List.filter({ target: this.$.Contributions })
                        });
                    }
                },
                Contributions: {
                    id: "contributions",
                    initialize: ({ target }) => {
                        List.initialize({
                            target,
                            getTemplateName: ({ item }) => `Contribute.Contributions.${item.type.selectedIds[0]} `,
                            filter: ({ item }) => {
                                const { selectedIds } = List.data.get({ target: this.$.ListFilters });
                                const user = 1;

                                const userOkay = item.user === user || !selectedIds.includes("M");
                                const typeOkay = item.type === "Range" && selectedIds.includes("R")
                                    || item.type === "Point" && selectedIds.includes("P")
                                    || (!selectedIds.includes("R")
                                        && !selectedIds.includes("P"));

                                return userOkay
                                    && typeOkay;
                            },
                            handler: ({ id, command }) => {
                                const handlers = {
                                    Edit: () => Browser.setHash({ hash: `contributions / ${id} `, reload: true })
                                };

                                handlers[command]();
                            }
                        });
                    }
                }
            },
            states: {
                Editor: {
                    leave: () => {
                        DateRange.set({ target: this.$.DateRange, descriptors: ["Editing$Leave"] });
                        // this.execute({ commands: [{ name: "SetState" }] });
                    },
                    reEntryAction: "Ignore",
                    backable: true
                },
                "Editor.Names": {
                    enter: () => {
                        const { ids, selectedIds, items } = List.data.get({
                            target: this.$.Names,
                            lookup: context.services.Lookup.get
                        });
                        Picker.data.set({ target: this.$.NamePicker, ids, selectedIds, items });
                    },
                    group: "Editors",
                    backable: true
                },
                "Editor.Tags": {
                    enter: () => {
                        const { ids, selectedIds, items } = List.data.get({
                            target: this.$.Tags,
                            lookup: context.services.Lookup.get
                        });
                        Picker.data.set({ target: this.$.TagPicker, ids, selectedIds, items });
                    },
                    group: "Editors",
                    backable: true
                },
                ContributionErrors: {
                    reEntryAction: "Allow",
                    enter: ({ /*target,*/ value }) => {
                        Data.set({
                            target: this.$.Contribution,
                            data: { errors: value.errors.map(error => `- ${error} `).join("<br/>") }
                        });
                    }
                },
                Contribution: {
                    enter: () => {
                        const { names, tags, dates } = context.services.AppState.get({ path: `controllers.${this.name} ` });
                        // TODO: create s service call for creating a new (default) contribution
                        Data.set({
                            target: this.$.Contribution,
                            data: {
                                names,
                                tags,
                                dates,
                                type: { selectedIds: ["Range"] },
                                volumeEstimate: { selectedId: "L" },
                                riskEstimate: { selectedId: "L" },
                                leverageEstimate: { selectedId: "L" },
                                comments: "",
                                min: 1,
                                open: 2,
                                close: 3,
                                volume: 4,
                                leverage: 5
                            },
                            context: {
                                lookup: context.services.Lookup.get
                            },
                            handle: true
                        });
                    },
                    leave: () => {
                    },
                    backable: true
                },
                ContributionRange: {
                    group: "ContributionType"
                },
                ContributionPoint: {
                    group: "ContributionType"
                },
                "Contribution.Names": {
                    group: "ContributionEditors",
                    enter: () => {
                        const { ids, selectedIds, items } = List.data.get({ target: this.$.ContributionNames, lookup: context.services.Lookup.get });
                        Picker.data.set({ target: this.$.ContributionNamePicker, ids, selectedIds, items });
                    },
                    backable: true
                },
                "Contribution.Tags": {
                    group: "ContributionEditors",
                    enter: () => {
                        const { ids, selectedIds, items } = List.data.get({ target: this.$.ContributionTags, lookup: context.services.Lookup.get });
                        Picker.data.set({ target: this.$.ContributionTagPicker, ids, selectedIds, items });
                    },
                    backable: true
                },
                Contributions: {
                    backable: true,
                    enter: () => {
                        Data.set({
                            target: this.$.Contribute,
                            data: {
                                mode: {
                                    selectedIds: ["List"]
                                }
                            }
                        });
                    },
                    leave: () => {
                        Data.set({
                            target: this.$.Contribute,
                            data: {
                                mode: {
                                    selectedIds: ["Chart"]
                                }
                            }
                        });
                    }
                }
            },
            commands: {
                Save: {
                    handler: function () {
                        context.services.AppState.set({
                            path: `controllers.${this.name} `,
                            value: Data.get({ target: this.$.Contribute })
                        });
                        throw "Implement with DataCache.request";
                    }
                },
                SaveContribution: {
                    handler: function () {
                        const { services, controllers } = context;
                        const { data: contribution, isValid, errors } = Data.get({ target: this.$.Contribution });
                        const appAuth = services.AppAuth;

                        if (isValid) {
                            const authenticate = appAuth.isAuthenticated()
                                ? () => Promise.resolve({ user: appAuth.user.get() })
                                : () => controllers.App.decorators.Authenticate({ mode: "Login" });

                            return authenticate().then(({ user, action }) => {
                                debugger;

                                contribution.userId = user.id;

                                return controllers.App.decorators.Busy({
                                    parameters: { text: "Adding Contribution..." },
                                    handler: () => {
                                        services.Contributions.add(contribution)
                                            .then(result => {
                                                this.set({ descriptors: ["Contribution$Leave"] });

                                                DataCache.request({
                                                    target: this.$.Cache,
                                                    parameters: { areas: ["Contributions"] }, mode: "Update"
                                                });

                                                return Promise.resolve(result);
                                            });
                                    }
                                });
                            });
                        }
                        else {
                            this.set({ states: [{ descriptor: "ContributionErrors$Enter", value: { errors } }] });
                        }
                    }
                }
            },
            requires: ({ target }) => context.controllers.App.create({ target }),
            create: ({ /*target,*/ controller }) => {
                return Element.fill({
                    target: controller.$.AppSlot,
                    name: this.name,
                    leaving: (/*{ name }*/) => this.destroy()
                })
            },
            destroy: () => {
                console.error("Destroying Contribute");
            },
            state: (() => {
                const to = Dates.getMinutes() - 1;
                const from = to - 120;

                return {
                    dates: {
                        from,
                        to,
                        step: 1
                    },
                    names: { ids: ["N1", "N2", "N3"], selectedIds: ["N1"] },
                    tags: { ids: ["T1", "T2", "T3"] },
                    frame: "1M"
                };
            })(),
            routes:
                [
                    {
                        route: "contribute",
                        handler: ({ target, values }) =>
                            super.create({ target })
                                .then(() => {
                                    const { names, tags, dates } = context.services.AppState.get({
                                        path: `controllers.${this.name} `,
                                        fallback: this.state // TODO: esli eto edinstvennoe mesto gde eto stavitsja stavit defot zdes' ge
                                    });

                                    Data.set({
                                        target: this.$.Contribute,
                                        data: {
                                            mode: "Chart", fix: "Center", names, tags, dates
                                        },
                                        components: [DateRange, List, Chart, Spinner, InnerHtml, UncontrolledList]
                                    });

                                    super.set({ descriptors: ["Editor$Leave"] });

                                    DataCache.request({
                                        target: this.$.Cache,
                                        areas: ["Quotes", "Contributions"],
                                        mode: "Reset",
                                        names,
                                        tags,
                                        dates,
                                    }); // TODO: ne nugen vozvrashat' promise deluashij nothing

                                    context.controllers.App.free();
                                })
                    },
                    {
                        route: "confirm",
                        redirectToRoute: "contribute",
                        handler: ({ target, values }) => {
                            const { token } = values || {};
                            if (!token) {
                                debugger;
                                throw "Invalid Operation";
                            }

                            // TODO: remove decorator, migrate to @ decorators
                            return super.create({ target }).then(() => {
                                context.controllers.App.decorators.Busy({
                                    parameters: { text: "Confirming..." },
                                    handler: () => {
                                        return context.services.Confirm.execute({ token })
                                            .finally(() => {
                                                context.controllers.App.set({
                                                    states: [{
                                                        descriptor: "AppModal$Enter",
                                                        value: { text: "Varified" }
                                                    }]
                                                });
                                            });
                                    }
                                });

                            });
                        }
                    }
                ],
            templates:
                [
                    {
                        name: "Contribute.Contributions.Point",
                        handler: ({ context }) => {
                            return `< div class="grid border-bottom" style = "grid-template-columns: min-content auto min-content;" >
                                <div class="padding" style="grid-column: 1;">
                                    <div class="border margins-auto grid" style="width: 30px; height: 30px;">
                                        <p class="margins-auto">P</p>
                                    </div>
                                </div>
                                <p class="margins-vertical-auto" style="grid-column: 2;">${context.comments}</p>
                                <div class="padding grid" style="grid-column: 3;">
                                    <button data-element-events='{"types": "click", "command": "Edit", "parameters": {"id": "${this.id}"}'
                                        class="margins-auto">Edit</button>
                                </div>
                                    </div > `;
                        }
                    },
                    {
                        name: "Contribute.Contributions.Range",
                        handler: ({ context }) => {
                            return `< div class="grid border-bottom" style = "grid-template-columns: min-content auto min-content;" >
                            <div class="padding" style="grid-column: 1;">
                                <div class="border margins-auto grid" style="width: 30px; height: 30px;">
                                    <p class="margins-auto">R</p>
                                </div>
                            </div>
                            <p class="margins-vertical-auto" style="grid-column: 2;">${this.comments}</p>
                            <div class="padding grid" style="grid-column: 3;">
                                <button data-element-events='{"types": "click", "command": "Edit", "parameters": {"id": "${this.id}"}'
                                    class="margins-auto">Edit</button>
                            </div>
                                    </div > `;
                        }
                    }
                ]
        });
    }
};