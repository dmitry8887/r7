﻿using r8.Models;
using r8.Services;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.Http;
using Dapper;
using System.Linq;

namespace r8.Controllers
{
    public class ContributionsController : ApiController
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

        public ContributionsResult Get(string names = "", string tags = "", int from = 0, int to = 0, int id = 0)
        {
            names = FormatCsvString(names);

            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();
                string sql;
                if (id == 0)
                {
                    sql = $@"SELECT contribution.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, contribution.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = contribution.[Id] AND ReactionType = 'Like' AND TargetType = 'Contribution') AS LikeCount,
                        (CASE WHEN contribution.[TypeId] = 1 THEN 'Range' ELSE 'Point' END) AS [Type],
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK) 
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON contribution.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE ((SELECT MAX(FromValues) FROM (values (contribution.[From]), ({from})) AS value(FromValues)) <= 
                          (SELECT min(ToValues) FROM (values (contribution.[To]), ({to})) AS value(ToValues))) AND contribution.[Names] = '{names}'";
                }
                else {
                    sql = $@"SELECT contribution.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, contribution.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = contribution.[Id] AND ReactionType = 'Like' AND TargetType = 'Contribution') AS LikeCount,
                        (CASE WHEN contribution.[TypeId] = 1 THEN 'Range' ELSE 'Point' END) AS [Type],
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK) 
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON contribution.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE contribution.Id = {id}";
                }

                var contributions = connection.Query<Contribution>(sql).ToList();
                var result = new ContributionsResult();

                result.AddRange(contributions);

                if (id> 0 && contributions.Count() == 1)
                {
                    var contribution = contributions[0];

                    sql = $@"SELECT post.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, post.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = post.[Id] AND ReactionType = 'Like' AND TargetType = 'Post') AS LikeCount,
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK)
                          INNER JOIN dbo.[Post] post WITH(NOLOCK) on post.[ExternalId] = contribution.[Id]
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON post.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE ExternalId = ${contribution.Id}";
                    
                    contribution.Discussion = connection.Query<Post>(sql).ToList();
                }

                connection.Close();

                return result;
            }
        }

        private Contribution Process(Contribution contribution)
        {
            contribution.TypeId = contribution.Type.Trim().ToLowerInvariant() == "range" ? 1 : 2;

            if (!string.IsNullOrEmpty(contribution.RiskEstimate)
                && contribution.RiskEstimate.Trim().ToLowerInvariant() == "none")
            {
                contribution.RiskEstimate = null;
            }

            if (!string.IsNullOrEmpty(contribution.VolumeEstimate)
                && contribution.VolumeEstimate.Trim().ToLowerInvariant() == "none")
            {
                contribution.VolumeEstimate = null;
            }

            if (!string.IsNullOrEmpty(contribution.LeverageEstimate)
                && contribution.LeverageEstimate.Trim().ToLowerInvariant() == "none")
            {
                contribution.LeverageEstimate = null;
            }

            if (contribution.TypeId == 1)
            {

            }
            else
            {
                contribution.DirectionId = contribution.Direction.Trim().ToLowerInvariant() == "buy" ? 1 : 2;
                contribution.CloseModeId = contribution.CloseMode.Trim().ToLowerInvariant() == "manual" ? 1 : 2;
            }

            contribution.CreatedDate = DateTime.UtcNow;
            contribution.Ip = Utils.GetCallerIp();

            contribution.Names = FormatCsvString(contribution.Names);

            return contribution;
        }

        [HttpPost]
        public Contribution Post(Contribution contribution)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                if (!string.IsNullOrEmpty(token))
                {
                    int appUserId;
                    if (UserServices.TryGetAppUserId(token, connection, out appUserId))
                    {
                        contribution.UserId = appUserId;
                    }
                    else
                    {
                        throw new HttpException("Invalid Token.");
                    }
                }

                contribution = Process(contribution);

                contribution.Id = connection.Query<int>(
                  Utils.GenerateInsertSql("dbo.[Contribution]",
                    new[]
                    {
              "TypeId", "Names", "From", "To", "UserId", "Tags", "Comment", "DirectionId", "RiskEstimate", "Open", "StopLoss", "TakeProfit",
              "Volume", "VolumeEstimate", "Close", "CloseModeId", "Leverage", "LeverageEstimate", "CreatedDate", "Ip"
                    }), contribution.Sanitize()).Single();

                connection.Close();
            }

            return contribution;
        }


        [HttpPut]
        public Contribution Put(Contribution contribution)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                if (!string.IsNullOrEmpty(token))
                {
                    int appUserId;
                    if (UserServices.TryGetAppUserId(token, connection, out appUserId))
                    {
                        contribution.UserId = appUserId;
                    }
                    else
                    {
                        throw new HttpException("Invalid Token.");
                    }
                }

                var existingContribution =
                    connection.Query<Contribution>($"select * from [dbo].Contribution where [Id] = {contribution.Id}").ToList().FirstOrDefault();
                
                if (existingContribution == null) {
                    throw new HttpException(410, string.Empty);
                }

                if (existingContribution.UserId != contribution.UserId) {
                    throw new HttpException(401, string.Empty);
                }

                contribution = Process(contribution);

                contribution.Id = connection.Query<int>(
                  Utils.GenerateUpdateSql("dbo.[Contribution]",
                    new[]
                    {
              "TypeId", "Names", "From", "To", "UserId", "Tags", "Comment", "DirectionId", "RiskEstimate", "Open", "StopLoss", "TakeProfit",
              "Volume", "VolumeEstimate", "Close", "CloseModeId", "Leverage", "LeverageEstimate", "CreatedDate", "Ip"
                    }), contribution.Sanitize()).Single();

                connection.Close();
            }

            return contribution;
        }

        [HttpDelete]
        public void Delete(Contribution contribution) {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                if (!string.IsNullOrEmpty(token))
                {
                    int appUserId;
                    if (UserServices.TryGetAppUserId(token, connection, out appUserId))
                    {
                        contribution.UserId = appUserId;
                    }
                    else
                    {
                        throw new HttpException("Invalid Token.");
                    }
                }

                var existingContribution =
                    connection.Query<Contribution>($"select * from [dbo].Contribution where [Id] = {contribution.Id}").ToList().FirstOrDefault();

                if (existingContribution == null)
                {
                    throw new HttpException(410, string.Empty);
                }

                if (existingContribution.UserId != contribution.UserId)
                {
                    throw new HttpException(401, string.Empty);
                }

                connection.ExecuteScalar(Utils.GenerateDeleteSql("dbo.[Contribution]"));
                connection.Close();
            }
        }

        public string FormatCsvString(string value)
        {
            return value.Split(',').Select(t => t.Replace("*", string.Empty)).OrderBy(name => name).Aggregate((f, s) => f + "," + s);
        }
    }
}