const ResearchController = new class extends Component {
    constructor() {
        super({
            elements: {
            },
            states: {
            },
            create: element => {
                throw "Not Impelemented";
            }
        });
    }
};
