﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace BookKeeper.Converters
{
    public class DollarDelimitedStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (parameter == null
                || value == null)
            {
                return Binding.DoNothing;
            }

            int index = int.Parse(parameter.ToString());
            return value.ToString().Split("$".ToCharArray())[index];
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
