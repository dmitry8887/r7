﻿"use strict";

r8.controllers = {};

// 195
const AppController = class extends simple.Controller {
  constructor({ resolver }) {
    super({
      name: "App",
      elements: {
        AppOverlay: { id: "app_overlay" },
        AppOverlayText: { id: "app_overlay_text" },
        AppMenu: {
          id: "app_menu",
          init: ({ element }) => simple.List.init({ element, template: ({ item }) => simple.Element.evalTemplate({ name: "App.MenuItem", context: item }), items: r8.metadata.menuItems() })
        },
        AppMenuOverlay: { id: "app_menu_overlay" },
        AppAppsOverlay: { id: "app_apps_overlay" },
        AppUserActivities: { id: "app_user_activities" },
        AppUserActivitiesOverlay: { id: "app_user_activities_overlay" },
        UserName: { id: "user_name" },
        AppMenuUserName: { id: "app_menu_user_name" },
        AppAuthenticateOverlay: {
          id: "app_authenticate_overlay",
          init: ({ element }) => {
            simple.Authentication.init({
              element,
              handle: ({ name, value, cancel }) => {
                if (cancel) {
                  return simple.App.cancel();
                }

                return this.run({
                  handle: () => {
                    // TODO: remove new Promise
                    return new Promise((resolve) => {
                      const action = {
                        Login: r8.services.authentication.login,
                        Register: r8.services.authentication.register,
                        Restore: r8.services.authentication.restore
                      }[name];
                      action(value).then(resolve);
                    });
                  },
                  options: { text: "Authenticating..." }
                });
              }
            });
          }
        },
        AppMenuLogin: { id: "app_menu_login" },
        AppMenuLogout: { id: "app_menu_logout" },
        UserLogout: { id: "user_logout" },
        AppGuest: { id: "app_guest" },
        AppUser: { id: "app_user" },
        AppMenuLauncher: { id: "app_menu_launcher" },
        AppViewHeader: { id: "app_view_header" },
        AppAppsBack: { id: "app_apps_back" },
        AppAppsLauncher: { id: "app_apps_launcher" },
        AppMenuBack: { id: "app_menu_back" },
        AppTheme: {
          id: "app_theme",
          init: ({ element }) => {
            const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;
            const { theme } = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

            simple.RadioList.init({
              element,
              items: r8.metadata.themes(),
              selectedId: theme,
              on: ({ id }) => {
                simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });

                setTheme({ theme: id });

                simple.App.apply();
              }
            });

            simple.RadioList.setSelectedId({ element, id: theme });
          }
        }
      },
      states: {
        User: {
          enter: () => {
            const { userName } = r8.services.app.getUser();
            ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name }).innerHTML = userName);
          },
          leave: () => ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name }).innerHTML = "Guest")
        },
        Overlay: {
          reEntryAction: "Allow",
          enter: ({ value }) => {
            const { text } = value;
            this.getElement({ name: "AppOverlayText" }).innerHTML = text;
          }
        },
        UserActivities: { reEntryAction: "Ignore" },
        Apps: { reEntryAction: "Ignore" }
      },
      commands: {
        Authenticate: {
          execute: ({ allowGuestLogin }) => this.authenticate({ allowGuestLogin }).then(() => simple.App.apply())
        },
        Logout: {
          execute: () => {
            r8.services.app.removeUser();
            this.execute({ batch: { descriptors: ["User$Leave"] } });
          }
        }
      },
      root: true,
      routes: [
        { hash: "#me", handle: () => this.getUserAcitivities() }
      ],
      resolver
    });

    this.run = this.run.bind(this);
    this.authenticate = this.authenticate.bind(this);
  }

  getUserAcitivities() {
    return r8.services.user.acitivities().then(() => {
      this.execute({ batch: { descriptors: ["UserActivities$Enter"] } });
    });

    /*.then(result => {
      return Promise.resolve();
    });*/
  }

  create({ resolver }) {
    debugger;
    
    return resolver.getElement();
  }

  run({ handle, options }) {
    return new Promise((resolve) => {
      this.busy({ options });

      handle().then(result => {
        this.free();
        resolve(result);
      });
    });
  }

  init() {
    super.init();
    this.execute({ batch: { descriptors: [r8.services.app.authenticated() ? "User$Enter" : "User$Leave"], transient: true } });
  }

  // TODO: move to commands
  authenticate({ allowGuestLogin }) {
    if (r8.services.app.authenticated()) {
      return Promise.resolve();
    }

    this.execute({ batch: { descriptors: ["Authenticate$Enter"] } });

    return simple.Authentication.authenticate({
      element: this.getElement({ name: "AppAuthenticateOverlay" }),
      appContext: this.appContext,
      allowGuestLogin
    }).then(result => {
      if (result) {
        const { userName, token } = result;
        r8.services.app.setUser({ user: { userName, token } });
        this.execute({ batch: { descriptors: ["User$Enter"], transient: true } });
      }

      simple.App.apply();
    });
  }

  busy({ options }) {
    this.execute({ batch: { states: [{ descriptor: "Overlay$Enter", value: options }], transient: true } });
  }

  free() {
    this.execute({ batch: { descriptors: ["Overlay$Leave"], transient: true } });
  }

  formatter({ name, selected }) {
    const color = Object.assign({}, { GLTZUR: "#ccc", VNRODG: "#ccc", DUSVJL: "#ccc" })[name];
    const thickness = selected ? 5 : 1;

    return { color, thickness };
  }

  export() {
    return { run: this.run, authenticate: this.authenticate, formatter: this.formatter };
  }
};