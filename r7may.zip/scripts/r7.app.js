﻿var r7 = r7 || {};
r7.app = r7.app || {};

r7.app.controllers = r7.app.controllers || {};
r7.app.bootstrap = function () {
    var init = function () {

        var states = {
            busy: {
                enter: function () {
                    $("#app_overlay").show();
                },
                leave: function() {
                    $("#app_overlay").hide();
                }
            }
        };


        r7.lib.state.ensureCache({
            items: [
                { name: "lib.menu", url: "html/lib/menu.html" },
                { name: "lib.menu.item.template", url: "html/lib/menu.item.template.html" },
                { name: "lib.chart.expanded", url: "html/lib/chart.expanded.html" },
                { name: "lib.chart.collapsed", url: "html/lib/chart.collapsed.html" },
                { name: "lib.list.expanded", url: "html/lib/list.expanded.html" },
                { name: "lib.list.collapsed", url: "html/lib/list.collapsed.html" },
                //
                { name: "app.views.contribute", url: "html/app/views/contribute.html" },
                { name: "app.views.research", url: "html/app/views/research.html" },
                { name: "app.views.labs", url: "html/app/views/labs.html" }
            ]
        }).then(function() {

            r7.lib.router.init({
                container: $("#app"),
                hash: "contribute",
                defaultHash: "contribute", // TODO: merge hash with defaultHash
                controllers:
                [
                    r7.app.controllers.app,
                    r7.app.controllers.app.contribute,
                    r7.app.controllers.app.research,
                    r7.app.controllers.app.labs
                ],
                predict: function(transition) {
                    //fxrig.apps.ensure({ container: $("#apps", $container), transition: transition });
                },
                done: function (e) {
                    $("#app_view_header").html(e.controller.header);
                },
                error: function (e) {
                    //console.error(e);
                }
            });
        });
    };

    init();
};