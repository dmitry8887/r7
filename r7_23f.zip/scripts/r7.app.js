﻿var r7 = r7 || {};
r7.app = r7.app || {};

r7.app.controllers = r7.app.controllers || {};

r7.app.bootstrap = function () {
    var init = function () {
        
        r7.lib.state.ensureCache({
            items: [
                { name: "lib.menu", url: "html/lib/menu.html" }
            ]
        });

        r7.lib.menu.init({
            launcher: $("#menu_launcher"),
            container: $("#app_overlay")
        });
    };

    init();
};