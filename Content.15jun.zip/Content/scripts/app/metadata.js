﻿"use strict";

const r8 = {};
r8.metadata = {}

r8.metadata.match = ({ categories, value, item }) => {
	const categoriesMatch = categories.length === 0 || item.categories.find(category => categories.includes(category));
	const valueMatch = value.trim() === "" || item.text.toUpperCase().includes(value.toUpperCase());

	return categoriesMatch && valueMatch;
};

r8.metadata.nameCategories = () => [{ id: "NC1", text: "NC1" }, { id: "NC2", text: "NC2" }, { id: "NC3", text: "NC3" }]; // rename to get...Categories

r8.metadata.getLevel = ({ change, frame }) => {
	change = 300 * (change / frame); // TODO: verify with other frames
	if (change < 0.25) return 1;
	if (change < 0.5) return 2;
	if (change < 0.75) return 3;
	if (change < 1) return 4;
	return 5;
};

r8.metadata.names = () =>
	[
		{ id: "GLTZUR", text: "GLTZUR", categories: ["NC1"] },
		{ id: "VNRODG", text: "VNRODG", categories: ["NC2"] },
		{ id: "DUSVJL", text: "DUSVJL", categories: ["NC3"] }
	];

r8.metadata.tagCategories = () => [{ id: "TC1", text: "TC1" }, { id: "TC2", text: "TC2" }, { id: "TC3", text: "TC3" }];

r8.metadata.tags = () =>
	[
		{ id: "T0", text: "T0", categories: ["TC1"] },
		{ id: "T1", text: "T1", categories: ["TC1"] },
		{ id: "T2", text: "T2", categories: ["TC1"] },
		{ id: "T3", text: "T3", categories: ["TC2"] },
		{ id: "T4", text: "T4", categories: ["TC2"] },
		{ id: "T5", text: "T5", categories: ["TC2"] },
		{ id: "T6", text: "T6", categories: ["TC3"] },
		{ id: "T7", text: "T7", categories: ["TC3"] },
		{ id: "T8", text: "T8", categories: ["TC3"] }
	];

r8.metadata.contributionTypes = () => [{ id: "Range", text: "Range" }, { id: "Point", text: "Point" }];

r8.metadata.contributionsFilterCategories = () => [{ id: "Range", text: "Range" }, { id: "Point", text: "Point" }];

r8.metadata.themes = () => [{ id: "light", text: "Light" }, { id: "dark", text: "Dark" }];

r8.metadata.contributionPointDirections = () => [{ id: "Buy", text: "Buy" }, { id: "Sell", text: "Sell" }];

r8.metadata.estimates = () => ["None", "XS", "S", "M", "L", "XL", "XXL"].map(value => ({ id: value, text: value }));

r8.metadata.contributionPointCloseModes = () => [{ id: "Manual", text: "Manual" }, { id: "Auto", text: "Auto" }];
