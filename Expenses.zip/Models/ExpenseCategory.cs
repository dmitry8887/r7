﻿using System;
using System.Data;

namespace BookKeeper.Models
{
    public class ExpenseCategory
    {
        public static readonly Func<IDataReader, ExpenseCategory> DataReaderCreator = (reader) => new ExpenseCategory()
        {
            Id = (int)reader["Id"],
            Name = (string)reader["Name"]
        };
        
        public int Id { get; private set; }

        public string Name { get; private set; }
    }
}
