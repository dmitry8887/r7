﻿"use strict";

const LabsController = class extends simple.Controller {
  constructor({ context }) {
    super({
      elements: {
        LabsDebug: { id: "labs_debug" }
      },
      name: "Labs",
      routes: [
        { hash: "#labs", handle: () => this.debug() }
      ],
      context
    });
  }

  debug() {
    debugger;
    return Promise.resolve();
  }

  create({ app }) {
    const element = simple.Dom.getElement({ element: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ element, name: this.name });
    debugger;

    return { element: element.children[0] };
  }

  init() {
    debugger;
    super.init();

    this.getElement({ name: "LabsDebug" }).innerHTML = "Lab Debug";
  }
};