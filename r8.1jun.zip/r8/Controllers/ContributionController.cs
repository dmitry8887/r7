﻿using r8.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using Dapper;

namespace r8.Controllers
{
    public class ContributionController: ApiController
    {
        private static readonly string ConnectionString =
           ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

        public ContributionResult Get(int id)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            string sql;
            
            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                sql = $@"SELECT contribution.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, contribution.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = contribution.[Id] AND ReactionType = 'Like' AND TargetType = 'Contribution') AS LikeCount,
                        (CASE WHEN contribution.[TypeId] = 1 THEN 'Range' ELSE 'Point' END) AS [Type],
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK) 
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON contribution.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE contribution.Id = {id}";

                var contribution = connection.Query<Contribution>(sql).First();

                sql = $@"SELECT post.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, post.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = post.[Id] AND ReactionType = 'Like' AND TargetType = 'Post') AS LikeCount,
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK)
                          INNER JOIN dbo.[Post] post WITH(NOLOCK) on post.[ExternalId] = contribution.[Id]
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON post.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE ExternalId = {id}";

                var posts = connection.Query<Post>(sql).ToList();

                return new ContributionResult()
                {
                    Contribution = contribution,
                    Posts = posts
                };
            }
        }
    }
}