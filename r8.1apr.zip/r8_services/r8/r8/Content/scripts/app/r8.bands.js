﻿const ranges = function* ({ from, to, frame, merge, include }){
  let currentTo;

  to = frame * Math.ceil(to / frame);
  from = frame * Math.floor(from / frame);

  currentTo = from + frame;

  while(currentTo <= to){
    yield { from, to: currentTo };

    from = currentTo;
    currentTo = from + frame;
  }

  return;
}


r8.bands.weekDays = ({ from, to, data }) => {
  const bands = [];
  
  /*
  
  24096320
  24106240

  */

  bands.push({
    name: "WD",
    from: 24096320,
    to: 24106240,
    level: 1,
    overlayLevel: 1,
    color: "transparent",
    overlayColor: "blue"
  });


  //let color = "white";
  //for(let range of ranges({ from, to, frame: 1440* 10 })){
  //  if (color === "white"){
  //    color = "#ccc";
  //  }
  //  else{
  //    color = "white";
  //  }
    
  //  bands.push({
  //    name: "WD",
  //    from: range.from,
  //    to: range.to,
  //    level: 1,
  //    overlayLevel: 1,
  //    color,
  //    overlayColor: "blue"
  //  });

  ////console.log(range);
  //}

  return bands;
};

r8.bands.random = ({ from, to, data }) => {
  const bands = [];

  bands.push({
    name: "R",
    from,
    to,
    top: 1,
    height: 2,
    color: "green",
    overlayColor: "blue"
  });

  bands.push({
    name: "R",
    from,
    to,
    top: 1,
    height: 2,
    color: "green",
    overlayColor: "blue"
  });

  return bands;
};