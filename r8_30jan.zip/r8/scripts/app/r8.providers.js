﻿r8.providers = {};

r8.providers.quotes = {
  fetch: (request) => {
    window.Promise.resolve(request);
  },
  merge: ()=> {
  },
  filter: () => {
  }
};

r8.providers.bands = {
  fetch: (request) => {
    window.Promise.resolve(request);
  },
  merge: () => {
  },
  filter: () => {
  }
};