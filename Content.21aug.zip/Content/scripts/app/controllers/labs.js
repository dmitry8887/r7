﻿"use strict";

// TODO: create a group for Research, Lab, Contribute
const LabsController = class extends simple.Controller {
  constructor({ appContext }) {
    super({
      elements: {
        LabsDebug: { id: "labs_debug" }
      },
      name: "Labs",
      routes: [
        { hash: "#labs", handle: () => this.debug() }
      ],
      appContext
    });
  }

  debug() {
    debugger;
    return Promise.resolve();
  }

  create({ element }) {
    const placeholderElement = simple.Element.getElement({ element, dataAttributeName: "data-app-view-placeholder" });
    const { content } = simple.Element.setInnerHtml({ element: placeholderElement, name: this.name });

    return content;
  }

  init() {
    debugger;
    super.init();

    this.getElement({ name: "LabsDebug" }).innerHTML = "Lab Debug";
  }
};