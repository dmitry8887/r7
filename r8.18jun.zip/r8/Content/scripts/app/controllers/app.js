﻿"use strict";

r8.controllers = {};

// TODO: app menu z-index should be greather than apps's one
const AppController = class extends simple.Controller {
  constructor({ context }) {
    super({
      name: "App",
      elements: {
        AppOverlay: "app_overlay",
        AppOverlayText: "app_overlay_text",
        AppMenu: "app_menu",
        AppMenuOverlay: "app_menu_overlay",
        AppAppsOverlay: "app_apps_overlay",
        AppUserActivities: "app_user_activities",
        AppUserActivitiesOverlay: "app_user_activities_overlay",
        UserName: "user_name",
        AppMenuUserName: "app_menu_user_name",
        AppAuthenticateOverlay: "app_authenticate_overlay",
        AppMenuLogin: "app_menu_login",
        AppMenuLogout: "app_menu_logout",
        UserLogout: "user_logout",
        AppGuest: "app_guest",
        AppUser: "app_user",
        AppMenuLauncher: "app_menu_launcher",
        AppViewHeader: "app_view_header",
        AppAppsBack: "app_apps_back",
        AppAppsLauncher: "app_apps_launcher",
        AppMenuBack: "app_menu_back",
        AppTheme: "app_theme"
      },
      states: [{
        name: "App$User",
        enter: () => {
          const { userName } = r8.services.app.getUser();
          ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name }).innerHTML = userName);
        },
        leave: () => {
          ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name }).innerHTML = "Guest");
        }
      },
      {
        name: "App$Overlay",
        reEntryAction: "Allow",
        enter: ({ value }) => {
          const { text } = value;
          this.getElement({ name: "AppOverlayText" }).innerHTML = text;
        }
      },
      {
        name: "App$UserActivities",
        reEntryAction: "Ignore"
      },
      {
        name: "App$Apps",
        reEntryAction: "Ignore"
      }
      ],
      context,
      root: true,
      routes: [
        {
          hash: "#me",
          handle: () => this.getUserAcitivities()
        }
      ]
    });
  }

  getUserAcitivities() {
    this.execute({ batch: { descriptors: ["App$UserActivities$Enter"] } });
    
    return r8.services.user.acitivities().then(result => {
      return Promise.resolve();
    });
  }

  create({ app }) {
    return { container: app };
  }

  destroy() {
    throw "Not Implemented";
  }

  run({ handle, options }) {
    return new Promise((resolve) => {
      this.busy({ options });

      handle().then(result => {
        this.free();
        resolve(result);
      });
    });
  }

  init() {
    super.init();

    simple.List.init({
      container: this.getElement({ name: "AppMenu" }),
      template: ({ item }) => simple.Dom.evalTemplate({
        name: "App.MenuItem",
        context: item
      }),
      items: [
        { label: "Contribute", description: "Contribute Description", href: "#contribute/data" },
        { label: "Research", description: "Research Description", href: "#research" },
        { label: "Labs", description: "Labs Description", href: "#labs" }
      ]
    });

    simple.Authentication.init({
      container: this.getElement({ name: "AppAuthenticateOverlay" }),
      handle: ({ name, value, cancel }) => {
        if (cancel) {
          return simple.Application.cancel();
        }

        return this.run({
          handle: () => {
            return new Promise((resolve) => {
              const action = {
                Login: r8.services.authentication.login,
                Register: r8.services.authentication.register,
                Restore: r8.services.authentication.restore
              }[name];
              action(value).then(resolve);
            });
          },
          options: { text: "Authenticating..." }
        });
      }
    });

    const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;
    const { theme } = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

    simple.RadioList.init({
      container: this.getElement({ name: "AppTheme" }),
      items: r8.metadata.themes(),
      selectedId: theme,
      on: ({ id }) => {
        simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });

        setTheme({ theme: id });

        simple.Application.apply();
      }
    });

    setTheme({ theme });

    const authenticated = r8.services.app.authenticated();
    const descriptor = authenticated ? "App$User$Enter" : "App$User$Leave";
    this.execute({ batch: { descriptors: [descriptor], transient: true } });

    ["AppMenuLogin", "AppGuest"].forEach(name => {
      this.addEventHandles({
        name, events: "click", handle: () => {
          this.authenticate({ allowGuestLogin: false }).then(() => {
            simple.Application.apply();
          });
        }
      });
    });

    this.addEventHandles({
      name: "UserLogout", events: "click", handle: () => {
        r8.services.app.removeUser();
        this.execute({ batch: { descriptors: ["App$User$Leave"] } });
      }
    })

    this.addEventHandles({
      name: "AppUserActivities", events: "click", handle: () => {
        simple.Application.navigate({ hash: "me" });
      }
    });
  }

  authenticate({ allowGuestLogin }) {
    // pass authenticated as a parameters when do Auth.init and check that internally(?)
    if (r8.services.app.authenticated()) {
      return Promise.resolve();
    }

    this.execute({ batch: { descriptors: ["App$Authenticate$Enter"] } });

    return simple.Authentication.authenticate({
      container: this.getElement({ name: "AppAuthenticateOverlay" }),
      appState: this.context.appState,
      allowGuestLogin
    }).then(result => {
      if (result) {
        // wasn't a guest login
        const { userName, token } = result;
        r8.services.app.setUser({ user: { userName, token } });

        this.execute({ batch: { descriptors: ["App$User$Enter"], transient: true } });
      }

      simple.Application.apply();
    });
  }

  busy({ options }) {
    this.execute({ batch: { states: [{ descriptor: "App$Overlay$Enter", value: options }], transient: true } });
  }

  free() {
    this.execute({ batch: { descriptors: ["App$Overlay$Leave"], transient: true } });
  }

  export() {
    return {
      run: this.run.bind(this),
      authenticate: this.authenticate.bind(this)
    };
  }
};