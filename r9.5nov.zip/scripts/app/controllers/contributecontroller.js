const ContributeController = ({ application }) => {
    const { Element, Symbols, Browser } = Utils;

    const getData = () => Promise.resolve();

    const controller = Controller.Create({
        elements: {
        },
        states: {
        },
        application,
        routes:
            [
                {
                    hash: "#contribute", default: true, fallBack: true,
                    handle: ({ controllers }) => {
                        debugger;

                        return getData();
                    }
                    // this.GetData().then(this.SetData).then(this.execute({ batch: { descriptors: ["Chart$Enter"] } }))

                },
                {
                    hash: "#contribute/contributions",
                    handle: () => this.GetData({ providers: [r8.QuotesProvider] }).then(() => this.execute({ batch: { descriptors: ["Contributions$Enter"] } }))
                },
                {
                    hash: "#contribute/contributions/create", handle: () => {
                        this.execute({ batch: { states: [{ descriptor: "Contribution$Enter", value: { mode: "Add" } }] } });
                        return Promise.resolve();
                    }
                }
            ],
        create: container => {
            throw "Not Implmeneted";
        }
    });
    
    const proxy = new Proxy(controller, {
        get: (v1, v2) => {
            debugger;
        },
        set: (v1, v2) => {
            debugger;
        },
        apply: (v1, v2) => {
            debugger;
        }
    });

    return controller;
}