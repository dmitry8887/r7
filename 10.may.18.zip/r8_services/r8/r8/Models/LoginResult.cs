﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace r8.Models
{
  public class LoginResult
  {
    [JsonProperty(PropertyName = "success")]
    public bool Success
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "errors")]
    public List<string> Errors
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "token")]
    public string Token
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "userName")]
    public string UserName
    {
      get;
      set;
    }
  }
}