﻿r8.services = {};
r8.services.metadata = {}
r8.services.metadata.names = ()=> ["GLTZUR", "VNRODG", "DUSVJL"].map(name=>({ id: name, text: name }));

r8.services.metadata.tags = () => {
  const tags = [];
  for (let i = 0; i < 10; i++) {
    tags.push({ id: "T" + i, text: "T" + i });
  }
  return tags;
}

r8.services.contribute = {}; // RENAME
r8.services.contribute.getDefaultData = () => ({
  from: 24056640,
  to: 24145920,
  frame: 1440,
  nameIds: ["GLTZUR", "DUSVJL"],
  activeNameId: "GLTZUR",
  tagIds: ["T1", "T3"]
});
