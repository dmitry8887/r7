﻿"use strict";

r8.controllers.Contribute = class extends simple.Controller {
	get properties() {
		return {
			route: "App$Contribute",
			startup: true,
			fallback: true,
			hash: "contribute",
			name: "Contribute"
		};
	}

	constructor({ resolver }) {
		super({
      resolver,
      getContainer: ({ created, stateContainer }) => {
        if (created !== true) {
          stateContainer.querySelector("#app_view_container").innerHTML = simple.Utils.getHtmlImportText({ name: "Contribute" });
        }
        return stateContainer.querySelector("#contribute");
      },
      elements: {
        Contribute: "contribute",
				DateRange: "date_range",
				Names: "names",
				Tags: "tags",
				NamesEditorLauncher: "names_editor_launcher",
				NamesEditor: "names_editor",
				TagsEditorLauncher: "tags_editor_launcher",
				TagsEditor: "tags_editor",
				Chart: "chart",
				Contributions: "contributions",
				ContributionsFilter: "contributions_filter",
				ContributionsLauncher: "contributions_launcher",
				ContributionsSummary: "contributions_summary",
				ContributionsPanel: "contributions_panel",
				DatesEditor: "dates_editor",
				DatesEditorSlider: "dates_editor_slider",
				DatesEditorDateRange: "dates_editor_date_range",
				DatesEditorDone: "dates_editor_done",
				DataSummary: "data_summary",
				ChartZoom: "chart_zoom",
				ContributionCreate: "contribution_create",
				ContributionAdd: "contribution_add",
				ContributionNames: "contribution_names",
				ContributionTags: "contribution_tags",
				ContributionNamesEditor: "contribution_names_editor",
				ContributionTagsEditor: "contribution_tags_editor",
				ContributionNamesEditorLauncher: "contribution_names_editor_launcher",
				ContributionTagsEditorLauncher: "contribution_tags_editor_launcher",
				ContributionOverlay: "contribution_overlay",
				ContributionDateRange: "contribution_date_range",
				ContributionDatesEditorDateRange: "contribution_dates_editor_date_range",
				ContributionDatesEditor: "contribution_dates_editor",
				ContributionDatesEditorSlider: "contribution_dates_editor_slider",
				ContributionType: "contribution_type",
				ContributionPointDirection: "contribution_point_direction",
				ContributionPoint: "contribution_point",
				ContributionPointCloseMode: "contribution_point_close_mode",
				ContributionPointRiskEstimate: "contribution_point_risk_estimate",
				ContributionPointVolumeEstimate: "contribution_point_volume_estimate",
				ContributionPointLeverageEstimate: "contribution_point_leverage_estimate",
				ContributionPointAddCloseButton: "contribution_point_add_close_button",
				ContributionPointRemoveCloseButton: "contribution_point_remove_close_button",
				ContributionPointCloseRow: "contribution_point_close_row",
				ContributionPointMoreButton: "contribution_point_more_button",
				ContributionPointLessButton: "contribution_point_less_button",
				ContributionPointVolumeRow: "contribution_point_volume_row",
				ContributionPointLeverageRow: "contribution_point_leverage_row",
				ContributionDatesEditorDone: "contribution_dates_editor_done",
				DiscussionOverlay: "discussion_overlay",
				DiscussionContext: "discussion_context",
				Discussion: "discussion"
			},
			states:
			[
				{
					descriptor: "App.Contribute$NamesEditor$Enter",
					group: "Editors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "NamesEditor" }),
							items: r8.services.metadata.names(),
							selectedIds: simple.Storage.getValue({ name: "r8.storage.contribute" }).names
						});
					}
				},
				{
					descriptor: "App.Contribute$TagsEditor$Enter",
					group: "Editors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "TagsEditor" }),
							items: r8.services.metadata.tags(),
							selectedIds: simple.Storage.getValue({ name: "r8.storage.contribute" }).tags
						});
					}
				},
				{
					descriptor: "App.Contribute$DatesEditor$Enter",
					handle: ({ descriptor }) => {
						const { from, to } = simple.Storage.getValue({ name: "r8.storage.contribute" });
						simple.DateRange.setOptions({
							container: this.getElement({ name: "DatesEditorDateRange" }),
							stateContainer: this.getStateContainer(),
							descriptor,
							from,
							to
						});
					}
				},
				{
					descriptor: "App.Contribute$DatesEditor$Leave",
					handle: () => simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) })
				},
				{
					descriptor: "App.Contribute$Contribution$Enter",
					childDescriptors: ["App.Contribute$ContributionRange$Enter"],
					handle: () => {
						const { from, to, names, tags } = simple.Storage.getValue({ name: "r8.storage.contribute" });
						simple.DateRange.setOptions({
							container: this.getElement({ name: "ContributionDateRange" }),
							stateContainer: this.getStateContainer(),
							from,
							to
						});

						simple.List.setItems({
							container: this.getElement({ name: "ContributionNames" }),
							items: r8.services.metadata.names().filter(name => names.includes(name.id)),
							selectedIds: names
						});

						simple.List.setItems({
							container: this.getElement({ name: "ContributionTags" }),
							items: r8.services.metadata.tags().filter(tag => tags.includes(tag.id)),
							selectedIds: tags
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionRange$Enter",
					group: "Contribution",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Enter"],
					handle: () => simple.RadioList.setSelectedId({
						container: this.getElement({ name: "ContributionType" }),
						id: "range"
					})
				},
				{
					descriptor: "App.Contribute$ContributionPoint$Enter",
					group: "Contribution",
					childDescriptors: ["App.Contribute$ContributionPointMore$Leave", "App.Contribute$ContributionPointHasClose$Leave"],
					handle: () => {
						["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(
							name => simple.Spinner.setSelectedId({ container: this.getElement({ name }), id: "None" }));
					}
				},
				{
					descriptor: "App.Contribute$ContributionPointHasClose$Enter",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Enter"]
				},
				{
					descriptor: "App.Contribute$ContributionPointHasClose$Leave",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Leave"]
				},
				{
					descriptor: "App.Contribute$ContributionDatesEditor$Enter",
					handle: ({ descriptor }) => {
						const { from, to, hasToDate } =
							simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDateRange" }) });

						simple.DateRange.setOptions({
							container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
							stateContainer: this.getStateContainer(),
							descriptor,
							hasToDate,
							from,
							to
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionNamesEditor$Enter",
					group: "ContributionEditors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "ContributionNamesEditor" }),
							items: r8.services.metadata.names(),
							selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionNames" }) })
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionTagsEditor$Enter",
					group: "ContributionEditors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "ContributionTagsEditor" }),
							items: r8.services.metadata.tags(),
							selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionTags" }) })
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionHasToDate$Enter",
					handle: () => {
						simple.DateRange.setHasToDate({
							container: this.getElement({ name: "ContributionDateRange" }),
							stateContainer: this.getStateContainer(),
							hasToDate: true
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionHasToDate$Leave",
					handle: () => {
						simple.DateRange.setHasToDate({
							container: this.getElement({ name: "ContributionDateRange" }),
							stateContainer: this.getStateContainer(),
							hasToDate: false
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionPoint$Leave",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Leave"]
				}
			]
		});
	}

	enter() {
    if (this.initialized !== true) {
      
			const stateContainer = this.getStateContainer();

			super.init();

			const like = (/*{ originator, id }*/) => {
				debugger;
			};

			const share = (/*{ originator, id }*/) => {
				debugger;
			};
		
			simple.DateRange.init({
				container: this.getElement({ name: "DateRange" }),
				stateContainer,
				on: ({ name, descriptor }) => {
					if (name === "Activate") {
						this.executeState({
							batch: {
								states: [{ descriptor: "App.Contribute$DatesEditor$Enter", value: { descriptor } }],
								backHandleMode: "EnterOnly"
							}
						});
					}
				}
			});

			simple.DateRange.init({
				container: this.getElement({ name: "DatesEditorDateRange" }),
				stateContainer,
				getSlider: () => this.getElement({ name: "DatesEditorSlider" })
			});

      simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }), stateContainer });

			simple.List.init({
        container: this.getElement({ name: "Contributions" }),
        stateContainer,
				template: ({ item, mode }) => {
					return simple.Utils.interpolate({
						name: {
							"Range.Render": "ContributionRangeRender",
              "Range.Export": "ContributionRangeExport",
              "Point.Render": "ContributionPointRender",
              "Point.Export": "ContributionPointExport"
						}[`${item.type}.${mode}`],
						context: { item }
					});
				},
				commands:
				[
					{ name: "Like", handle: like },
					{
						name: "Discuss",
						handle: ({ /*originator,*/ id }) => {
							this.getElement({ name: "DiscussionContext" }).innerHTML =
								simple.List.exportItem({ container: this.getElement({ name: "Contributions" }), id });

							// Get data then execute state
							const request = Object.assign(simple.Data.getRequest({ container: this.getElement({ name: "Contribute" }) }),
								{ targetId: id });

							simple.Data.request({ container: this.getElement({ name: "Contribute" }), request });
						}
					},
					{ name: "Share", handle: share }
				]
			});

			simple.List.init({ container: this.getElement({ name: "ContributionNames" }), stateContainer });

			simple.List.init({ container: this.getElement({ name: "ContributionTags" }), stateContainer });

			simple.Picker.init({
				container: this.getElement({ name: "ContributionNamesEditor" }),
				stateContainer,
				on: ({ name, selectedIds }) => {
					switch (name) {
					case "Change":
						simple.List.setItems({
							container: this.getElement({ name: "ContributionNames" }),
							items: r8.services.metadata.names().filter(name => selectedIds.includes(name.id)),
							selectedIds
						});
						simple.Application.apply();
						break;
					}
				}
			});

			simple.Picker.init({
				container: this.getElement({ name: "ContributionTagsEditor" }),
				stateContainer,
				on: ({ name, selectedIds }) => {
					switch (name) {
					case "Change":
						simple.List.setItems({
							container: this.getElement({ name: "ContributionTags" }),
							items: r8.services.metadata.tags().filter(name => selectedIds.includes(name.id)),
							selectedIds: selectedIds
						});
						simple.Application.apply();
						break;
					}
				}
			});

			simple.DateRange.init({
				container: this.getElement({ name: "ContributionDateRange" }),
				stateContainer,
				on: ({ name, descriptor }) => {
					if (name === "Activate") {
						this.executeState({
							batch: {
								states: [{ descriptor: "App.Contribute$ContributionDatesEditor$Enter", value: { descriptor } }],
								backHandleMode: "All"
							}
						});
					}
				}
			});

			simple.Slider.init({ container: this.getElement({ name: "ContributionDatesEditorSlider" }), stateContainer });

			simple.DateRange.init({
				container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
				stateContainer,
				getSlider: () => this.getElement({ name: "ContributionDatesEditorSlider" })
			});

			simple.RadioList.init({
				container: this.getElement({ name: "ContributionType" }),
				items: r8.services.metadata.contributionTypes(),
				selectedId: "range",
				on: ({ name, id, manual }) => {
					const descriptor = {
						range: "App.Contribute$ContributionRange$Enter",
						point: "App.Contribute$ContributionPoint$Enter"
					}[id];

					switch (name) {
					case "Select":
						if (!descriptor) {
							throw `Invalid Contribution Type: '${id}'`;
						}
						this.executeState({ batch: { descriptors: [descriptor] } });
						break;
					default:
						throw `Invalid Command: '${name}'`;
					}
				}
			});

			simple.RadioList.init({
				container: this.getElement({ name: "ContributionPointDirection" }),
				items: r8.services.metadata.contributionPointDirections(),
				selectedId: "b"
			});

			simple.RadioList.init({
				container: this.getElement({ name: "ContributionPointCloseMode" }),
				items: r8.services.metadata.contributionPointCloseModes(),
				selectedId: "manual"
			});

			["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(
				name => simple.Spinner.init({ container: this.getElement({ name }), items: r8.services.metadata.estimates() }));

			simple.Discussion.init({
				container: this.getElement({ name: "Discussion" }),
				stateContainer,
				template: ({ item, mode }) => {
					const name = {
						"Post.Render": "DiscussionPostRender",
            "Post.Export": "DiscussionPostExport"
					}[`Post.${mode}`];

					return simple.Utils.interpolate({ name, context: { item } });
				},
				commands:
				[
					{ name: "Like", handle: like }
				],
				indent: 30,
				on: ({ name, value }) => {
					switch (name) {
					case "PostAdd":
						//var post = value;
						debugger;

						break;
					}
				}
			});

			// TODO: change to use then instead of on, as on'd force handling in one place (?)
			simple.Data.init({
				container: this.getElement({ name: "Contribute" }),
				providers: [r8.providers.quotes, r8.providers.contributions, r8.providers.posts],
				on: ({ data, request }) => {
					const { left, right } = data;
					simple.Data.renderSummary({ container: this.getElement({ name: "DataSummary" }), left, right });

					const quotes = data[r8.providers.quotes.name];
					if (quotes) {
						simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
					}

					const contributions = data[r8.providers.contributions.name];
					if (contributions) {
						simple.List.setItems({ container: this.getElement({ name: "Contributions" }), items: contributions });
					}

					const posts = data[r8.providers.posts.name];
					if (posts && request.targetId) {
						simple.Discussion.setItems({ container: this.getElement({ name: "Discussion" }), items: posts });

						this.executeState({ batch: { descriptors: ["App.Contribute$Discussion$Enter"], backHandleMode: "EnterOnly" } });
					}
				}
			});

			const loadState = () => {
				const stateContainer = this.getStateContainer();

				const state = simple.Storage.getValue({
					name: "r8.storage.contribute",
					defaultValue: r8.services.contribute.getDefaultData()
				});

				simple.List.setItems({
					container: this.getElement({ name: "Names" }),
					items: r8.services.metadata.names().filter(name => state.names.includes(name.id)),
					selectedIds: [state.activeName]
				});

				simple.List.setItems({
					container: this.getElement({ name: "Tags" }),
					items: r8.services.metadata.tags().filter(tag => state.tags.includes(tag.id)),
					selectedIds: state.tags
				});

				simple.DateRange.setOptions({
					container: this.getElement({ name: "DateRange" }),
					stateContainer,
					from: state.from,
					to: state.to
        });

			  simple.Data.request({ container: this.getElement({ name: "Contribute" }), request: state }).then(
			    ({ data, request, padding }) => {
			      debugger;
			    });
			};

			simple.Chart.init({
				container: this.getElement({ name: "Chart" }),
				stateContainer,
				bands: [r8.bands.weekDays],
				on: ({ name, value }) => {
					const $contribute = this.getElement({ name: "Contribute" });
					const from = value ? value.from : null;
					const to = value ? value.to : null;

					switch (name) {
					case "Drag":
						simple.Data.request({
							container: $contribute,
							request: Object.assign(simple.Data.getRequest({ container: $contribute }), { from, to })
						});

						break;
					case "DragStop":
						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								value.from = from;
								value.to = to;
								return value;
							}
						});

						loadState();

						break;
					}
				}
			});

			simple.Picker.init({
				container: this.getElement({ name: "TagsEditor" }),
				stateContainer,
				on:  ({ selectedIds }) => {
					simple.Storage.setValue({
						name: "r8.storage.contribute",
						mutator: (value) => {
							value.tags = selectedIds;
							return value;
						}
					});

					simple.Application.apply();
					loadState();
				}
			});

			simple.List.init({
				container: this.getElement({ name: "Tags" }),
				stateContainer,
				on: ({ ids, selectedIds, name }) => {
					switch (name) {
					case "Change":
						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								value.tags = ids;
								return value;
							}
						});

						loadState();

						break;
					default:
						throw `Invalid Event:${name}`;
					}
				}
			});

			simple.Picker.init({
				container: this.getElement({ name: "NamesEditor" }),
				stateContainer,
				on:  ({ selectedIds }) => {
					simple.Storage.setValue({
						name: "r8.storage.contribute",
						mutator: (value) => {
							const names = selectedIds;
							let activeName = value.activeName;
							if (!names.includes(activeName)) {
								activeName = names[0];
							}
							value.names = names;
							value.activeName = activeName;
							return value;
						}
					});

					simple.Application.apply();
					loadState();
				}
			});

			simple.List.init({
				container: this.getElement({ name: "Names" }),
				stateContainer,
				on: ({ ids, selectedIds, name }) => {
					switch (name) {
					case "Change":
					case "Select":
						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								value.names = ids;
								value.activeName = selectedIds[0];
								return value;
							}
						});

						loadState();

						break;
					default:
						throw `Invalid Event:${name}`;
					}
				}
			});

			this.addEventsHandle({
				name: "ContributionDatesEditorDone",
				events: "click",
				handle: () => {
					const { from, to } =
						simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDatesEditorDateRange" }) });
					simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDatesRange" }, from, to) });
				}
			});

			this.addEventsHandle({
				name: "DatesEditorDone",
				events: "click",
				handle: () => {
					const { from, to } = simple.DateRange.getOptions({ container: this.getElement({ name: "DatesEditorDateRange" }) });

					simple.Storage.setValue({
						name: "r8.storage.contribute",
						mutator: (value) => {
							value.from = from;
							value.to = to;
							return value;
						}
					});

					simple.Application.apply();
					loadState();
				}});

			this.addEventsHandle({
				name: "ContributionAdd",
				events: "click",
				handle: () => {
					const app = simple.Application.getController({ container: stateContainer, name: "App" });
          app.authenticate({ allowGuestLogin: true }).then(() => {
            alert("do!");
          });
				}
			});

			loadState();
			this.initialized = true;
		}
	}

	leave() {
	}
}