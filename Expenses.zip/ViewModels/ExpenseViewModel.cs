﻿using System;
using System.Linq;
using BookKeeper.Models;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using BookKeeper.Annotations;
using BookKeeper.Services;
using System.Collections.Generic;
// ReSharper disable ExplicitCallerInfoArgument
// ReSharper disable MemberCanBePrivate.Global

namespace BookKeeper.ViewModels
{
    public class ExpenseViewModel : INotifyPropertyChanged
    {
        public ExpenseViewModel(AppViewModel expenseApp)
        {
            App = expenseApp;
        }

        public ExpenseViewModel(AppViewModel expenseApp, Expense expense) : this(expenseApp)
        {
            Date = expense.Date;
            CategoryId = expense.CategoryId;
            CategoryName = expenseApp.Categories.First(t => t.Id == CategoryId).Name;
            Amount = expense.Amount;
        }

        // ReSharper disable once MemberCanBePrivate.Global
        public AppViewModel App
        {
            // ReSharper disable once UnusedAutoPropertyAccessor.Global
            get;
            private set;
        }

        private DateTime? _date;
        public DateTime? Date
        {
            get
            {
                return _date;
            }
            // ReSharper disable once MemberCanBePrivate.Global
            set
            {
                _date = value;
                // ReSharper disable once ExplicitCallerInfoArgument
                OnPropertyChanged(nameof(Date));
            }
        }

        private decimal _amount;
        public decimal Amount
        {
            get
            {
                return _amount;
            }
            set
            {
                _amount = value;
                OnPropertyChanged(nameof(Amount));
            }
        }

        private int _categoryId;
        public int CategoryId
        {
            get { return _categoryId; }
            set
            {
                _categoryId = value;
                OnPropertyChanged(nameof(CategoryId));
            }
        }

        public string CategoryName
        {
            get; }

        public string GroupDescription
        {
            get; set;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }


        private bool _isVisible;
        public bool IsVisible
        {
            get { return _isVisible; }
            set
            {
                _isVisible = value;

                OnPropertyChanged(nameof(IsVisible));
            }
        }

        internal void Reset()
        {
            Errors = new List<string>();
            HasErrors = false;

            CategoryId = 0;
            Date = DateTime.Today;
            Amount = 0;
        }

        internal bool TryAdd()
        {
            List<string> errors;

            Validate(out errors);

            if (!HasErrors)
            {
                if (Date != null)
                    new DbService().AddExpense(new Expense()
                    {
                        UserId = 1,
                        CategoryId = CategoryId,
                        Amount = Amount,
                        Date = Date.Value
                    });
            }

            return !HasErrors;
        }

        internal void Validate(out List<string> errors)
        {
            errors = new List<string>();

            if (!Date.HasValue)
            {
                errors.Add("Please Select Date.");
            }

            if (CategoryId < 1)
            {
                errors.Add("Please Select Category.");
            }

            if (Amount <= 0 ||
                Amount > 999)
            {
                errors.Add("Amount Must be a numeric value less than 1,000.");
            }

            Errors = errors;
            HasErrors = errors.Count > 0;
        }


        private bool _hasErrors;
        public bool HasErrors
        {
            get { return _hasErrors; }
            set
            {
                _hasErrors = value;
                OnPropertyChanged(nameof(HasErrors));
            }
        }

        private List<string> _errors;
        public List<string> Errors
        {
            get { return _errors; }
            set
            {
                _errors = value;
                OnPropertyChanged(nameof(Errors));
            }
        }
    }

    public class GroupDescription
    {
        public string CategoryName { get; set; }
        public string MonthYear { get; set; }
        public decimal Total { get; set; }
    }
}
