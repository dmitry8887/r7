﻿"use strict";

// todo: disable script while it's running
var fxrig = fxrig || {};
fxrig.controllers = fxrig.controllers || {};
fxrig.controllers.app = fxrig.controllers.app || {};

fxrig.controllers.app.labs = new function () {
    this.hash = "labs";
    this.url = "html/views/labs.html";
    this.route = "app$app.labs";

    var self = {

    };

    this.enter = function (context) {
        console.info("entering fxrig.controllers.app.labs");

        return new window.Promise(function (resolve, reject) {
            resolve(context);
        });
    };

    this.leave = function (context) {
        console.info("leaving fxrig.controllers.app.labs");
        
        return new window.Promise(function (resolve, reject) {
            resolve(context);
        });
    };

    // todo: research
    this.defaultState = function () {
    };
};