﻿r8.services = {};
r8.services.metadata = {}

r8.services.metadata.names = ["GLTZUR", "VNRODG", "DUSVJL"].map(name=>({ id: name, text: name }));
