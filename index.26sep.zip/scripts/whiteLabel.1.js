// scope

const whiteLabel = () => {
    const self = {};

    self.Symbols = {
        path: Symbol("path"),
        getParent: Symbol("getParent")
    };

    self.Object = {};

    self.Object.is = target => {
        const type = typeof target;
        const [isObject, isSymbol, isFunction, isString, isNumber, isArray = isObject && Array.isArray(target)] = ["object", "symbol", "function", "string", "number"].map(typeName => typeName === type);
        const isPrimitive = isString || isNumber;

        return { isObject, isSymbol, isFunction, isString, isNumber, isArray, isPrimitive };
    };

    self.Object.getPath = ({ target, key }) => [target[self.Symbols.path], key].filter(path => path !== undefined).join(".");

    self.Object.import = ({ target, key, path = $.Object.getPath({ target, key }), value }) =>
        Object.assign(value, {
            [self.Symbols.path]: path,
            [self.Symbols.getParent]: () => target
        });

    // TODO: remove, manage via scope
    self.Object.trace = ({ target, scope }) => {
        const trace = [];

        while (target !== scope) {
            trace.push(target);
            target = target[$.Symbols.getParent]();
        }

        return trace;
    };

    self.Object.wrap = ({ target, handler, isBound, allowDynamicProperties }) => {
        const getPathValuePairs = target => {
            const pathValuePairs = [];

            const process = target => {
                Object.entries(target).forEach(([key, value]) => {
                    const { isObject } = self.Object.is(value);
                    const path = self.Object.getPath({ target, key });

                    if (isObject) {
                        value = self.Object.import({ target, path, value });
                    }

                    pathValuePairs.push({ path, value });

                    if (isObject) {
                        process(value);
                    }
                });
            };

            process(target);

            return pathValuePairs;
        }

        const getInternalHandler = scope => ({
            get: (target, key) => {
                let value = target[key];

                if (!value) {
                    if (!allowDynamicProperties) {
                        throw "Invalid Operation";
                    }

                    value = self.Object.import({ target, key, value: {} }); // TODO: implement [] | {} selection
                    target[key] = value;
                }

                if (self.Object.is(value).isObject === true) {
                    let path = self.Object.getPath({ target, key });

                    if (isBound(path)) {
                        scope = target[key];
                    }
                    else if (self.Object.is(target).isArray === true) {
                        path = self.Object.getPath({ target });
                        if (isBound(path)) {

                            debugger;
                            scope = target[key];
                        }
                    }

                    value = new Proxy(value, getInternalHandler(scope));
                }

                return value;
            },
            set: (target, key, value) => {
                const originalPath = self.Object.getPath({ target, key });
                const path = self.Object.getPath({ target: scope });

                if (self.Object.is(value).isObject === true) {

                    value = self.Object.unwrap(value);
                    value = self.Object.import({ target, path: originalPath, value: self.Object.unwrap(value) })
                }

                target[key] = value;

                const { isArray: isScopeArray } = $.Object.is(scope);

                const isElevated = target !== scope;
                const originalValue = value;

                if (isScopeArray) {
                    if (isElevated || (!isElevated && key === "length")) {
                        if (isElevated) {
                            const trace = $.Object.trace({ target, scope });
                            value = trace[trace.length - 1];
                        }
                        else {
                            value = self.Object.unwrap(scope);
                        }

                        handler({ isInitial: false, path, originalPath, value, originalValue });
                    }
                }
                else {
                    // TODO: only report bound paths
                    handler({ isInitial: false, path, originalPath, value, originalValue });
                }

                return true;
            }
        });

        getPathValuePairs(target).forEach(({ path, value }) => {
            if (isBound(path)) {
                handler({ isInitial: true, originalPath: path, path, originalValue: value, value });
            }
        });

        return new Proxy(target, getInternalHandler(target));
    };

    self.Object.unwrap = proxy => {
        const target = {};

        const unwrap = ({ proxy, target }) => {
            if (!proxy) {
                debugger;
            }

            Object.entries(proxy).forEach(([key, value]) => {
                const { isObject, isArray } = self.Object.is(value);
                if (isObject) {
                    target[key] = isArray ? [] : {};

                    unwrap({ proxy: value, target: target[key] });
                }
                else {
                    target[key] = value;
                }
            });

        };

        unwrap({ proxy, target });

        return target;
    };

    self.Element = {};

    self.Element.init = (element) => {
        debugger;
    };

    return self;
};