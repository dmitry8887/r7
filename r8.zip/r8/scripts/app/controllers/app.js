﻿"use strict";

r8.controllers.App = class extends simple.Stateful {
    get routing() {
        return { route: "App" };
    }

    get container() {
        return this._container;
    }

    constructor({ container }) {
        super({
            ownedElements:
            [
                "app_overlay", 
                "app_overlay_message", 
                "app_overlay_error_message", 
                "app_menu", "app_menu_overlay",
                "app_apps_overlay", "user_name", 
                "app_menu_user_name", 
                "app_login_overlay", 
                "app_menu_login", 
                "app_user",
                "app_menu_launcher", 
                "app_view_header", 
                "app_apps_back", 
                "app_apps_launcher", 
                "app_menu_back", 
                "app_menu_logout"
            ],
            states:
                [
                    { descriptor: "App$Menu$Enter", handle: () => { } },
                    { descriptor: "App$Menu$Leave", handle: () => { } },
                    { descriptor: "App$Apps$Enter", handle: () => { } },
                    { descriptor: "App$Apps$Leave", handle: () => { } },
                    { descriptor: "App$Message$Enter", handle: ({ text }) => { elements.$appMessage().html(text || "Loading..."); } },
                    { descriptor: "App$Message$Leave", handle: () => { } },
                    { descriptor: "App$Error$Enter", handle: ({ text }) => { elements.$appErrorMessage().html(text || "Error."); } },
                    { descriptor: "App$Error$Leave", handle: () => { } },
                    {
                        descriptor: "App$User$Enter",
                        handle: () => {
                            const userName = r7.app.controllers.app.getUser().userName;

                            elements.$userName().text(userName);
                            elements.$appMenuUserName().text(userName);
                        }
                    },
                    {
                        descriptor: "App$User$Leave",
                        handle: () => {
                            elements.$userName().text(guestUserName);
                            elements.$appMenuUserName().text(guestUserName);
                            r7.app.controllers.app.logout();
                        }
                    },
                    { descriptor: "App$Authenticate$Enter", handle: () => { } },
                    { descriptor: "App$Authenticate$Leave", handle: () => { } }
                ]
        });

        this._container = container;
    }

    enter({ transition }) {
       

        debugger;

        if (this.initialized !== true) {
            this.init({ container: this.container });

            this.initialized = true;
        }
        

        //console.warn(transition);
    }

    leave({ transition }) {
        //console.warn(transition);
    };
};