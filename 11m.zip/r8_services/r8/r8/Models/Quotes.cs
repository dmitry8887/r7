﻿using System.Collections.Generic;
using Newtonsoft.Json;

namespace r8.Models
{
  public class QuotesResult : List<PointSet>
  {
  }

  public class PointSet
  {
    public PointSet(List<Point> points, string name)
    {
      Points = points;
      Name = name;
    }

    [JsonProperty(PropertyName = "name")]
    public string Name { get; set; }

    [JsonProperty(PropertyName = "points")]
    public List<Point> Points { get; set; }
  }

  public class Point
  {
    [JsonProperty(PropertyName = "o")]
    public int O { get; set; }

    [JsonProperty(PropertyName = "m")]
    public decimal M { get; set; }
  }
}