﻿"use strict";
// remove "App$Overlay$Enter" calls (? or resolve dedicated states in code?)
r8.controllers.App = class extends simple.Controller {
	get properties() {
		return { route: "App", name: "App" };
	}

	constructor({ resolver }) {
		super({
			resolver,
			create: ({ appContainer }) => appContainer,
			elements:
				{
					AppOverlay: "app_overlay",
					//AppOverlayMessage: "app_overlay_message",
					//AppOverlayErrorMessage: "app_overlay_error_message",
					AppMenu: "app_menu",
					AppMenuOverlay: "app_menu_overlay",
					AppAppsOverlay: "app_apps_overlay",
					UserName: "user_name",
					AppMenuUserName: "app_menu_user_name",
					AppAuthenticateOverlay: "app_authenticate_overlay",
					AppMenuLogin: "app_menu_login",
					AppMenuLogout: "app_menu_logout",
					AppUser: "app_user",
					AppMenuLauncher: "app_menu_launcher",
					AppViewHeader: "app_view_header",
					AppAppsBack: "app_apps_back",
					AppAppsLauncher: "app_apps_launcher",
					AppMenuBack: "app_menu_back",
					AppTheme: "app_theme"
				},
			states:
				[
					{
						descriptor: "App$User$Enter",
						handle: () => {
							const { userName } = r8.services.app.getUser();
							["UserName", "AppMenuUserName"].forEach(name => {
								this.getElement({ name }).innerHTML = userName;
							});
						}
					},
					{
						descriptor: "App$User$Leave",
						handle: () => {
							["UserName", "AppMenuUserName"].forEach(name => {
								this.getElement({ name }).innerHTML = "Guest";
							});
						}
					}
				]
		});
	}

	enter( /*{ from, to }*/) {
		if (this.initialized !== true) {
			this.init();

			const appContainer = this.getAppContainer();

			const state = simple.Storage.getValue({
				path: "r8",
				defaultValue: r8.services.app.getDefaultState()
			});

			simple.List.init({
				container: this.getElement({ name: "AppMenu" }),
				appContainer,
				template: ({ item }) => simple.Utils.interpolate({ name: "App.MenuItem", context: item }),
				items: [
					{ label: "Contribute", description: "Contribute Description", href: "#contribute" },
					{ label: "Research", description: "Research Description", href: "#research" },
					{ label: "Labs", description: "Labs Description", href: "#labs" }
				]
			});

			simple.Authentication.init({
				container: this.getElement({ name: "AppAuthenticateOverlay" }),
				appContainer,
				handle: ({ name, value }) => {
					const { action, text } = {
						Login: { action: r8.services.authentication.login, text: "Logging In..." },
						Register: { action: r8.services.authentication.register, text: "Registering..." },
						Restore: { action: r8.services.authentication.restore, text: "Restoring..." }
					}[name];

					this.busy({ text });

					return action(value).then(({ value }) => {
						this.free();
						return value;
					});
				}
			});

			const setTheme = ({ theme }) => {
				const name = {
					dark: "dark",
					light: "light"
				}[theme];
				document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${name}.css`;
			};

			simple.RadioList.init({
				container: this.getElement({ name: "AppTheme" }),
				items: r8.services.metadata.themes(),
				selectedId: state.theme,
				on: ({ id, manual }) => {
					simple.Storage.setValue({
						path: "r8",
						mutator: (value) => {
							value.theme = id;
							return value;
						}
					});

					setTheme({ theme: id });
					simple.Application.apply();
				}
			});

			setTheme({ theme: state.theme });

			const authenticated = r8.services.app.authenticated();
			const batch = (authenticated)
				? { descriptors: ["App$User$Enter"] }
				: { descriptors: ["App$User$Leave"] };

			this.executeState({ batch });

			this.addEventHandles({
				name: "AppMenuLogin",
				events: "click",
				handle: () => {
					this.authenticate({ allowGuestLogin: false }).then(() => {
						debugger;
						alert("1");
					});
				}
			});

			this.addEventHandles({
				name: "AppMenuLogout",
				events: "click",
				handle: () => {
					r8.services.app.removeUser();
					this.executeState({ batch: { descriptors: ["App$User$Leave"] } });
				}
			});

			this.initialized = true;
		}
	}

	authenticate({ allowGuestLogin }) {
		this.executeState({ batch: { descriptors: ["App$Authenticate$Enter"], backableDirections: "Enter" } });

		return simple.Authentication.authenticate({
			container: this.getElement({ name: "AppAuthenticateOverlay" }),
			appContainer: this.getAppContainer(),
			allowGuestLogin
		}).then((result) => {
			const { action } = result;

			switch (action) {
				case "Continue":
					const { userName, token } = result;
					r8.services.app.setUser({ user: { userName, token } });
					this.executeState({ batch: { descriptors: ["App$User$Enter"] } });
					break;
				case "ContinueAsGuest":
					result.action = "Continue";
					break;
			}

			if (result.action === "Exit") {
				simple.Application.cancel();
			}
			else {
				simple.Application.apply();
			}

			return result;
		});
	}

	busy() {
		this.executeState({ batch: { descriptors: ["App$Overlay$Enter"] } });
	}

	free() {
		this.executeState({ batch: { descriptors: ["App$Overlay$Leave"] } });
	}

	leave( /*{ from, to }*/) {
	}
}