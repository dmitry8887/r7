﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace r8.Controllers
{
    public static class Utils
    {
        public static string GenerateInsertSql(string tableName, IEnumerable<string> fieldNames)
        {
            var names = fieldNames as string[] ?? fieldNames.ToArray();

            var fieldNamesString = names.Select(name => $"[{name}]").Aggregate((f, s) => f + "," + s);
            var fieldValuesString = names.Select(name => $"@{name}").Aggregate((f, s) => f + "," + s);

            string sql = $"insert into {tableName} ({fieldNamesString}) values ({fieldValuesString}); select cast(SCOPE_IDENTITY() as int)";

            return sql;
        }

        public static string GenerateUpdateSql(string tableName, IEnumerable<string> fieldNames)
        {
            Debugger.Break();

            var names = fieldNames as string[] ?? fieldNames.ToArray();

            var fieldSetsString = names.Select(name => $"[{name}] = @{name}").Aggregate((f, s) => f + "," + s);

            string sql = $"update {tableName} set {fieldSetsString} where [Id] = @Id; select cast(@@ROWCOUNT as int)";

            return sql;
        }

        public static string GenerateDeleteSql(string tableName)
        {
            return $"delete from {tableName} where Id = @id";
        }

        public static bool TryGetAuthorizationToken(HttpRequestMessage requestMessage, out string token)
        {
            var authorizationHeader = requestMessage.Headers.Authorization;
            token = null;

            if (authorizationHeader != null)
            {
                token = authorizationHeader.Scheme;

                if (token == "null")
                {
                    token = null;
                }
            }

            return !string.IsNullOrEmpty(token);
        }

        public static string GetCallerIp()
        {
            var current = HttpContext.Current;
            string ip = null;

            if (current != null && !current.Request.IsLocal)
            {
                ip = HttpContext.Current.Request.UserHostAddress;
            }

            return ip;
        }
    }
}