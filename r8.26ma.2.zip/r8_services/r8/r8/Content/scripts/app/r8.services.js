﻿r8.services.href = "http://localhost:50034/Api/";

r8.services.authentication = {};

r8.services.authentication.register = (data) => simple.Ajax.post({ url: r8.services.href + "register", data });

r8.services.authentication.login = (data) => simple.Ajax.post({ url: r8.services.href + "login", data });

r8.services.authentication.restore = (data) => simple.Ajax.post({ url: r8.services.href + "restore", data });

r8.services.quotes = {};

r8.services.quotes.get = ({ from, to, names, frame }) => simple.Ajax.get({
	url: r8.services.href + `quotes?names=${names}&from=${from}&to=${to}&frame=${frame}`,
	name: "Quotes"
}).then(result => result.value);

r8.services.contributions = {};

r8.services.contributions.add = (data) => simple.Ajax.post({ url: r8.services.href + "contributions/", data });

r8.services.contributions.get = () => {
	return new window.Promise((resolve) => {
		const data = [];
		resolve([]);
	});
}

r8.services.posts = {};

r8.services.posts.get = () => {
	return new window.Promise((resolve) => {
		const data = [];
		setTimeout(() => { resolve(data); }, 0);
	});
};

// app
r8.services.app = {};

r8.services.app.getDefaultState = () => ({
	contribute: {
		from: 24582240,
		to: 24671520,
		frame: 1440,
		names: ["GLTZUR*", "DUSVJL"],
		tags: ["T1", "T3"]
	},
	theme: "dark"
});

r8.services.app.authenticated = () => localStorage["user"] !== undefined;

r8.services.app.setUser = ({ user }) => localStorage["user"] = JSON.stringify(user);

r8.services.app.removeUser = () => localStorage.removeItem("user");

r8.services.app.getUser = () => JSON.parse(localStorage["user"]);