﻿"use strict";

r8.controllers.Labs = class extends simple.Component {
  constructor() {
    super({ elements: {}, states: [] });
  }

  create() {
    if (!this.initialized) {
      this.init();
    }
  }
};