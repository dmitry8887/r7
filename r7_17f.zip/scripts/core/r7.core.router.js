﻿"use strict";

var r7 = r7 || {};
r7.core = r7.core || {};

r7.core.router = new function () {
    var getController = function(e) {
        var hash = e.hash.replace("#", ""), route = e.route;
        var state = e.state || e.container.state;

        var controller;

        if (hash) {
            controller = _.find(state.controllers, function(c) { return c.hash === hash; });
        } else {
            controller = _.find(state.controllers, function(c) { return c.route === route; });
        }

        return controller || _.find(state.controllers, function(c) { return c.hash === state.defaultHash; });;
    };

    var getTransitions = function (e) {
        var fromNames = e.fromRoute ? e.fromRoute.split("$") : [], toNames = e.toRoute.split("$");

        var transitions = [];

        var i, j = -1;
        var fromName, toName;

        for (i = fromNames.length - 1; i > 0; i--) {

            if (fromNames[i] === toNames[i]) {
                j = i;
                break;
            }

            fromName = fromNames[i];
            toName = fromNames[i - 1];

            transitions.push({ from: fromName, to: toName, direction: "Leave" });
            transitions.push({ from: fromName, to: toName, direction: "Enter" });
        }

        for (i = i; i < toNames.length - 1; i++) {
            fromName = toNames[i];
            toName = toNames[i + 1];

            if (fromName) {
                transitions.push({ from: fromName, to: toName, direction: "Leave" });
            }

            transitions.push({ from: fromName, to: toName, direction: "Enter" });
        }

        return transitions;
    };

    this.navigate = function (navigateArgs) {
        var $container = navigateArgs.container;
        var state = $container.state();
        var toRouteController = utils.getController(navigateArgs);
        var fromRoute = state.route;
        var toRoute = toRouteController.route;
        var context = navigateArgs.context;

        var transitions = getTransitions({ fromRoute: fromRoute, toRoute: toRoute });

        state.predict({ from: utils.getName({ route: fromRoute || "" }), to: utils.getName({ route: toRoute }) });

        var chain = window.Promise.resolve(context);

        for (var i = 0; i < transitions.length; i++) {
            var transition = transitions[i];
            var promise;

            if (transition.direction === "Leave") {
                promise = getController({ name: transition.from, container: $container }).leave;
            } else {
                promise = getController({ name: transition.to, container: $container }).enter;
            }

            promise = promise.bind(transition);

            chain = chain.then(promise);
        }

        chain.then(function () {
            location.hash = toRouteController.hash;
            state.route = toRoute;

            var success = state.success;
            if (success) {
                success({ from: utils.getName({ route: fromRoute || "" }), to: utils.getName({ route: toRoute }) });
            }
        }).catch(function (e) {
            var error = state.error;
            if (error) {
                error(e);
            }
        });
    };

    this.init = function (initArgs) {
        var $container = initArgs.container;

        var state = $container.state(initArgs);
        var appName = initArgs.appName;

        var hash = state.hash || state.hash;

        for (var i = 0; i < state.controllers.length; i++) {
            state.controllers[i].appName = appName;
        }

        var navigate = function(hash) {
            r7.core.router.navigate({ container: $container, hash: hash });
        };

        $(window).on("hashchange", function() {
            navigate(location.hash);
        });

        navigate(hash);
    };
};