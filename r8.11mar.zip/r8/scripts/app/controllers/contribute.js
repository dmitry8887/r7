﻿"use strict";

r8.controllers.Contribute = class extends simple.Controller {
  get properties() {
    return {
      route: "App$Contribute",
      startup: true,
      fallback: true,
      hash: "contribute",
      name: "Contribute"
    };
  }

  constructor({ resolver }) {
    super({
      resolver,
      create: ({ appContainer }) => {
        appContainer.querySelector("#app_view_container").innerHTML =
          simple.Utils.getHtmlImportText({ name: "Contribute" });
        return appContainer.querySelector("#contribute");
      },
      elements: {
        Contribute: "contribute",
        DateRange: "date_range",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor",
        Chart: "chart",
        Contributions: "contributions",
        ContributionsFilter: "contributions_filter",
        ContributionsLauncher: "contributions_launcher",
        ContributionsSummary: "contributions_summary",
        ContributionsPanel: "contributions_panel",
        DatesEditor: "dates_editor",
        DatesEditorSlider: "dates_editor_slider",
        DatesEditorDateRange: "dates_editor_date_range",
        DatesEditorDone: "dates_editor_done",
        DataPadding: "data_padding",
        DataZoom: "data_zoom",
        ContributionCreate: "contribution_create",
        ContributionAdd: "contribution_add",
        ContributionNames: "contribution_names",
        ContributionTags: "contribution_tags",
        ContributionNamesEditor: "contribution_names_editor",
        ContributionTagsEditor: "contribution_tags_editor",
        ContributionNamesEditorLauncher: "contribution_names_editor_launcher",
        ContributionTagsEditorLauncher: "contribution_tags_editor_launcher",
        ContributionOverlay: "contribution_overlay",
        ContributionDateRange: "contribution_date_range",
        ContributionDatesEditorDateRange: "contribution_dates_editor_date_range",
        ContributionDatesEditor: "contribution_dates_editor",
        ContributionDatesEditorSlider: "contribution_dates_editor_slider",
        ContributionType: "contribution_type",
        ContributionPointDirection: "contribution_point_direction",
        ContributionPoint: "contribution_point",
        ContributionPointCloseMode: "contribution_point_close_mode",
        ContributionPointRiskEstimate: "contribution_point_risk_estimate",
        ContributionPointVolumeEstimate: "contribution_point_volume_estimate",
        ContributionPointLeverageEstimate: "contribution_point_leverage_estimate",
        ContributionPointAddCloseButton: "contribution_point_add_close_button",
        ContributionPointRemoveCloseButton: "contribution_point_remove_close_button",
        ContributionPointCloseRow: "contribution_point_close_row",
        ContributionPointMoreButton: "contribution_point_more_button",
        ContributionPointLessButton: "contribution_point_less_button",
        ContributionPointVolumeRow: "contribution_point_volume_row",
        ContributionPointLeverageRow: "contribution_point_leverage_row",
        ContributionDatesEditorDone: "contribution_dates_editor_done",
        DiscussionOverlay: "discussion_overlay",
        DiscussionContext: "discussion_context",
        Discussion: "discussion"
      },
      states:
      [
        {
          descriptor: "Contribute$NamesEditor$Enter",
          group: "Editors",
          handle: () => {
            simple.Picker.setItems({
              container: this.getElement({ name: "NamesEditor" }),
              items: r8.services.metadata.names(),
              selectedIds: simple.List.selectedIds
                .parse({ ids: simple.Storage.getValue({ path: "r8.contribute" }).names }).ids
            });
          }
        },
        {
          descriptor: "Contribute$TagsEditor$Enter",
          group: "Editors",
          handle: () => {
            simple.Picker.setItems({
              container: this.getElement({ name: "TagsEditor" }),
              items: r8.services.metadata.tags(),
              selectedIds: simple.Storage.getValue({ path: "r8.contribute" }).tags
            });
          }
        },
        {
          descriptor: "Contribute$DatesEditor$Enter",
          handle: ({ descriptor }) => {
            const { from, to } = simple.Storage.getValue({ path: "r8.contribute" });
            simple.DateRange.setOptions({
              container: this.getElement({ name: "DatesEditorDateRange" }),
              appContainer: this.getAppContainer(),
              descriptor,
              from,
              to
            });
          }
        },
        {
          descriptor: "Contribute$DatesEditor$Leave",
          handle: () => simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) })
        },
        {
          descriptor: "Contribute$Contribution$Enter",
          childDescriptors: ["Contribute$ContributionRange$Enter"],
          handle: () => {
            const { from, to, names, tags } = simple.Storage.getValue({ path: "r8.contribute" });
            simple.DateRange.setOptions({
              container: this.getElement({ name: "ContributionDateRange" }),
              appContainer: this.getAppContainer(),
              from,
              to
            });

            const { ids } = simple.List.selectedIds.parse({ ids: names });
            simple.List.setItems({
              container: this.getElement({ name: "ContributionNames" }),
              items: r8.services.metadata.names().filter(name => ids.includes(name.id)),
              selectedIds: ids
            });

            simple.List.setItems({
              container: this.getElement({ name: "ContributionTags" }),
              items: r8.services.metadata.tags().filter(tag => tags.includes(tag.id)),
              selectedIds: tags
            });
          }
        },
        {
          descriptor: "Contribute$ContributionRange$Enter",
          group: "Contribution",
          childDescriptors: ["Contribute$ContributionHasToDate$Enter"],
          handle: () => simple.RadioList.setSelectedId({
            container: this.getElement({ name: "ContributionType" }),
            id: "range"
          })
        },
        {
          descriptor: "Contribute$ContributionPoint$Enter",
          group: "Contribution",
          childDescriptors: ["Contribute$ContributionPointMore$Leave", "Contribute$ContributionPointHasClose$Leave"],
          handle: () => {
            ["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"]
              .forEach(
                name => simple.Spinner.setSelectedId({ container: this.getElement({ name }), id: "None" }));
          }
        },
        {
          descriptor: "Contribute$ContributionPointHasClose$Enter",
          childDescriptors: ["Contribute$ContributionHasToDate$Enter"]
        },
        {
          descriptor: "Contribute$ContributionPointHasClose$Leave",
          childDescriptors: ["Contribute$ContributionHasToDate$Leave"]
        },
        {
          descriptor: "Contribute$ContributionDatesEditor$Enter",
          handle: ({ descriptor }) => {
            const { from, to, hasToDate } =
              simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDateRange" }) });

            simple.DateRange.setOptions({
              container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
              appContainer: this.getAppContainer(),
              descriptor,
              hasToDate,
              from,
              to
            });
          }
        },
        {
          descriptor: "Contribute$ContributionNamesEditor$Enter",
          group: "ContributionEditors",
          handle: () => {
            simple.Picker.setItems({
              container: this.getElement({ name: "ContributionNamesEditor" }),
              items: r8.services.metadata.names(),
              selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionNames" }) })
            });
          }
        },
        {
          descriptor: "Contribute$ContributionTagsEditor$Enter",
          group: "ContributionEditors",
          handle: () => {
            simple.Picker.setItems({
              container: this.getElement({ name: "ContributionTagsEditor" }),
              items: r8.services.metadata.tags(),
              selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionTags" }) })
            });
          }
        },
        {
          descriptor: "Contribute$ContributionHasToDate$Enter",
          handle: () => {
            simple.DateRange.setHasToDate({
              container: this.getElement({ name: "ContributionDateRange" }),
              appContainer: this.getAppContainer(),
              hasToDate: true
            });
          }
        },
        {
          descriptor: "Contribute$ContributionHasToDate$Leave",
          handle: () => {
            simple.DateRange.setHasToDate({
              container: this.getElement({ name: "ContributionDateRange" }),
              appContainer: this.getAppContainer(),
              hasToDate: false
            });
          }
        },
        {
          descriptor: "Contribute$ContributionPoint$Leave",
          childDescriptors: ["Contribute$ContributionHasToDate$Leave"]
        }
      ]
    });
  }

  enter() {
    if (this.initialized !== true) {
      const appContainer = this.getAppContainer();
      super.init();

      const like = ( /*{ originator, id }*/) => {
        debugger;
      };

      const share = ( /*{ originator, id }*/) => {
        debugger;
      };

      simple.DateRange.init({
        container: this.getElement({ name: "DateRange" }),
        appContainer,
        on: ({ name, descriptor }) => {
          if (name === "Activate") {
            this.executeState({
              batch: {
                states: [{ descriptor: "Contribute$DatesEditor$Enter", value: { descriptor } }],
                backHandleMode: "EnterOnly"
              }
            });
          }
        }
      });

      simple.DateRange.init({
        container: this.getElement({ name: "DatesEditorDateRange" }),
        appContainer,
        getSlider: () => this.getElement({ name: "DatesEditorSlider" })
      });

      simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }), appContainer });

      simple.CheckboxList.init({
        container: this.getElement({ name: "ContributionsFilter" }),
        items: r8.services.metadata.contributionsFilterCategories(),
        on: ({ value }) => simple.List.filter({
          container: this.getElement({ name: "Contributions" }),
          filter: ({ item }) =>
            (value.length === 0 || value.length === 2) ||
            (value.includes("range") && item.type === "Range") ||
            (value.includes("point") && item.type === "Point")
        })
      });

      simple.List.init({
        container: this.getElement({ name: "Contributions" }),
        appContainer,
        template: ({ item, mode }) => {
          return simple.Utils.interpolate({
            name: {
              "Range.Render": "Contribute.ContributionRangeRender",
              "Range.Export": "Contribute.ContributionRangeExport",
              "Point.Render": "Contribute.ContributionPointRender",
              "Point.Export": "Contribute.ContributionPointExport"
            }[`${item.type}.${mode}`],
            context: { item }
          });
        },
        commands:
        [
          { name: "Like", handle: like },
          {
            name: "Discuss",
            handle: ({ /*originator,*/ id }) => {
              this.getElement({ name: "DiscussionContext" }).innerHTML =
                simple.List.exportItem({ container: this.getElement({ name: "Contributions" }), id });

              const request = Object.assign(
                simple.Data.getRequest({ container: this.getElement({ name: "Contribute" }) }),
                { targetId: id });

              simple.Data.request({
                container: this.getElement({ name: "Contribute" }),
                providerNames: [r8.PostsProvider].map(provider => provider.name),
                force: true,
                request
              }).then(({ data }) => {
                const posts = data[r8.PostsProvider.name];

                if (posts && request.targetId) {
                  simple.Discussion.setItems({ container: this.getElement({ name: "Discussion" }), items: posts });

                  this.executeState({
                    batch: { descriptors: ["Contribute$Discussion$Enter"], backHandleMode: "EnterOnly" }
                  });
                }
              });
            }
          },
          { name: "Share", handle: share }
        ]
      });

      simple.List.init({ container: this.getElement({ name: "ContributionNames" }), appContainer });

      simple.List.init({ container: this.getElement({ name: "ContributionTags" }), appContainer });

      simple.Picker.init({
        container: this.getElement({ name: "ContributionNamesEditor" }),
        appContainer,
        filter: {
          categories: r8.services.metadata.nameCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ name, selectedIds }) => {
          switch (name) {
          case "Change":
            simple.List.setItems({
              container: this.getElement({ name: "ContributionNames" }),
              items: r8.services.metadata.names().filter(name => selectedIds.includes(name.id)),
              selectedIds
            });
            simple.Application.apply();
            break;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "ContributionTagsEditor" }),
        appContainer,
        filter: {
          categories: r8.services.metadata.tagCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ name, selectedIds }) => {
          switch (name) {
          case "Change":
            simple.List.setItems({
              container: this.getElement({ name: "ContributionTags" }),
              items: r8.services.metadata.tags().filter(name => selectedIds.includes(name.id)),
              selectedIds: selectedIds
            });
            simple.Application.apply();
            break;
          }
        }
      });

      simple.DateRange.init({
        container: this.getElement({ name: "ContributionDateRange" }),
        appContainer,
        on: ({ name, descriptor }) => {
          if (name === "Activate") {
            this.executeState({
              batch: {
                states: [{ descriptor: "Contribute$ContributionDatesEditor$Enter", value: { descriptor } }],
                backHandleMode: "All"
              }
            });
          }
        }
      });

      simple.Slider.init({ container: this.getElement({ name: "ContributionDatesEditorSlider" }), appContainer });

      simple.DateRange.init({
        container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
        appContainer,
        getSlider: () => this.getElement({ name: "ContributionDatesEditorSlider" })
      });

      simple.RadioList.init({
        container: this.getElement({ name: "ContributionType" }),
        items: r8.services.metadata.contributionTypes(),
        selectedId: "range",
        on: ({ name, id, manual }) => {
          const descriptor = {
            range: "Contribute$ContributionRange$Enter",
            point: "Contribute$ContributionPoint$Enter"
          }[id];

          switch (name) {
          case "Select":
            if (!descriptor) {
              throw `Invalid Contribution Type: '${id}'`;
            }
            this.executeState({ batch: { descriptors: [descriptor] } });
            break;
          default:
            throw `Invalid Command: '${name}'`;
          }
        }
      });

      simple.RadioList.init({
        container: this.getElement({ name: "ContributionPointDirection" }),
        items: r8.services.metadata.contributionPointDirections(),
        selectedId: "b"
      });

      simple.RadioList.init({
        container: this.getElement({ name: "ContributionPointCloseMode" }),
        items: r8.services.metadata.contributionPointCloseModes(),
        selectedId: "manual"
      });

      ["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(
        name => simple.Spinner.init({ container: this.getElement({ name }), items: r8.services.metadata.estimates() }));

      simple.Discussion.init({
        container: this.getElement({ name: "Discussion" }),
        appContainer,
        template: ({ item, mode }) => {
          const name = {
            "Post.Render": "Contribute.DiscussionPostRender",
            "Post.Export": "Contribute.DiscussionPostExport"
          }[`Post.${mode}`];

          return simple.Utils.interpolate({ name, context: { item } });
        },
        commands:
        [
          { name: "Like", handle: like }
        ],
        indent: 30,
        on: ({ name, value }) => {
          switch (name) {
          case "PostAdd":
            //var post = value;
            debugger;

            break;
          }
        }
      });

      simple.Data.init({
        container: this.getElement({ name: "Contribute" }),
        providers: [r8.QuotesProvider, r8.ContributionsProvider, r8.PostsProvider]
      });

      const loadState = () => {
        console.warn("Load state");

        const appContainer = this.getAppContainer();

        const state = simple.Storage.getValue({
          path: "r8.contribute",
          defaultValue: r8.services.app.getDefaultState()
        });

        let { ids, selectedId } = simple.List.selectedIds.parse({ ids: state.names });
        simple.List.setItems({
          container: this.getElement({ name: "Names" }),
          items: r8.services.metadata.names().filter(name => ids.includes(name.id)),
          selectedIds: [selectedId]
        });

        ids = simple.List.selectedIds.parse({ ids: state.tags }).ids;
        simple.List.setItems({
          container: this.getElement({ name: "Tags" }),
          items: r8.services.metadata.tags().filter(tag => ids.includes(tag.id)),
          selectedIds: ids
        });

        simple.DateRange.setOptions({
          container: this.getElement({ name: "DateRange" }),
          appContainer,
          from: state.from,
          to: state.to
        });

        simple.Data.request({
          container: this.getElement({ name: "Contribute" }),
          providerNames: [r8.QuotesProvider, r8.ContributionsProvider].map(provider => provider.name),
          request: state
        }).then(
          ({ data, request, padding }) => {
            this.getElement({ name: "DataPadding" }).innerHTML =
              simple.Utils.interpolate({ name: "Contribute.DataPadding", context: padding });

            const quotes = data[r8.QuotesProvider.name];
            if (quotes) {
              simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
            }

            const contributions = data[r8.ContributionsProvider.name];
            if (contributions) {
              simple.List.setItems({ container: this.getElement({ name: "Contributions" }), items: contributions });
            }
          });
      };

      simple.Chart.init({
        container: this.getElement({ name: "Chart" }),
        appContainer,
        bands: [r8.bands.weekDays],
        on: ({ name, value }) => {
          const $contribute = this.getElement({ name: "Contribute" });
          const from = value ? value.from : null;
          const to = value ? value.to : null;

          switch (name) {
          case "Drag":
            simple.Data.request({
              container: $contribute,
              providerNames: [r8.QuotesProvider, r8.ContributionsProvider].map(provider => provider.name),
              request: Object.assign(simple.Data.getRequest({ container: $contribute }), { from, to })
            }).then(({ data, padding, request }) => {
              this.getElement({ name: "DataPadding" }).innerHTML =
                simple.Utils.interpolate({ name: "Contribute.DataPadding", context: padding });

              const quotes = data[r8.QuotesProvider.name];
              if (quotes) {
                simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
              }

              const contributions = data[r8.ContributionsProvider.name];
              if (contributions) {
                simple.List.setItems({ container: this.getElement({ name: "Contributions" }), items: contributions });
              }
            });

            break;
          case "DragStop":
            simple.Storage.setValue({
              path: "r8.contribute",
              mutator: (value) => {
                value.from = from;
                value.to = to;
                return value;
              }
            });

            loadState();

            break;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "TagsEditor" }),
        appContainer,
        filter: {
          categories: r8.services.metadata.tagCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ selectedIds }) => {
          simple.Storage.setValue({
            path: "r8.contribute",
            mutator: (value) => {
              value.tags = selectedIds;
              return value;
            }
          });

          simple.Application.apply();
          loadState();
        }
      });

      simple.List.init({
        container: this.getElement({ name: "Tags" }),
        appContainer,
        on: ({ ids, selectedIds, name }) => {
          switch (name) {
          case "Change":
            simple.Storage.setValue({
              path: "r8.contribute",
              mutator: (value) => {
                value.tags = ids;
                return value;
              }
            });

            loadState();

            break;
          default:
            throw `Invalid Event:${name}`;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "NamesEditor" }),
        appContainer,
        filter: {
          categories: r8.services.metadata.nameCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ selectedIds }) => {
          simple.Storage.setValue({
            path: "r8.contribute",
            mutator: (value) => {
              const names = selectedIds;
              let selectedName = simple.List.selectedIds.parse({ ids: names }).selectedId;
              selectedName = names.includes(selectedName) ? selectedName : names[0];

              value.names = simple.List.selectedIds.build({ ids: names, selectedId: selectedName });
              return value;
            }
          });

          simple.Application.apply();
          loadState();
        }
      });

      simple.List.init({
        container: this.getElement({ name: "Names" }),
        appContainer,
        on: ({ ids, selectedIds, name }) => {
          switch (name) {
          case "Change":
          case "Select":
            simple.Storage.setValue({
              path: "r8.contribute",
              mutator: (value) => {
                value.names = simple.List.selectedIds.build({ ids, selectedId: selectedIds[0] });
                return value;
              }
            });

            loadState();

            break;
          default:
            throw `Invalid Event:${name}`;
          }
        }
      });

      this.addEventHandles({
        name: "ContributionDatesEditorDone",
        events: "click",
        handle: () => {
          const { from, to } =
            simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDatesEditorDateRange" }) });
          simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDateRange" }, from, to) });
        }
      });

      this.addEventHandles({
        name: "DatesEditorDone",
        events: "click",
        handle: () => {
          const { from, to } =
            simple.DateRange.getOptions({ container: this.getElement({ name: "DatesEditorDateRange" }) });

          simple.Storage.setValue({
            path: "r8.contribute",
            mutator: (value) => {
              value.from = from;
              value.to = to;
              return value;
            }
          });

          simple.Application.apply();
          loadState();
        }
      });

      this.addEventHandles({
        name: "ContributionAdd",
        events: "click",
        handle: () => {
          const app = simple.Application.getController({ container: appContainer, name: "App" });
          app.authenticate({ allowGuestLogin: true }).then(() => {
            alert("do!");
          });
        }
      });

      loadState();
      this.initialized = true;
    }
  }

  leave() {
    this.initialized = false;
    super.detach();
  }
}