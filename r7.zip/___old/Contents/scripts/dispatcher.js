﻿var fxrig = fxrig || {};
fxrig.dispatcher = new function() {
    
};