﻿"use strict";

r8.controllers = {};

// TODO: app menu z-index should be greather than apps's one
r8.controllers.App = new class extends simple.Component {
  constructor() {
    super({
      elements:
        {
          AppOverlay: "app_overlay",
          //AppOverlayMessage: "app_overlay_message",
          //AppOverlayErrorMessage: "app_overlay_error_message",
          AppMenu: "app_menu",
          AppMenuOverlay: "app_menu_overlay",
          AppAppsOverlay: "app_apps_overlay",
          AppUserActivitiesOverlay: "app_user_activities_overlay",
          UserName: "user_name",
          AppMenuUserName: "app_menu_user_name",
          AppAuthenticateOverlay: "app_authenticate_overlay",
          AppMenuLogin: "app_menu_login",
          AppMenuLogout: "app_menu_logout",
          UserLogout: "user_logout",
          AppGuest: "app_guest",
          AppUser: "app_user",
          AppMenuLauncher: "app_menu_launcher",
          AppViewHeader: "app_view_header",
          AppAppsBack: "app_apps_back",
          AppAppsLauncher: "app_apps_launcher",
          AppMenuBack: "app_menu_back",
          AppTheme: "app_theme"
        },
      states:
        [
          {
            name: "App$User",
            enter: ({ container }) => {
              const { userName } = r8.services.app.getUser();
              ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name, container }).innerHTML = userName);
            },
            leave: ({ container }) => ["UserName", "AppMenuUserName"].forEach(name => this.getElement({ name, container }).innerHTML = "Guest")
          },
          {
            name: "App$Overlay",
            reEntryAction: "Allow",
            enter: ({ value }) => {
              const { options } = value;
            }
          },
          {
            name: "App$UserActivities",
            reEntryAction: "Ignore"
          },
          {
            name: "App$Apps",
            reEntryAction: "Ignore"
          },
        ]
    });
  }

  run({ container, handle, options }) {
    return new Promise((resolve) => {
      this.busy({ container, options });
      handle({ container }).then(result => {
        this.free({ container });
        resolve(result);
      });
    });
  }

  init({ container }) {
    simple.Element.init({ element: container });
    const initialized = container.expandos.initilized;

    if (initialized) {
      return null;
    }

    super.init({ container });
    const state = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

    simple.List.init({
      container: this.getElement({ name: "AppMenu", container }),
      template: ({ item }) => simple.Utils.interpolate({ name: "App.MenuItem", context: item }),
      items: [
        { label: "Contribute", description: "Contribute Description", href: "#contribute/data" },
        { label: "Research", description: "Research Description", href: "#research" },
        { label: "Labs", description: "Labs Description", href: "#labs" }
      ]
    });

    simple.Authentication.init({
      container: this.getElement({ name: "AppAuthenticateOverlay", container }),
      handle: ({ name, value, cancel }) => {
        if (cancel) {
          return simple.Application.cancel();
        }

        return this.run({
          handle: () => {
            return new Promise((resolve, reject) => {
              var action = { Login: r8.services.authentication.login, Register: r8.services.authentication.register, Restore: r8.services.authentication.restore }[name];
              action(value).then(resolve);
            });
          }
        });
      }
    });

    const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;

    simple.RadioList.init({
      container: this.getElement({ name: "AppTheme", container }), items: r8.metadata.themes(), selectedId: state.theme,
      on: ({ id, manual }) => {
        simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });
        setTheme({ theme: id });
        simple.Application.apply();
      }
    });

    setTheme({ theme: state.theme });

    const authenticated = r8.services.app.authenticated();
    const descriptors = authenticated ? ["App$User$Enter"] : ["App$User$Leave"];

    this.executeState({ container, batch: { descriptors } });

    ["AppMenuLogin", "AppGuest"].forEach(name => this.addEventHandles({ name, container, events: "click", handle: () => this.authenticate({ allowGuestLogin: false }) }));

    ["UserLogout", "AppMenuLogout"].forEach(name => {
      this.addEventHandles({
        name, container, events: "click",
        handle: () => {
          r8.services.app.removeUser();
          this.executeState({ container, batch: { descriptors: ["App$User$Leave"] } });
        }
      });
    });

    container.expandos.initialized = true;
  }

  authenticate({ container, allowGuestLogin }) {
    if (r8.services.app.authenticated()) {
      return Promise.resolve();
    }

    executeState({ container, batch: { descriptors: ["App$Authenticate$Enter"], backableDirections: "Enter" } });

    return simple.Authentication.authenticate({
      container: this.getElement({ name: "AppAuthenticateOverlay", container }), allowGuestLogin
    }).then(result => {
      if (result) {
        const { userName, token } = result;
        r8.services.app.setUser({ user: { userName, token } });
        this.executeState({ container, batch: { descriptors: ["App$User$Enter"] } });
      }

      simple.Application.cancel();
    });
  }

  setView({ container, name }) {
    container.querySelector("#app_view_container").innerHTML =
      simple.Utils.getHtmlImportText({ name });
    return container.querySelector("#app_view_container").children[0];
  }

  busy({ container, options }) {
    this.executeState({ container, batch: { states: [{ descriptor: "App$Overlay$Enter", value: options }] } });
  }

  free({ container }) {
    this.executeState({ container, theme, batch: { descriptors: ["App$Overlay$Leave"] } });
  }
};
