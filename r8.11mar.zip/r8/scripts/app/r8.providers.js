﻿r8.QuotesProvider = new class extends simple.Provider {
	constructor() {
		super({
			name: "Quotes",
			fetch: ({ request }) => r8.services.quotes.get({ request })
				.then(result => Object.assign(result, { providerName: this.name })),
			merge: ({ existingData, data }) => {
				if (!existingData) {
					return data;
				}
				//debugger;
				throw "Not Implemented";
			},
			filter: ({ data, request }) => {
				const { from, to, frame } = request;
				const range = {};
				const filteredData = data.map(seria => {
          range[seria.name] = {}; // TODO: cache metadata
          
					const nameRange = range[seria.name]; 

					seria.points = seria.points.filter(point => {
						const match = point.o >= from && point.o <= to;
						if (match) {
							const m = point.m;
							nameRange.min = Math.min((nameRange.min || Number.POSITIVE_INFINITY), m);
							nameRange.max = Math.max((nameRange.max || Number.NEGATIVE_INFINITY), m);
						}

						return match;
					});
					return seria;
				});
				
				filteredData.forEach((seria) => {
					const nameRange = range[seria.name];
					seria.min = nameRange.min;
          seria.max = nameRange.max;

				  seria.median = (seria.min + (seria.max - seria.min) / 2).toFixed(5); // TODO: cache metadata and use it
					seria.level = r8.services.metadata.getLevel({ change: 100 * (seria.max - seria.min) / seria.min , frame });
					//
					//console.error("Level - " + seria.name, seria.level); // GLTZUR  is good
				});

				filteredData.name = this.name; // TODO: check and delete if no needed
				filteredData.names = request.names;
				filteredData.from = request.from;
        filteredData.to = request.to;
			  filteredData.median = filteredData.from + (filteredData.to - filteredData.from) / 2;
				filteredData.frame = request.frame;


        console.error(`${request.from} - ${request.to} - ${filteredData[0].points.length}`);

				return filteredData;
			}
		});
	}
};

r8.ContributionsProvider = new class extends simple.Provider {
	constructor() {
		super({
			name: "Contributions",
			fetch: ({ request }) => r8.services.contributions.get({ request })
				.then(result => Object.assign(result, { providerName: this.name })),
			merge: ({ existingData, data }) => {
				if (!existingData) {
					//return data;
				}
				//debugger;
				//throw "Not Implemented";
				return data;
			},
			filter: ({ data, request }) => {
				data.name = this.name; // TODO: check and delete if no needed
				return data;
			}
		});
	}
}

r8.PostsProvider = new class extends simple.Provider {
  constructor() {
    super({
      name: "Posts",
      fetch: ({ request }) => r8.services.posts.get({ request })
        .then(result => Object.assign(result, { providerName: this.name })),
      merge: ({ existingData, data }) => {
        if (!existingData) {
          // return data;
        }
        //debugger;
        // throw "Not Implemented";
        return data;
      },
      filter: ({ data, request }) => {
        data.name = this.name;
        return data;
      }
    });
  }
}