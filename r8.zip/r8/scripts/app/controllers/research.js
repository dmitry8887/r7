﻿"use strict";

r8.controllers.Research = class extends simple.Stateful {
    get routing() {
        return { route: "App$Research", hash: "research" };
    }

    constructor(resolver) {
        super({ elements: [], states: [] });

        this._resolver = resolver;
    }

    get resolver() {
        return this._resolver;
    }

    enter({ transition }) {
        document.querySelector("#view").innerText = "Research";

        console.warn(transtion);
    }

    leave({ transition }) {
        console.warn(transtion);
    };
}