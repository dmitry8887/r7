class LabsController extends Controller {
    constructor(context) {
        super({
            name: "Labs",
            routes:
                [
                    {
                        route: "labs",
                        handler: ({ target, values }) => this.create({ target, values })
                    },
                ],
            requires: ({ target, values }) => context.controllers.App.create({ target, values, final: false }),
            create: (/*{ target }*/) => {
                const appController = context.controllers.App;
                return Element.fill({
                    target: appController.$.AppSlot,
                    name: this.name, leaving: ({ name }) => context.controllers[name].destroy()
                }).then(({ target }) => {
                    appController.set({ descriptors: ["AppBusy$Leave"] });
                    return Promise.resolve({ target });
                })
            },
            initialize: ({ target }) => {
                // debugger;
            },
            destroy: () => {
                console.error("Destroying Labs");
            }
        });
    }
};