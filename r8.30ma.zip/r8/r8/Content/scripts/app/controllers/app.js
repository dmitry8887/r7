﻿"use strict";

r8.controllers = {};

// TODO: app menu z-index should be greather than apps's one
r8.controllers.App = new class extends simple.Component {
  constructor() {
    super({
      elements: {
        AppOverlay: "app_overlay",
        AppOverlayText: "app_overlay_text",
        AppMenu: "app_menu",
        AppMenuOverlay: "app_menu_overlay",
        AppAppsOverlay: "app_apps_overlay",
        AppUserActivitiesOverlay: "app_user_activities_overlay",
        UserName: "user_name",
        AppMenuUserName: "app_menu_user_name",
        AppAuthenticateOverlay: "app_authenticate_overlay",
        AppMenuLogin: "app_menu_login",
        AppMenuLogout: "app_menu_logout",
        UserLogout: "user_logout",
        AppGuest: "app_guest",
        AppUser: "app_user",
        AppMenuLauncher: "app_menu_launcher",
        AppViewHeader: "app_view_header",
        AppAppsBack: "app_apps_back",
        AppAppsLauncher: "app_apps_launcher",
        AppMenuBack: "app_menu_back",
        AppTheme: "app_theme"
      },
      states: [{
        name: "App$User",
        enter: context => {
          const { userName } = r8.services.app.getUser();
          ["UserName", "AppMenuUserName"].forEach(name => this.getElement(context.assign({ name })).innerHTML = userName);
        },
        leave: context => {
          debugger;
          ["UserName", "AppMenuUserName"].forEach(name => this.getElement(context.assign({ name })).innerHTML = "Guest");
        }
      },
      {
        name: "App$Overlay",
        reEntryAction: "Allow",
        enter: ({ container, stateContainer, value }) => {
          const { text } = value;
          this.getElement({ container, name: "AppOverlayText" }).innerHTML = text;
        }
      },
      {
        name: "App$UserActivities",
        reEntryAction: "Ignore"
      },
      {
        name: "App$Apps",
        reEntryAction: "Ignore"
      },
      ]
    });
  }

  root(){
    return true;
  }

  run({ container, stateContainer, handle, options }) {
    return new Promise((resolve) => {
      this.busy({ container, options });

      handle({ container }).then(result => {
        this.free({ container });
        resolve(result);
      });
    });
  }

  init({ container, stateContainer }) {
    super.init({ container, stateContainer });

    simple.Element.initContainer({
      container,
      handle: () => {
        const state = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

        simple.List.init({
          container: this.getElement({ container, name: "AppMenu" }),
          template: ({ item }) => simple.Utils.interpolate({
            name: "App.MenuItem",
            context: item
          }),
          items: [
            { label: "Contribute", description: "Contribute Description", href: "#contribute/data" },
            { label: "Research", description: "Research Description", href: "#research" },
            { label: "Labs", description: "Labs Description", href: "#labs" }
          ]
        });

        simple.Authentication.init({
          container: this.getElement({ container, name: "AppAuthenticateOverlay" }),
          handle: ({ name, value, cancel }) => {
            if (cancel) {
              return simple.Application.cancel();
            }

            return this.run({
              handle: () => {
                return new Promise((resolve, reject) => {
                  var action = {
                    Login: r8.services.authentication.login,
                    Register: r8.services.authentication.register,
                    Restore: r8.services.authentication.restore
                  }[name];
                  action(value).then(resolve);
                });
              }
            });
          }
        });

        const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;

        simple.RadioList.init({
          container: this.getElement({ container, name: "AppTheme" }),
          items: r8.metadata.themes(),
          selectedId: state.theme,
          on: ({ id, manual }) => {
            simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });

            setTheme({ theme: id });

            simple.Application.apply();
          }
        });

        setTheme({ theme: state.theme });
      },
      get: () => container.expandos.initialized,
      set: () => container.expandos.initialized = true
    });

    return { container, stateContainer };
  }

  authenticate({ container, allowGuestLogin }) {
    if (r8.services.app.authenticated()) {
      return Promise.resolve();
    }

    executeState({ container, batch: { descriptors: ["App$Authenticate$Enter"], backableDirections: "Enter" } });

    return simple.Authentication.authenticate({
      container: this.getElement({ name: "AppAuthenticateOverlay", container }),
      allowGuestLogin
    }).then(result => {
      if (result) {
        const { userName, token } = result;
        r8.services.app.setUser({ user: { userName, token } });

        this.executeState({ container, batch: { descriptors: ["App$User$Enter"] } });
      }

      debugger;
      simple.Application.cancel();
    });
  }

  // TODO: make private
  busy({ container, options }) {
    this.executeState({ container, batch: { states: [{ descriptor: "App$Overlay$Enter", transient: true, value: options }] } });
  }

  // TODO: make private
  free({ container }) {
    this.executeState({ container, batch: { descriptors: ["App$Overlay$Leave"], transient: true } });
  }
};