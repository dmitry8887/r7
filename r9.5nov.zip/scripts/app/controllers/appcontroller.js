const AppController = ({ application }) => {
    const { Symbols } = Utils;

    const getData = () => alert("getData!");

    const controller = Controller.Create({
        elements: {
            AppMenu: {
                id: "app_menu",
                init: ({ element }) => List.init({ element, template: ({ item }) => simple.Element.evalTemplate({ name: "App.MenuItem", context: item }), items: r8.metadata.menuItems() })
            },
            AppAuthenticateOverlay: {
                id: "app_authenticate_overlay",
                init: () => {
                    throw "Not Implemented";
                }
            },
            AppTheme: {
                id: "app_theme",
                init: ({ element }) => {
                    const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;
                    const { theme } = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

                    simple.RadioList.init({
                        element,
                        items: r8.metadata.themes(),
                        selectedId: theme,
                        on: ({ id }) => {
                            simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });

                            setTheme({ theme: id });

                            simple.App.apply();
                        }
                    });

                    simple.RadioList.setSelectedId({ element, id: theme });
                }
            }
        },
        states: {
        },
        application,
        routes: [{ hash: "#me", handle: () => { } }],
        init: (target) => {
            debugger;
        }
    });

    controller.run = ({ handle, options }) => {
        const busy = options => this.execute({ batch: { states: [{ descriptor: "Overlay$Enter", value: options }], transient: true } });
        const free = () => this.execute({ batch: { descriptors: ["Overlay$Leave"], transient: true } });

        return new Promise(resolve => {
            busy(options);
            handle().then(result => {
                free();
                resolve(result);
            });
        });
    };

    return controller;

    /*return (new class extends Controller {
        constructor() {
            super({
                elements: {
                    AppMenu: {
                        id: "app_menu",
                        init: ({ element }) => List.init({ element, template: ({ item }) => simple.Element.evalTemplate({ name: "App.MenuItem", context: item }), items: r8.metadata.menuItems() })
                    },
                    AppAuthenticateOverlay: {
                        id: "app_authenticate_overlay",
                        init: () => {
                            throw "Not Implemented";
                        }
                    },
                    AppTheme: {
                        id: "app_theme",
                        init: ({ element }) => {
                            const setTheme = ({ theme }) => document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${theme}.css`;
                            const { theme } = simple.Storage.getValue({ path: "r8", defaultValue: r8.services.app.getDefaultState() });

                            simple.RadioList.init({
                                element,
                                items: r8.metadata.themes(),
                                selectedId: theme,
                                on: ({ id }) => {
                                    simple.Storage.setValue({ path: "r8", mutator: value => Object.assign(value, { theme: id }) });

                                    setTheme({ theme: id });

                                    simple.App.apply();
                                }
                            });

                            simple.RadioList.setSelectedId({ element, id: theme });
                        }
                    }
                },
                states: {
                },
                application,
                routes: [{ hash: "#me", handle: () => { } }],
                init: target => {
                    debugger;
                }
            });

        }

        run({ handle, options }) {
            const busy = options => this.execute({ batch: { states: [{ descriptor: "Overlay$Enter", value: options }], transient: true } });
            const free = () => this.execute({ batch: { descriptors: ["Overlay$Leave"], transient: true } });

            return new Promise(resolve => {
                busy(options);
                handle().then(result => {
                    free();
                    resolve(result);
                });
            });
        }
    });*/
}
