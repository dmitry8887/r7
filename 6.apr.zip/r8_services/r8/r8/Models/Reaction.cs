﻿using System;
using System.Web.Security.AntiXss;

namespace r8.Models
{
  public class Reaction
  {
    public int Id
    {
      get;
      set;
    }

    public int TargetId
    {
      get;
      set;
    }

    public string TargetType // Contribution | Post
    {
      get;
      set;
    }

    public string ReactionType // Like
    {
      get;
      set;
    }

    public DateTime CreatedDate
    {
      get;
      set;
    }

    public string UserToken
    {
      get;
      set;
    }

    public int AppUserId
    {
      get;
      set;
    }

    public string Ip
    {
      get;
      set;
    }

    public Reaction Sanitize()
    {
      TargetType = AntiXssEncoder.HtmlEncode(TargetType, false);     // C or P
      ReactionType = AntiXssEncoder.HtmlEncode(ReactionType, false); // L
      UserToken = AntiXssEncoder.HtmlEncode(UserToken, false);
      Ip = AntiXssEncoder.HtmlEncode(Ip, false);

      return this;
    }
  }
}