﻿using System;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using r8.Controllers;
using r8.Models;

namespace r8.Services
{
  public class UserServices
  {
    public static bool UserExists(Registration registration, SqlConnection connection)
    {
      // check is user name or email are in use
      string sql = $@"SELECT Id 
        FROM dbo.[AppUser] WITH(NOLOCK) 
        WHERE upper(UserName) = UPPER('{registration.UserName}') or UPPER(Email) = UPPER('{registration.Email}')";

      int appUserId = connection.Query<int>(sql).FirstOrDefault();
      return appUserId != 0;
    }

    public static int CreateAppUser(Registration registration, SqlConnection connection)
    {
      return connection.Query<int>(Utils.GenerateInsertSql("dbo.[AppUser]", new[] {"UserName", "Email", "Hash", "Ip", "CreatedDate"}),
        registration).FirstOrDefault();
    }

    public static bool TryGetAppUserId(string token, SqlConnection connection, out int appUserId)
    {
      appUserId = 0;
      var sql = $"SELECT AppUserId as Id FROM dbo.[AppUserSession] WITH(NOLOCK) WHERE Token = '{token}'";
      var queryResult = connection.Query<AppUser>(sql).FirstOrDefault();

      if (queryResult != null) appUserId = queryResult.Id;
      return appUserId > 0;
    }

    public static AppUserSession CreateAppUserSession(int appUserId, SqlConnection connection)
    {
      AppUserSession session = new AppUserSession()
      {
        AppUserId = appUserId,
        Token = Guid.NewGuid().ToString(),
        CreatedDate = DateTime.UtcNow,
        Ip = Utils.GetCallerIp(),
        Active = true
      };

      var deactiveSessionsSql = $"UPDATE dbo.[AppUserSession] SET Active = 0 WHERE AppUSerId = {appUserId}";
      connection.Execute(deactiveSessionsSql);

      connection.Query<int>(Utils.GenerateInsertSql("dbo.[AppUserSession]", new[] {"AppUserId", "Token", "Ip", "CreatedDate", "Active"}),
        session);

      return session;
    }
  }
}