﻿const r8 = {};
r8.controllers = {};

r8.boostrap = () => {
    const appContainer = document.querySelector("#app");

    const urls =
        [
            { name: "R8.Contribute", url: "../html/app/views/contribute.html" },
            { name: "R8.Research", url: "../html/app/views/research.html" },
            { name: "R8.Labs", url: "../html/app/views/labs.html" }
        ];

    simple.Cache.ensure({ urls, version: appContainer.dataset.version }).then(() => {
        const app = new r8.controllers.App({ container: appContainer });
        const contribute = new r8.controllers.Contribute({ container: appContainer.querySelector("#contribute") });
        const research = new r8.controllers.Research({ container: appContainer.querySelector("#research") });
        const labs = new r8.controllers.Labs({ container: appContainer.querySelector("#labs") });

        simple.Router.init({ container: app, controllers: () =>[app, contribute, research, labs], hash: "contribute" });
    });
};