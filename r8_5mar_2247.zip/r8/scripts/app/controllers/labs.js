﻿"use strict";

r8.controllers.Labs = class extends simple.Controller {
	get properties() {
		return { route: "App$Labs", hash: "labs", view: () => "Labs", name: "Labs" };
	}

	constructor({ resolver }) {
    super({
      resolver,
      getContainer: ({ created, stateContainer }) => {
	      if (created !== true) {
		      stateContainer.querySelector("#app_view_container").innerHTML = "Labs";
	      }
	      return stateContainer.querySelector("#app_view_container");
      },
      elements: {},
      states: []
    });
	}

	enter() {
		if (!this.initialized) {
			this.init();
		}
	}

	leave() {
		//console.warn(transition);
	}
}