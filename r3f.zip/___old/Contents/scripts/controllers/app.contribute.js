﻿// make everything driven by the request otherwise it'll be chart centric which is bad

"use strict";

var fxrig = fxrig || {};
fxrig.controllers = fxrig.controllers || {};
fxrig.controllers.app = fxrig.controllers.app || {};


// call invalidate upon init completion
fxrig.controllers.app.contribute = new function () {
    this.hash = "contribute";
    this.url = "html/views/contribute.html";
    this.route = "app$app.contribute";

    var self = {
        name: "Contribute",
        init: function (initArgs) {
            var init = function (initArgs) {
                return new window.Promise(function (resolve, reject) {
                    try {
                        fxrig.data.init({
                            container: $("#contribute_container"),
                            providers: ["Core", "O", "Contributions", "Events", "Discussions"],
                            settings: { fetchScreens: 7, bufferScreens: 3 }
                        });

                        resolve(initArgs);
                    } catch (error) {
                        reject({ error: error });
                    }
                });
            };

            return init(initArgs).then(function () {
                var promises = self.parts.filter(function (part) { return part.init }).map(function (part) {
                    return part.init(initArgs);
                });

                window.Promise.all(promises);
            });
        },
        invalidate: function (invalidateArgs) {

            var state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });

            var invalidateParts = function() {
                var promises = self.parts.filter(function (part) { return part.invalidate }).map(function (part) {
                    return part.invalidate(invalidateArgs);
                });

                return window.Promise.all(promises);
            };

            return fxrig.data.request({
                container: $("#contribute_container"),
                display: state.display,
                mode: "Reset",
                filters:
                [
                    { provider: "Contributions", value: fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions.Filters").actions.getFilter() }
                ],
                context: { sender: "Contribute", receivers: "*", name: "App.Contribute.Data" }
            }).then(function (result) {
                
                var context = result.context, data = result.data;
                fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
            }).then(invalidateParts);
        },
        parts: [
            {
                name: "App.Contribute.Contributions",
                parts: [
                    {
                        name: "App.Contribute.Contributions.Editor",
                        init: function (initArgs) {
                            var $container = $("#contributions_editor_container");

                            $container.html(fxrig.state.getCacheItem({ appName: "fxrig", name: "contribution" }));

                            fxrig.controls.list.initRadioSet({
                                container: $("#contribution_type_radio_set", $container),
                                data: [{ id: "R", text: "R" }, { id: "P", text: "P" }],
                                selectedId: "R",
                                name: "contribution_types",
                                on: function (onArgs) {
                                    var value = onArgs.value;

                                    $("#contribution_range, #contribution_point").hide();

                                    if (value === "R") {
                                        $("#contribution_range").show();
                                    } else {
                                        $("#contribution_point").show();
                                    }

                                    fxrig.controllers.controller.send(self, { name: "App.Contribute.Contributions.Editor.SelectionMode", value: value }); // good
                                }
                            });

                            $("#save_button, #cancel_button", $container).on("click", function () {
                                var role = $(this).data().role;

                                if (role === "Save") {
                                    var getContribution = function () {

                                        var contributionType = fxrig.controls.list.getSelectedId({ container: $("#contribution_type_radio_set") });
                                        var selection = fxrig.controls.chart.getSelection({ container: $("#chart_chart_container") });
                                        var names;
                                        var comment = $("#contribution_range_comment").val();

                                        if (contributionType === "R") {
                                            names = fxrig.controls.list.getIds({ container: $("#chart_chart_names") });

                                            return {
                                                Names: fxrig.utils.data.normilizeNames(names),
                                                From: selection.from,
                                                To: selection.to,
                                                Comment: comment
                                            };
                                        }
                                        else {
                                            names = fxrig.controls.list.getSelectedId({ container: $("#chart_chart_names") });

                                            return {
                                                Names: names,
                                                From: selection.from,
                                                To: selection.to,
                                                Comment: comment
                                            };
                                        }
                                    };

                                    var requestContributions = function () {
                                        fxrig.data.request({
                                            container: $("#contribute_container"),
                                            providers: ["Contributions"],
                                            mode: "Force",
                                            filters:
                                            [
                                                { provider: "Contributions", value: fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions.Filters").actions.getFilter() }
                                            ],
                                            context: { sender: "App.Contribute.Contributions.Filters", receivers: "*", name: "App.Contribute.Contributions.Data" }
                                        }).then(function (result) {
                                            var context = result.context, data = result.data;
                                            fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
                                        }).then(function () {
                                            $("#contributions_editor_container").hide();
                                        });

                                    };

                                    fxrig.services.contributions.add(getContribution()).then(requestContributions);
                                } else {
                                    $container.hide();
                                }
                            });

                            return window.Promise.resolve(initArgs);
                        },
                        on: function (message) {
                            var name = message.name, value = message.value;

                            switch (name) {
                                case "App.Contribute.Chart.Chart.Selection":

                                    var from = value.from;
                                    var to = value.to;

                                    $("#contribution_date_from").text(from);
                                    $("#contribution_date_to").text(to);
                                    $("#contribution_date").text(from);

                                    break;
                            }
                        }
                    },
                    {
                        name: "App.Contribute.Contributions.Filters", // todo: rather do by private init
                        init: function (initArgs) {

                            $("#contributions_add_button").on("click", function () {

                                fxrig.controls.security.authenticate("fxrig").then(function (contributor) {
                                    fxrig.controllers.controller.sendToController(fxrig.controllers.app, { name: "App.Contributor", value: contributor });
                                    $("#contributions_editor_container").show();
                                });
                            });

                            fxrig.controls.list.initCheckboxSet({
                                container: $("#contributions_filter_checkbox_set"),
                                data: [{ id: "R", text: "R" }, { id: "P", text: "P" }, { id: "FullMatch", text: "Full Match" }, { id: "JustMine", text: "Just Mine" }],
                                selectedIds: "R,P",
                                on: function (onArgs) {
                                    if (onArgs.manual) {
                                        fxrig.data.request({
                                            container: $("#contribute_container"),
                                            providers: ["Contributions"],
                                            filters:
                                            [
                                                { provider: "Contributions", value: fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions.Filters").actions.getFilter() }
                                            ],
                                            context: { sender: "App.Contribute.Contributions.Filters", receivers: "*", name: "App.Contribute.Contributions.Data" }
                                        }).then(function (result) {
                                            var context = result.context, data = result.data;
                                            fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
                                        });
                                    }
                                }
                            });

                            return window.Promise.resolve(initArgs);
                        },
                        actions: {
                            getFilter: function () {
                                var selectedIds = fxrig.controls.list.getSelectedIds({ container: $("#contributions_filter_checkbox_set") });
                                selectedIds = selectedIds ? selectedIds.split(",") : [];

                                var selection = fxrig.controls.chart.getSelection({ container: $("#chart_chart_container") });

                                return {
                                    Range: selectedIds.indexOf("R") > -1,
                                    Point: selectedIds.indexOf("P") > -1,
                                    FullMatch: selectedIds.indexOf("FullMatch") > -1,
                                    JustMine: selectedIds.indexOf("JustMine") > -1,
                                    Selection: selection
                                }; // todo: in schekbox get a call returning object automatically based on ids
                            }
                        }
                    },
                    {
                        name: "App.Contribute.Contributions.List",
                        init: function () {
                            return fxrig.controls.list.init({
                                container: $("#contributions_list_container"),
                                template: function (item) {
                                    var name;

                                    switch (item.Type) {
                                        case "R":
                                            name = "range";
                                            break;
                                        case "P":
                                            name = "point";
                                            break;
                                        default:
                                            throw { error: "Invalid Type: " + item.type };
                                    }

                                    return fxrig.state.getCacheItem({ appName: "fxrig", name: name });
                                },
                                on: function (message) {
                                    fxrig.controllers.controller.send(self, _.assign(message, { name: "App.Contribute.Contributions.List.SelectedId" }));
                                }
                            });
                        },
                        on: function (message) {
                            switch (message.name) {
                                case "App.Contribute.Data":
                                case "App.Contribute.Contributions.Data":

                                    fxrig.controls.list.invalidate({ container: $("#contributions_list_container"), data: message.value.Contributions });

                                    var $discussionGroup = $("#discussions_top_container,#discussions_bottom_container");

                                    if (message.value.Contributions.length === 0) {
                                        $discussionGroup.hide();
                                    } else {
                                        $discussionGroup.show();
                                    }

                                    break;
                            }
                        }
                    },
                    {
                        name: "App.Contribute.Contributions.Discussion",
                        init: function () {
                            fxrig.controls.discussion.init({
                                container: $("#discussions_bottom_container"),
                                on: function (message) {
                                    var name = message.name, value = message.value;

                                    switch (name) {
                                        case "AddPost":
                                            fxrig.controls.security.authenticate("fxrig").then(function (contributor) {
                                                fxrig.controllers.controller.sendToController(fxrig.controllers.app, { name: "App.Contributor", value: contributor });

                                                var requestDiscussions = function (discussionId) {
                                                    fxrig.data.request({
                                                        container: $("#contribute_container"),
                                                        providers: ["Discussions"],
                                                        mode: "Force",
                                                        filters:
                                                        [
                                                            { provider: "Discussions", value: { discussionId: discussionId } }
                                                        ],
                                                        context: { sender: "App.Contribute.Contributions.Discussion", receivers: "*", name: "App.Contribute.Contributions.Discussion.Data" }
                                                    }).then(function (result) {
                                                        var context = result.context, data = result.data;
                                                        fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
                                                    });
                                                };

                                                fxrig.services.discussions.add(value).then(function () {
                                                    requestDiscussions(value.discussionId);
                                                });
                                            });

                                            break;
                                    }
                                }
                            });
                        },
                        on: function (message) {
                            var name = message.name, value = message.value;

                            switch (name) {
                                case "App.Contribute.Contributions.List.SelectedId":
                                    fxrig.data.request({
                                        container: $("#contribute_container"),
                                        providers: ["Discussions"],
                                        filters:
                                        [
                                            { provider: "Discussions", value: { discussionId: message.value } }
                                        ],
                                        mode: "Force",
                                        context: { sender: "App.Contribute.Contributions.Discussion", receivers: "*", name: "App.Contribute.Contributions.Discussion.Data" }
                                    }).then(function (result) {
                                        var context = result.context, data = result.data;
                                        fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
                                    });

                                    break;
                                case "App.Contribute.Contributions.Discussion.Data": // nevermind Data itself

                                    fxrig.controls.discussion.invalidate({ container: $("#discussions_bottom_container"), data: value });

                                    break;
                            }
                        }
                    }
                ],
                init: function (initArgs) {

                    var promises = fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions").parts.filter(function (part) { return part.init }).map(function (part) {
                        return part.init(initArgs);
                    });
                    return window.Promise.all(promises);
                },
                invalidate: function (invalidateArgs) {
                    var promises = fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions").parts.filter(function (part) { return part.invalidate }).map(function (part) {
                        return part.invalidate(invalidateArgs);
                    });
                    return window.Promise.all(promises);
                },
                states: {
                    get: function (e) {
                        return fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions").states[e.name];
                    },
                    set: function () {
                        var name = e.name, value = e.value;
                        fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions").states[name] = value;

                        switch (name) {
                            case "Mode":
                                if (value === "")
                                    break;
                            default:
                                throw { error: "App.Contribute.Contributions Invalid State: " + name };
                        }
                    }
                }
            },
            {
                name: "App.Contribute.Chart",
                parts: [
                    {
                        name: "App.Contribute.Chart.Header",
                        invalidate: function () {
                            var state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });
                            var text = "{0}:{1} - {2}".format(state.display.names, state.display.from, state.display.to);
                            $("#contribute_chart_header").text(text);

                            return window.Promise.resolve();
                        }
                    },
                    {
                        name: "App.Contribute.Chart.Chart",
                        init: function () {
                            var state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });

                            var $expandButton = $("#chart_expand_button"),
                                $expandedHeader = $("#chart_expanded_header"),
                                $collapseButton = $("#chart_collapse_button"),
                                $collapsedHeader = $("#chart_collapsed_header"),
                                $chartCollapsableContainer = $("#chart_collapsable_container");

                            var setHeaderMode = function (mode) {
                                $expandedHeader.add($collapsedHeader).hide();

                                if (mode === "Collapsed") {
                                    $chartCollapsableContainer.hide();
                                    $collapsedHeader.show();
                                } else {

                                    $chartCollapsableContainer.css("display", "table-row");
                                    $expandedHeader.show();
                                }
                            };

                            $collapseButton.on("click", function () { setHeaderMode("Collapsed"); });
                            $expandButton.on("click", function () { setHeaderMode("Expanded"); });

                            return fxrig.controls.chart.init({
                                container: $("#chart_chart_container"),
                                display: state.display,
                                serviceName: state.serviceName,
                                bands: state.bands,
                                resolution: "Low",
                                on: function (message) {
                                    var name = message.name, value = message.value;

                                    switch (name) {
                                        case "Busy":

                                            var $adorner = $("#contributions_adorner_container");
                                            if (value) {
                                                $adorner.show();
                                            } else {
                                                $adorner.hide();
                                            }

                                            break;
                                        case "Display":
                                            fxrig.controllers.controller.send(self, _.assign(message, { name: "App.Contribute.Chart.Chart." + message.name }));

                                            break;
                                        case "Selection":

                                            if (value.manual === true) {
                                                fxrig.data.request({
                                                    container: $("#contribute_container"),
                                                    providers: ["Contributions"],
                                                    filters:
                                                    [
                                                        { provider: "Contributions", value: fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions.Filters").actions.getFilter() }
                                                    ],
                                                    context: { sender: "App.Contribute.Chart.Chart", receivers: "*", name: "App.Contribute.Contributions.Data" }
                                                }).then(function (result) {
                                                    var context = result.context, data = result.data;
                                                    fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
                                                });
                                            }

                                            fxrig.controllers.controller.send(self, _.assign(message, { name: "App.Contribute.Chart.Chart." + message.name }));

                                            break;
                                        case "RequestData":

                                            // todo: remove filters - they should be specified in init or only as overrides
                                            fxrig.data.request({
                                                container: $("#contribute_container"),
                                                display: value,
                                                filters:
                                                [
                                                    { provider: "Contributions", value: fxrig.controllers.controller.getPart(self, "App.Contribute.Contributions.Filters").actions.getFilter() }
                                                ],
                                                context: { sender: "App.Contribute.Chart.Chart", receivers: "*", name: "App.Contribute.Data" }
                                            }).then(function(result) {

                                                var context = result.context, data = result.data;
                                                fxrig.controllers.controller.send(self, { name: context.name, value: data, receivers: context.receivers });
                                            });

                                            break;
                                    }
                                }
                            });
                        },
                        on: function (message) {
                            switch (message.name) {
                                case "App.Contribute.Data": // todo: App.Contribute.Data
                                    fxrig.controls.chart.invalidate({ container: $("#chart_chart_container"), data: message.value });

                                    break;
                                case "App.Contribute.Contributions.Editor.SelectionMode": // todo: rename to Chart.SelectionMode
                                    fxrig.controls.chart.invalidate({ container: $("#chart_chart_container"), selectionMode: message.value });

                                    break;
                                case "App.Contribute.Chart.Names":
                                    fxrig.controls.chart.invalidate({ container: $("#chart_chart_container"), selectedName: message.value });

                                    break;
                            }
                        }
                    },
                    {
                        name: "App.Contribute.Chart.Names",
                        invalidate: function (invalidateArgs) {

                            var state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });
                            var names = state.display.names;

                            fxrig.controls.list.initRadioSet({
                                container: $("#chart_chart_names"),
                                data: names.split(":")[0].split(",").map(function (name) { return { id: name, text: name } }),
                                selectedId: names.split(":")[1],
                                name: "chart_names",
                                on: function (onArgs) {
                                    var value = onArgs.value, manual = onArgs.manual;

                                    if (manual) {
                                        fxrig.controllers.controller.send(self, { name: "App.Contribute.Chart.Names", value: value });
                                    }
                                }
                            });

                            return window.Promise.resolve(invalidateArgs);
                        }
                    },
                    {
                        name: "App.Contribute.Chart.Editor",
                        init: function (invalidateArgs) {

                            $("#chart_editor_button").on("click", function () {
                                fxrig.router.navigate({ container: $("#app_container"), name: "app.contribute.editor" });
                            });

                            return window.Promise.resolve(invalidateArgs);
                        }
                    }
                ],
                init: function (initArgs) {

                    var promises = fxrig.controllers.controller.getPart(self, "App.Contribute.Chart").parts.filter(function (part) { return part.init; }).map(function (part) {
                        return part.init(initArgs);
                    });

                    return window.Promise.all(promises);
                },
                invalidate: function (invalidateArgs) {
                    var promises = fxrig.controllers.controller.getPart(self, "App.Contribute.Chart").parts.filter(function (part) { return part.invalidate; }).map(function (part) {
                        return part.invalidate(invalidateArgs);
                    });
                    return window.Promise.all(promises);
                }
            }
        ],
        send: function (message) {
            fxrig.controllers.controller.send(self, message);
        },
        on: function (message) {
            var state;

            switch (message.name) {
                case "App.Contribute.Chart.Chart.Display":
                    state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });
                    state.display = message.value;

                    fxrig.state.set({ controller: fxrig.controllers.app.contribute, value: state });
                    
                    break;
                case "App.Contribute.Chart.Names":

                    // todo: why not invalidating?
                    state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });
                    state.display.names = state.display.names.split(":")[0] + ":" + message.value;
                    fxrig.state.set({ controller: fxrig.controllers.app.contribute, value: state });

                    break;
            }
        }
    };

    this.enter = function (context) {
        console.info("Entering fxrig.controllers.app.contribute.");

        var that = this;

        return new window.Promise(function (resolve, reject) {
            try {
                if (that.from === "app") {
                    return self.init(context).then(self.invalidate).then(resolve);
                } else if (that.from === "app.contribute.editor") {

                    if (context
                        && context.action === "Apply") {

                        self.invalidate(context);
                    }

                    resolve(context);
                } else {
                    throw { error: "Invalid From: " + that.from };
                }
            } catch (error) {
                reject({ error: error });
            }

            throw { message: "Unexpected result for non-blocking call." };
        });
    };

    this.leave = function (context) {
        console.info("Leaving fxrig.controllers.app.contribute.");

        return window.Promise.resolve(context);
    };

    this.on = function (message) {
        fxrig.controllers.controller.send(self, message);
    };

    this.getDefaultState = function() {
        return {
            display: { names: "INS1,INS2:INS1", from: 22749720, to: 22749810, timeframe: 1 },
            serviceName: "Core",
            bands:
            [
                { provider: "O", handler: "Weekends" }, { provider: "O", handler: "Mondays" }, { provider: "Contributions", handler: "Contributions" }
            ],
            resolution: "Low"
        };
    };
};