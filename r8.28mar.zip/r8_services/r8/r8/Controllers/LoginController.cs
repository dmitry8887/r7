﻿using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using Dapper;
using r8.Models;
using r8.Services;

namespace r8.Controllers
{
  public class LoginController : ApiController
  {
    private static readonly string ConnectionString =
      ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    [HttpPost]
    public LoginResult Login(Login login)
    {
      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        string sql = $@"SELECT Id as AppUserId, UserName 
            FROM dbo.[AppUser] with(nolock) 
            WHERE (upper(UserName) = upper('{login.UserNameOrEmail}') or upper(Email) = upper('{login.UserNameOrEmail}')) and Hash = '{login.Token}'";

        var queryResult = connection.Query<AppUser>(sql).FirstOrDefault() ?? new AppUser();
        var appUserId = queryResult.Id;
        var userName = queryResult.Name;

        var success = !string.IsNullOrEmpty(userName);
        AppUserSession session = new AppUserSession();

        if (success)
        {
          session = UserServices.CreateAppUserSession(appUserId, connection);
        }

        LoginResult result = new LoginResult()
        {
          Success = success,
          UserName = userName,
          Token = session.Token,
          Errors = success ? null : new List<string>() { "Invalid Credentials" } // use codes
        };

        connection.Close();

        return result;
      }
    }

  }
}