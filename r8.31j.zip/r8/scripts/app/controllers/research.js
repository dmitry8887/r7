﻿"use strict";

r8.controllers.Research = class extends simple.Controller {
  get routing() {
    return { route: "App$Research", hash: "research" };
  }

  constructor(resolver) {
    super({ resolver, elements: [], states: [] });
  }

  enter() {
    document.querySelector("#view").innerText = "Research";
  }

  leave() {
  }

  static templates() {
    return [
      { name: "r8.views.research", url: "../html/app/views/research.html" }
    ];
  }
}