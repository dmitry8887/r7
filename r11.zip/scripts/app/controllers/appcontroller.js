// TODO: sdelat' dokartoro chtobi controller.decorators.Busy({parameters:{text:"Loading"}, handler})(parameters) - tak budet kruto
// dobavit' podderzhku dashboarda
// TODO: implementirovat' feedback
class AppController extends Controller {
    constructor(context) {
        super({
            name: "App",
            elements: {
                AppAuthAuthenticator: {
                    id: "app_auth_authenticator",
                    initialize: ({ target }) =>
                        Authenticator.initialize({
                            target,
                            login: parameters =>
                                context.controllers.App.decorators.Busy({
                                    parameters: { text: "Authenticating..." },
                                    handler: () => context.services.Login.execute(parameters)
                                        .then(({ user }) => ({ action: "Login", user }))
                                }),
                            register: ({ email, password }) =>
                                context.controllers.App.decorators.Busy({
                                    parameters: { text: "Registering..." },
                                    handler: () =>
                                        context.services.Register.execute(({ email, password }))
                                }),
                            restore: parameters => {
                                const handler = () => context.services.Restore.execute(parameters)
                                    .then(() => ({ action: "Restore" }));

                                return context.controllers.App.decorators.Busy({
                                    parameters: { text: "Restoring..." },
                                    handler
                                });
                            },
                            resolve: ({ action, user }) => {
                                this.set({ descriptors: ["AppAuth$Leave"] });

                                const handlers = {
                                    Login: () => {
                                        if (user) {
                                            context.services.AppAuth.user.set({ user });
                                            this.set({ states: [{ descriptor: "AppUser$Enter", value: { user } }] });
                                            return { _continue: true };
                                        }
                                        else {
                                            debugger;
                                            throw "Invalid Operation";
                                        }
                                    },
                                    Register: () => {
                                        this.set({
                                            states: [{ descriptor: "AppModal$Enter", value: { text: "Registered, check email." } }]
                                        });
                                    },
                                    Restore: () => {
                                        this.set({
                                            states: [{ descriptor: "AppModal$Enter", value: { text: "Restored, check email" } }]
                                        });
                                    },
                                    AsAnonymous: () => {
                                        return { _continue: true };
                                    }
                                };

                                const handler = handlers[action] || (() => ({ _continue: false }));
                                const { _continue } = handler();

                                return new Promise((resolve) => {
                                    if (_continue) {
                                        resolve({ user, action });
                                    }
                                });
                            },
                            reject: () => {
                                debugger;
                                throw "Invalid Operation";
                            }
                        })
                },
                // TODO: remove
                AppSlot: {
                    id: "app_slot"
                },
                AppDashboard: {
                    id: "app_dashboard",
                    initialize: ({ target }) => {
                        Events.register({
                            target,
                            type: "click",
                            selector: ({ target }) => {
                                if (Element.isExpanded) {
                                    const { hash } = Element.expandos.get({ target });
                                    if (hash !== undefined) {
                                        return { selected: true, hash };
                                    }
                                }
                                return { selected: false };
                            },
                            handler: ({ hash }) => {
                                if (["contribute", "research", "labs"].includes(hash)) {
                                    super.set({ descriptors: ["AppDashboard$Leave"] });
                                    console.warn(`setting hash: '${hash}'`); // TODO: oshibec
                                    Browser.setHash({ hash, reload: true });
                                }
                                else {
                                    debugger;
                                    throw "Invalid Operation";
                                }
                            }
                        });
                    }
                }
            },
            states: {
                AppUser: {
                    enter: ({ value }) => {
                        Data.set({ target: this.$.AppUser, data: value.user });
                    }
                },
                AppBusy: {
                    enter: ({ text }) => Data.set({
                        target: this.$.AppBusy,
                        data: { text }, components: [InnerHtml]
                    }),
                    reEntryAction: "Allow"
                },
                AppAuth: {
                    backable: true
                },
                AppModal: {
                    enter: ({ text }) => Data.set({ target: this.$.AppModal, data: { text } })
                },
                AppDashboard: {
                    reEntryAction: "Ignore"
                },
                Header: {
                    enter: ({ value }) => {
                        debugger;
                    },
                    reEntryAction: "Allow"
                }
            },
            initialize: (/*{ target }*/) => {
                const appAuth = context.services.AppAuth;
                if (appAuth.isAuthenticated()
                    && !appAuth.anonymous()) {
                    this.set({
                        states: [{
                            descriptor: "AppUser$Enter",
                            value: { user: appAuth.user.get() }
                        }]
                    });
                }
                else {
                    this.set({ descriptors: ["AppUser$Leave"] });
                }
            },
            destroy: () => {
                throw "Invalid Operation.";
            },
            commands: {
                Login: {
                    handler: () => {
                        super.set({ states: [{ descriptor: "AppAuth$Enter" }] });
                        return Authenticator.authenticate({
                            target: this.$.AppAuthAuthenticator,
                            mode: "Login"
                        });
                    }
                },
                Logout: {
                    handler: () => {
                        context.services.AppAuth.user.remove();
                        this.set({ descriptors: ["AppUser$Leave"] });
                    }
                },
                CloseAppModal: {
                    handler: () => this.set({ descriptors: ["AppModal$Leave"] })
                }
            },
            routes: [
                {
                    route: "", fallBack: true, default: true,
                    handler: ({ target, values }) => {
                        return this.create({ target, values })
                            .then(() => {
                                this.set({ descriptors: ["AppBusy$Leave", "AppDashboard$Enter"] });
                                return Promise.resolve({ target, values });
                            });
                    }
                }
            ],
            // TODO: remove decorators
            decorators: {
                // TODO: where to get decorator parameters
                Busy: ({ parameters, handler }) => {
                    const { text = "Loading..." } = parameters;
                    this.set({ states: [{ descriptor: "AppBusy$Enter", value: { text } }] });
                    // TODO: remove Flow.delay
                    return Flow.delay(0).then(handler)
                        .finally(() => {
                            this.set({ descriptors: ["AppBusy$Leave"] });
                        });
                },
                Authenticate: ({ handler }) => {
                    super.set({ states: [{ descriptor: "AppAuth$Enter", value: { mode: "Login" } }] });
                    return Authenticator.authenticate({ target: this.$.AppAuthAuthenticator, mode: "Login", allowAnonymousLogin: true })
                        .then(result => {
                            debugger;
                            const { _continue, user } = result;
                            if (_continue) {
                                if (!user) {
                                    debugger;
                                    throw "Invalid Operaion";
                                }
                                return handler(result);
                            }
                        });
                }
            },
            templates:
                [

                ]
        })
    }

    busy({ text }) {
        super.set({ states: [{ descriptor: "AppBusy$Enter", value: { text } }] });
    }

    free() {
        super.set({ descriptors: ["AppBusy$Leave"] });
    }
}