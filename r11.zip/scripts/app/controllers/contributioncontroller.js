class ContributionController extends Controller {
    constructor(context) {
        super({
            name: "Contribution",
            elements: {
                Discussion: {
                    id: "discussion",
                    initialize: ({ target }) => {
                        Discussion.initialize({
                            target,
                            handler: e => {
                                debugger;
                            }
                        });
                    }
                }
            },
            routes:
                [
                    {
                        route: "contributions/{id}",
                        handler: ({ target, values }) => {
                            this.create({ target }).then(({ target }) => {
                                const { id } = values;
                                return context.services.Contributions.details({ id })
                                    .then(contribution => {
                                        Data.set({
                                            target,
                                            data: {
                                                discussion: {
                                                    items: contribution.discussion
                                                }
                                            }
                                        });
                                    });
                            })
                        }
                    }
                ],
            requires: ({ target, values }) => context.controllers.App.create({ target, values }),
            create: ({ controller }) => {
                return Element.fill({
                    target: controller.$.AppSlot,
                    name: this.name, leaving: ({ name }) => context.controllers[name].destroy()
                }).then(({ target }) => {
                    appController.set({ descriptors: ["AppBusy$Leave"] });
                    return Promise.resolve({ target });
                })
            },
            initialize: ({ target }) => {
                // debugger;
            },
            destroy: () => {
                console.error("Destroying Contribution");
            },
            templates:
                [
                    {
                        name: "Contribute.Context.Point",
                        handler: ({ context }) => {
                            return `<div class="grid padding" style="grid-template-columns: auto min-content;">
                                        <p class="margins-vertical-auto">Discussion Point</p>
                                        <p class="margins-vertical-auto">${context.id}</p>
                                    </div>`;
                        }
                    },
                    {
                        name: "Contribute.Context.Range",
                        handler: ({ context }) => {
                            return `<div class="grid padding" style="grid-template-columns: auto min-content;">
                                        <p class="margins-vertical-auto">Discussion Range</p>
                                    </div>`;
                        }
                    }
                ]
        });
    }
};