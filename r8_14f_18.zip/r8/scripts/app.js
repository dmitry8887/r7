﻿const r8 = {};
r8.controllers = {};

r8.boostrap = () => {
  const $appContainer = document.querySelector("#app");

  simple.Element.init({ element: document });
  simple.Element.init({ element: $appContainer });
  
  simple.Storage.ensure({
    urls: [
      simple.Data,
      simple.List,
      simple.Picker,
      simple.Slider,
      simple.Date,
      simple.DateRange,
      simple.Chart,
      r8.controllers.App,
      r8.controllers.Contribute,
      r8.controllers.Research,
      r8.controllers.Labs
    ]
    .map(templated => templated.templates()).reduce((result, current) => result.concat(current)),
    version: $appContainer.dataset.version
  }).then(() => {
    const app = new r8.controllers.App({ appContainer: () => $appContainer, container: () => $appContainer });
    const contribute = new r8.controllers.Contribute({ appContainer: () => $appContainer, container: () => $appContainer.querySelector("#contribute") });
    const research = new r8.controllers.Research({ appContainer: () => $appContainer, container: () => $appContainer.querySelector("#research") });
    const labs = new r8.controllers.Labs({ appContainer: () => $appContainer, container: () => $appContainer.querySelector("#labs") });

    simple.Router.init({
      container: $appContainer,
      controllers: () =>[app, contribute, research, labs],
      hash: "contribute"
    });

    simple.Navigator.register({ container: $appContainer });
  });
};