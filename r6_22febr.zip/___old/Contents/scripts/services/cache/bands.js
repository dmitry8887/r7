﻿// create multi color bands

fxrig.services = fxrig.services || {};
fxrig.services.cache = fxrig.services.cache || {};
fxrig.services.cache.bands = new function() {

    this.weekdays = function (e) {
        this.provider = "O";
    };

    this.contributions = function (e) {
        this.provider = "Contributions";
    };
};