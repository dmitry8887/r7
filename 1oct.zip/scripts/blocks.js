// TODO: try generators
// TODO: try iterator symbol for custom iterations
const blocks = (self = {}) => {
    self.Symbols = {
        path: Symbol("path")
    };

    self.Object = {};

    self.Object.check = target => {
        const type = typeof target;
        const [isObject, isSymbol, isFunction, isString, isNumber, isArray = isObject && Array.isArray(target)] = ["object", "symbol", "function", "string", "number"].map(typeName => typeName === type);

        return { isObject, isSymbol, isFunction, isString, isNumber, isArray };
    };

    self.Object.traverse = ({ target, handler }) => {
        const process = target => Object.entries(target).forEach(([key, value]) => {
            const { isObject, isArray } = self.Object.check(value);

            handler({ target, key, value, isObject, isArray });

            if (isObject) {
                process(value);
            }
        });

        process(target);
    }

    self.Object.setPaths = ({ target, handler, path }) => {
        if (path){
            target[self.Symbols.path] = path;
        }
        
        return self.Object.traverse({
            target, handler: ({ target, key, value, isObject }) => {
                const path = self.Object.getPath({ target, key });

                if (isObject) {
                    value = self.Object.import({ target, path, value });
                }

                if (handler) {
                    handler({ path, value });
                }
            }
        });
    }

    self.Object.getPath = ({ target, key }) => [target[self.Symbols.path], key].filter(path => path !== undefined).join(".");

    self.Object.import = ({ target, key, path = $.Object.getPath({ target, key }), value }) => {
        self.Object.setPaths({ target: value, path });

        return value;
    };

    self.Object.wrap = ({ target, handler, isBound, allowDynamicProperties }) => {
        const getContextHandler = context => ({
            get: function (target, key) {
                let value = target[key];

                if (value === undefined) {
                    if (!allowDynamicProperties) {
                        throw `'${key}' doesn't exist on '{value}'`;
                    }

                    value = self.Object.import({ target, key, value: {} });
                    target[key] = value;
                }

                const { isObject, isFunction } = self.Object.check(value);

                if (isObject) {
                    let path = self.Object.getPath({ target, key });

                    if (isBound(path)) {
                        context = { target: value };
                    }
                    else if (self.Object.check(target).isArray
                        && !this.state.ignoreChanges) {
                        path = self.Object.getPath({ target });

                        if (isBound(path)) {
                            context = { target, item: value };
                        }
                    }

                    value = new Proxy(value, getContextHandler(context));
                }
                else if (isFunction) {
                    const arrayUnsupportedMethods = ["delete"];

                    if (arrayUnsupportedMethods.includes(key)) {
                        throw `'${key}' method is not supported.`;
                    }

                    const arrayMutatingMethods = ["splice", "pop", "push", "shift", "unshift"];

                    if (arrayMutatingMethods.includes(key)) {
                        this.state.ignoreChanges = true;
                    }
                }

                return value;
            },
            set: function (target, key, value) {
                const { isString } = self.Object.check(key);

                if (!isString) {
                    throw `Not implemented`;
                }

                const path = self.Object.getPath({ target, key });

                value = self.Object.check(value).isObject
                    ? self.Object.import({ target, path, value: self.Object.unwrap(value) })
                    : value;

                target[key] = value;

                const hasContext = () => context !== undefined;

                if (!hasContext() && isBound(path)) {
                    context = { target: value };
                }

                if (hasContext()) {
                    const { isArray } = $.Object.check(context.target);
                    const isDirect = target === context.target;

                    const arrayChange = isArray;
                    const arrayMemberChange = arrayChange && (!isDirect || (isDirect && !this.state.ignoreChanges));
                    const arrayLengthChange = arrayChange && isDirect && key === "length";

                    if (!arrayChange
                        || arrayMemberChange
                        || arrayLengthChange) {

                        handler(Object.assign({
                            originalValue: value,
                            value: context.target,
                            originalPath: path,
                            path: self.Object.getPath(context)
                        }, {}));

                        this.state.ignoreChanges = false;
                    }
                }

                return true;
            },
            state: { ignoreChanges: false }
        });

        self.Object.setPaths({
            target, handler: ({ path, value }) => {
                if (isBound(path)) {
                    handler({ isInitial: true, originalPath: path, path, originalValue: value, value });
                }
            }
        });

        return new Proxy(target, getContextHandler());
    };

    self.Object.unwrap = proxy => {
        let _target = self.Object.check(proxy).isArray ? [] : {};

        let recent = _target;
        let previous;

        self.Object.traverse({
            target: proxy, handler: ({ target, key, value, isObject, isArray }) => {

                if (isObject) {
                    recent[key] = isArray ? [] : {};

                    previous = recent;
                    recent = recent[key];

                    //unwrap({ proxy: value, target: target[key] });
                }
                else {
                    recent[key] = value;
                    //debugger;
                    recent = previous;
                    //value[key] = value;
                }
            }
        });

        // debugger;
        return _target;
    };

    return self;
};