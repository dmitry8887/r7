﻿const r8 = {};
r8.controllers = {};
r8.bands = {};
r8.providers = {};