﻿const r8 = {};
r8.controllers = {};

r8.boostrap = () => {
  const $app = document.querySelector("#app");

  const initRouter = () => {
    const app = new r8.controllers.App({ appContainer: () => $app, container: () => $app });
    const contribute =
      new r8.controllers.Contribute({ appContainer: () => $app, container: () => $app.querySelector("#contribute") });
    const research =
      new r8.controllers.Research({ appContainer: () => $app, container: () => $app.querySelector("#research") });
    const labs = new r8.controllers.Labs({ appContainer: () => $app, container: () => $app.querySelector("#labs") });

    const routerConfiguration = {
      container: $app,
      controllers: () => [app, contribute, research, labs],
      hash: "contribute"
    };

    simple.Router.init(routerConfiguration);
  };

  simple.Cache.ensure({
      urls: [simple.List, simple.Date, r8.controllers.App, r8.controllers.Contribute, r8.controllers.Research, r8.controllers.Labs]
      .map(templated => templated.templates()).reduce((reduced, current) => reduced.concat(current)),
    version: $app.dataset.version
  }).then(initRouter);
};