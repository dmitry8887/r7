﻿"use strict";

var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};
fxrig.controls.dates = new function () {

    var utils = {
        minutesToDate: function (minutes) {
            var date = new Date(utils.getStartDate() + (minutes * 60 * 1000));

            var month = date.getUTCMonth() + 1;

            return {
                year: date.getUTCFullYear(),
                month: month, // todo: review
                monthName: utils.getMonthName(month),
                day: date.getUTCDate(),
                //weekDay: utils.getWeekDay(date.getUTCDay()),
                hours: date.getUTCHours(),
                minutes: date.getUTCMinutes()
            };
        },
        dateToMinutes: function (date) {
            var year = date.year;
            var month = date.month - 1;
            var day = date.day;
            var hours = date.hours + 1;
            var minutes = date.minutes;

            return Math.round((Date.UTC(year, month, day, hours - 1, minutes) - utils.getStartDate()) / 1000 / 60);
        },
        getStartDate: function () {
            var minUtcDate = new Date(1970, 0, 1, 0, 0);
            return new Date(minUtcDate.getUTCFullYear(), minUtcDate.getUTCMonth(), minUtcDate.getUTCDate()).getTime();
        },
        getWeekDay: function (day) {
            var days = [
                { id: 0, text: "Mon", weekDay: true }, { id: 1, text: "Tue", weekDay: true }, { id: 2, text: "Wed", weekDay: true }, { id: 3, text: "Thu", weekDay: true }, { id: 4, text: "Fri", weekDay: true }, { id: 5, text: "Sat", weekDay: false }, { id: 6, text: "Sun", weekDay: false }
            ];// todo: move to the services

            return _.find(days, function (weekDay) { return weekDay.id === day; }).text;
        },
        getMonthName: function (month) {
            var months = [
                { text: "Jan", id: 1 }, { text: "Feb", id: 2 }, { text: "Mar", id: 3 }, { text: "Apr", id: 4 }, { text: "May", id: 5 }, { text: "Jun", id: 6 }, { text: "Jul", id: 7 }, { text: "Aug", id: 8 }, { text: "Sep", id: 9 }, { text: "Oct", id: 10 }, { text: "Nov", id: 11 }, { text: "Dec", id: 12 }
            ];

            return _.find(months, function (m) { return m.id === month; }).text;
        },
        forceLeadingZero: function (value) {
            return value < 10 ? "0" + value.toString() : value.toString();
        },
        getRegister: function (registerName) {
            return registers.find(function (register) { return register.name === registerName; });
        },
        getDaysInMonth: function (date) {
            switch (date.month - 1) {
                case 1:
                    return (date.year % 4 === 0 && date.year % 100) || date.year % 400 === 0 ? 29 : 28;
                case 8: case 3: case 5: case 10:
                    return 30;
                default:
                    return 31;
            }
        }
    };


    var registers = [
        {
            name: "Day",
            getText: function (date) {
                return utils.forceLeadingZero(date.day);
            },
            getDynamicText: function (sliderValue) {
                return utils.forceLeadingZero(sliderValue);
            },
            getSliderOptions: function (date) {
                return { min: 1, max: utils.getDaysInMonth(date), value: date.day, width: 300 };
            },
            update: function (date, sliderValue) {
                return _.assign(date, { day: sliderValue });
            }
        },
        {
            name: "Month", // todo: check for the 31 of feb
            getText: function (date) {
                return date.monthName;
            },
            getDynamicText: function (sliderValue) {
                return utils.getMonthName(sliderValue);
            },
            getSliderOptions: function (date) {
                return { min: 1, max: 12, value: date.month, width: 300 };
            },
            update: function (date, sliderValue) {
                return _.assign(date, { month: sliderValue });
            },
            coerce: function (date, sliderValue) {
                // coerce day
                var daysInMonth = utils.getDaysInMonth(_.assign(date, { month: sliderValue }));

                if (date.day > daysInMonth) {
                    date.day = daysInMonth;
                    date.month = sliderValue;
                    date.monthName = utils.getMonthName(date.month);

                    return { coerced: true, date: date };
                }

                return { coerced: false };
            }
        },
        {
            name: "Year",
            getText: function (date) {
                return date.year;
            },
            getDynamicText: function (sliderValue) {
                return sliderValue;
            },
            getSliderOptions: function (date) {
                return { min: 2005, max: new Date().getFullYear(), value: date.year, width: 300 }; // todo: today?
            },
            update: function (date, sliderValue) {
                return _.assign(date, { year: sliderValue });
            }
        },
        {
            name: "Hours",
            getText: function (date) {
                return utils.forceLeadingZero(date.hours);
            },
            getDynamicText: function (sliderValue) {
                return utils.forceLeadingZero(sliderValue);
            },
            getSliderOptions: function (date) {
                return { min: 0, max: 23, value: date.hours, width: 300 }; // todo: today?
            },
            update: function (date, sliderValue) {
                return _.assign(date, { hours: sliderValue });
            }
        },
        {
            name: "Minutes",
            getText: function (date) {
                return utils.forceLeadingZero(date.minutes);
            },
            getDynamicText: function (sliderValue) {
                return utils.forceLeadingZero(sliderValue);
            },
            getSliderOptions: function (date) {
                return { min: 1, max: 59, value: date.minutes, width: 300 }; // todo: today?
            },
            update: function (date, sliderValue) {
                return _.assign(date, { minutes: sliderValue });
            }
        }
    ];

    var updateRegister = function (container, registerName, text) {
        $($("#radio_" + container.attr("id") + "_" + registerName, container).next().children()[0]).text(text);
    };

    var updateRegisters = function (container, date) {
        for (var i = 0; i < registers.length; i++) {
            var register = registers[i];
            updateRegister(container, register.name, register.getText(date));
        }
    }

    this.init = function (initArgs) {
        var $container = initArgs.container;
        var state = $container.state({ minutes: initArgs.minutes, date: utils.minutesToDate(initArgs.minutes) }); // number full stop

        var html = fxrig.state.getCacheItem({ appName: "fxrig", name: "dates" });
        $container.html(html);

        var $dateRadioSet = $("#date_radio_set", $container);
        var $timeRadioSet = $("#time_radio_set", $container);
        var $slider = $("#slider_container", $container);

        var containerId = $container.attr("id");

        $slider.slider()
            .on("slide", function (event, data) {
                updateRegister($container, state.register.name, state.register.getDynamicText(data.value));

                if (state.register.coerce) {
                    var coerceResult = state.register.coerce(state.date, data.value);
                    if (coerceResult.coerced) {
                        
                        state.date = coerceResult.date;
                        state.minutes = utils.dateToMinutes(state.date);

                        updateRegisters($container, state.date);
                    }
                }
            })
            .on("slidechange", function (event, data) {
                if (event.originalEvent !== undefined) {
                    var date = state.register.update(state.date, data.value);

                    state.date = date;
                    state.minutes = utils.dateToMinutes(date);
                }
            });

        var updateSlider = function () {
            var register = state.register;
            var date = utils.minutesToDate(state.minutes); // watch the number of calls

            if (!register) {
                debugger;
            }

            var sliderOptions = register.getSliderOptions(date);
            $slider.width(sliderOptions.width).slider("option", "min", sliderOptions.min).slider("option", "max", sliderOptions.max).slider("value", sliderOptions.value);
        };

        fxrig.controls.list.initRadioSet({
            container: $dateRadioSet,
            name: containerId,
            data: [{ id: "Day", text: "8" }, { id: "Month", text: "Feb" }, { id: "Year", text: "2016" }],
            selectedId: "Day",
            on: function (onArgs) {
                state.register = utils.getRegister(onArgs.value);
                updateSlider();
            }
        });

        fxrig.controls.list.initRadioSet({
            container: $timeRadioSet,
            name: containerId,
            data: [{ id: "Hours", text: "11" }/*, { id: "separator", text: ":" }*/, { id: "Minutes", text: "25" }],
            on: function (onArgs) {
                state.register = utils.getRegister(onArgs.value);
                updateSlider();
            }
        });

        updateRegisters($container, state.date);

        return window.Promise.resolve(initArgs);
    };

    this.getMinutes = function (getMinutesArgs) { return getMinutesArgs.container.state().minutes };

    this.getDateHtml = function(minutes, type) {
        var html;
        switch (type) {
        case "Default":
            html = "<div><div>";
            break;
        case "Extended":
            html = "todo";
            break;
        default:
            throw { error: "Invalid Type: " + type };
        }

        return html;
    };
};