const blocks = (self = {}) => {
    self.Symbols = {
        path: Symbol("path"),
        expandos: Symbol("expandos"),
        elements: Symbol("elements"),
        states: Symbol("states"),
        commands: Symbol("commands")
    };

    self.Object = {};

    self.Object.check = target => {
        const type = typeof target;
        const [isObject, isSymbol, isFunction, isString, isNumber, isArray = isObject && Array.isArray(target)] = ["object", "symbol", "function", "string", "number"].map(typeName => typeName === type);

        return { isObject, isSymbol, isFunction, isString, isNumber, isArray };
    };

    self.Object.import = ({ target = {}, path, handler }) => {
        target = Object.assign(self.Object.untrap(target), { [self.Symbols.path]: path });

        const process = target => Object.entries(target).forEach(([key, value]) => {
            const path = self.Object.getPath({ target, key });
            const isObject = self.Object.check(value).isObject;

            if (isObject) {
                value[self.Symbols.path] = path;
                process(value);
            }

            if (handler) {
                handler({ path, value });
            }
        });

        process(target);

        return target;
    }

    self.Object.getPath = ({ target, key }) => [target[self.Symbols.path], key].filter(path => path !== undefined).join(".");

    self.Object.trap = ({ target, handler, isBound, allowDynamicProperties }) => {
        const getContextHandler = context => ({
            get: function (target, key) {
                const isUntrappable = ["toJSON"].includes(key);
                if (isUntrappable) {
                    return target[key];
                }

                const path = self.Object.getPath({ target, key });

                let value = target[key];
                if (value === undefined) {
                    if (!allowDynamicProperties) {
                        throw `'${key}' doesn't exist on '{value}'`;
                    }

                    value = self.Object.import({ path });
                    target[key] = value;
                }

                const { isObject, isFunction } = self.Object.check(value);
                if (isObject) {
                    value[self.Symbols.path] = path;

                    if (isBound(path)) {
                        context = { target: value };
                    }
                    else if (self.Object.check(target).isArray
                        && !this.state.ignoreChanges) {

                        if (isBound(path)) {
                            context = { target, item: value };
                        }
                    }

                    value = new Proxy(value, getContextHandler(context));
                }
                else if (isFunction) {
                    const arrayMutatingMethods = ["splice", "pop", "push", "shift", "unshift", "delete"];
                    if (arrayMutatingMethods.includes(key)) {
                        this.state.ignoreChanges = true;
                    }
                }

                return value;
            },
            set: function (target, key, value) {
                const path = self.Object.getPath({ target, key });

                value = self.Object.check(value).isObject ? self.Object.import({ target: value, path }) : value;

                target[key] = value;

                const hasContext = () => context !== undefined;
                if (!hasContext() && isBound(path)) {
                    context = { target: value };
                }

                if (hasContext()) {
                    const { isArray } = $.Object.check(context.target);
                    const isDirect = target === context.target;
                    const arrayChange = isArray;
                    const arrayMemberChange = arrayChange && (!isDirect || (isDirect && !this.state.ignoreChanges));
                    const arrayLengthChange = arrayChange && isDirect && key === "length";

                    if (!arrayChange
                        || arrayMemberChange
                        || arrayLengthChange) {

                        handler(Object.assign({
                            isInitial: false, originalValue: value, value: context.target, originalPath: path, path: self.Object.getPath({ target: context.target })
                        }, {}));

                        this.state.ignoreChanges = false;
                    }
                }

                return true;
            },
            state: { ignoreChanges: false }
        });

        self.Object.import({
            target, handler: ({ path, value }) => {
                if (isBound(path)) {
                    handler({ isInitial: true, originalPath: path, path, originalValue: value, value });
                }
            }
        });

        return new Proxy(target, getContextHandler());
    };

    self.Object.untrap = proxy => JSON.parse(JSON.stringify(proxy));

    
    self.Application = {};

    // return instance
    self.Application.init = ({ host, routes }) => {

    };

    return self;
};