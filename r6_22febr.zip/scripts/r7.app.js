﻿var r7 = r7 || {};
r7.app = r7.app || {};

r7.app.controllers = r7.app.controllers || {};

r7.app.boostrap = function () {
    var init = function() {

    };

    init();
};