﻿using System;
using System.Web.Http;
using r8.Models;

namespace r8.Controllers
{
  public class RestoreController : ApiController
  {
    //private static readonly string ConnectionString =
    //  ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    [HttpPost]
    public void Restore(Restore restore)
    {
      throw new NotImplementedException();
    }
  }
}