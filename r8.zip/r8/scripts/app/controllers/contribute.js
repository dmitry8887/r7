﻿"use strict";

r8.controllers.Contribute = class extends simple.Stateful {
    constructor({ container }){
        super({ownedElementIds:[], states:[]});
    }

    get routing() {
        return { route: "App$Contribute", "default": true, hash: "contribute" };
    }

    enter({ transition }) {
        document.querySelector("#view").innerText = "Contribute";

        if (this.initialized !== true) {
            this.init({ container: this.container });

            this.initialized = true;
        }

        //console.warn(transition);
    }

    leave({ transition }) {
        //console.warn(transition);
    };
}