﻿var r7 = r7 || {};
r7.app = r7.app || {};
r7.app.controllers = r7.app.controllers || {};

r7.app.boostrap = function () {
    r7.core.router.init({
        container: $("#app"),
        appName: "r7",
        routing: {
            defaultControllerName: "Contributions",
            controllers: [
                r7.app.controllers.app,
                r7.app.controllers.app.contribute,
                r7.app.controllers.app.research,
                r7.app.controllers.app.labs
            ]
        }
    });
};

r7.app.controllers.app = function () {
    this.enter = function() {};
    this.leave = function() {};
};

r7.app.controllers.app.contribute = function () {
    this.enter = function () { };
    this.leave = function () { };
};

r7.app.controllers.app.research = function () {
    this.enter = function () { };
    this.leave = function () { };
};

r7.app.controllers.app.labs = function () {
    this.enter = function () { };
    this.leave = function () { };
};