﻿using r8.Models;
using r8.Services;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web;
using System.Web.Http;
using Dapper;
using System.Linq;

namespace r8.Controllers
{
    public class ContributionsController : ApiController
    {
        private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

        public ContributionsResult Get(string names, int from, int to, int minId = int.MinValue)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                string sql = $@"SELECT contribution.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, contribution.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = contribution.[Id] AND ReactionType = 'Like' AND TargetType = 'Contribution') AS LikeCount,
                        (CASE WHEN contribution.[TypeId] = 1 THEN 'Range' ELSE 'Point' END) AS [Type],
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK) 
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON contribution.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE (SELECT MAX(FromValues) FROM (values (contribution.[From]), ({from})) AS value(FromValues)) <= 
                          (SELECT min(ToValues) FROM (values (contribution.[To]), ({to})) AS value(ToValues))
                          AND contribution.Id > {minId}";

                var contributions = connection.Query<Contribution>(sql).ToList();
                var result = new ContributionsResult();

                result.AddRange(contributions);

                connection.Close();

                return result;
            }
        }

        private Contribution Process(Contribution contribution)
        {
            contribution.TypeId = contribution.Type.Trim().ToLowerInvariant() == "range" ? 1 : 2;

            if (!string.IsNullOrEmpty(contribution.RiskEstimate)
                && contribution.RiskEstimate.Trim().ToLowerInvariant() == "none")
            {
                contribution.RiskEstimate = null;
            }

            if (!string.IsNullOrEmpty(contribution.VolumeEstimate)
                && contribution.VolumeEstimate.Trim().ToLowerInvariant() == "none")
            {
                contribution.VolumeEstimate = null;
            }

            if (!string.IsNullOrEmpty(contribution.LeverageEstimate)
                && contribution.LeverageEstimate.Trim().ToLowerInvariant() == "none")
            {
                contribution.LeverageEstimate = null;
            }

            if (contribution.TypeId == 1)
            {

            }
            else
            {
                contribution.DirectionId = contribution.Direction.Trim().ToLowerInvariant() == "buy" ? 1 : 2;
                contribution.CloseModeId = contribution.CloseMode.Trim().ToLowerInvariant() == "manual" ? 1 : 2;
            }

            contribution.CreatedDate = DateTime.UtcNow;
            contribution.Ip = Utils.GetCallerIp();

            return contribution;
        }

        public Contribution Post(Contribution contribution)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                if (!string.IsNullOrEmpty(token))
                {
                    int appUserId;
                    if (UserServices.TryGetAppUserId(token, connection, out appUserId))
                    {
                        contribution.UserId = appUserId;
                    }
                    else
                    {
                        throw new HttpException("Invalid Token.");
                    }
                }

                contribution = Process(contribution);

                contribution.Id = connection.Query<int>(
                  Utils.GenerateInsertSql("dbo.[Contribution]",
                    new[]
                    {
              "TypeId", "Names", "From", "To", "UserId", "Tags", "Comment", "DirectionId", "RiskEstimate", "Open", "StopLoss", "TakeProfit",
              "Volume", "VolumeEstimate", "Close", "CloseModeId", "Leverage", "LeverageEstimate", "CreatedDate", "Ip"
                    }), contribution.Sanitize()).Single();

                connection.Close();
            }

            return contribution;
        }
    }
}