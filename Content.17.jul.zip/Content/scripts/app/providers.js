﻿"use strict";

r8.providers = {};

r8.QuotesProvider = {
	name: "Quotes",
	fetch: r8.services.quotes.get,
	merge: ({ data, newData, action }) => {
		if (!data) {
			return newData;
		}
		else {
			if (!newData) {
				return data;
			}
			else {
				if (data) {
					const { fetchAppend, fetchPrepend } = action;
					if (fetchAppend && fetchPrepend) {
						throw "Invalid Operation";
					}

					let left, right;

					if (fetchPrepend) {
						left = newData;
						right = data;
					}
					else {
						left = data;
						right = newData;
					}

					left.map(seria => seria.name).forEach(name => {
						let [leftPoints, rightPoints] = [left, right].map(side => side.find(seria => seria.name === name).points);

						if (leftPoints.length === 0 && rightPoints.length > 0) {
							left.find(seria => seria.name === name).points = rightPoints;
						}
						else if (leftPoints.length > 0 && rightPoints.length > 0) {

							const rightmostLeftO = leftPoints[leftPoints.length - 1].o;
							const leftmostRightO = rightPoints[0].o;

							const startIndex = (rightmostLeftO === leftmostRightO) ? 1 : 0;

							for (let i = startIndex; i < rightPoints.length; i++) {
								const rightPoint = rightPoints[i];
								leftPoints.push(rightPoint);
							}
						}
					});

					return left;
				}
			}
		}
	},
	filter: ({ data, request }) => {
		const { from, to, frame } = request;
		const range = {};

		const filteredData = data.map(seria => {
			range[seria.name] = {};
			const nameRange = range[seria.name];

			const filteredPoints = seria.points.filter(point => {
				const match = point.o >= from && point.o <= to;
				if (match) {
					const m = point.m;
					nameRange.min = Math.min((nameRange.min || Number.POSITIVE_INFINITY), m);
					nameRange.max = Math.max((nameRange.max || Number.NEGATIVE_INFINITY), m);
				}

				return match;
			});

			return { name: seria.name, points: filteredPoints };
		});

		filteredData.forEach((seria) => {
			const { min, max } = range[seria.name];
			seria = Object.assign(seria, { min, max });

			seria.median = (min + (max - min) / 2).toFixed(5); // TODO: cache metadata and use it
			seria.level = r8.metadata.getLevel({ change: 100 * (max - min) / min, frame });

			//console.error("Level - " + seria.name, seria.level); // GLTZUR  is good
		});

		filteredData.names = request.names;
		filteredData.from = from;
		filteredData.to = to;
		filteredData.frame = frame;
		filteredData.median = filteredData.from + (filteredData.to - filteredData.from) / 2;

		return filteredData;
	}
}

r8.ContributionsProvider = {
	name: "Contributions",
	fetch: r8.services.contributions.get,
	merge: ({ data, newData }) => {
		if (!data) {
			return newData;
		}
		else {
			if (!newData) {
				return data;
			}
			else {
				return data;
			}
		}
	},
	filter: ({ data, request }) => {
		const getJIndex = (from1, to1, from2, to2) => {
			return 100;
		};

		data.forEach(contribution => {
			const from1 = 1, to1 = 2, from2 = 3, to2 = 4;
			contribution.jIndex = getJIndex({ from1, to1, from2, to2 });
		});

		return data;
	}
};

r8.PostsProvider = {
	name: "Posts",
	fetch: r8.services.posts.get,
	merge: ({ data }) => data,
	filter: ({ data }) => {
		data.name = this.name;
		return data;
	}
};