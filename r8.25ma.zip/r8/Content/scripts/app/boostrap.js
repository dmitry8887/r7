﻿"use strict";

r8.routes =
    [
        {
            name: "default",
            hash: "contribute",
            handle: ({ container, stateContainer }) => {
                container = r8.controllers.Contribute.init({ container, stateContainer }).container;
                return r8.controllers.Contribute.getData({ container, stateContainer });
            }
        },
        {
            hash: "contribute/contributions",
            handle: ({ container, stateContainer, values }) => {
                container = r8.controllers.Contribute.init({ container, stateContainer }).container;
                return r8.controllers.Contribute.getContributionData({ container, stateContainer, values });
            }
        },
        {
            hash: "contribute/contributions", handle: ({ container, stateContainer, id }) => { 
                debugger;
            }
        },
        {
            hash: "contribute/contribution", handle: ({ container }) => { }
        },
        {
            hash: "labs", handle: ({ container }) => { }
        },
        {
            hash: "research", handle: ({ container }) => { }
        }
    ];

const routes = r8.routes;
routes.defaultName = "default";
routes.fallbackName = "default";

const app = r8.controllers.App;
r8.init = app.init.bind(app);
r8.run = app.run.bind(app);