﻿using System.Collections.Generic;

namespace r8.Models
{
  public class PostsResult : List<Post>
  {
  }
}