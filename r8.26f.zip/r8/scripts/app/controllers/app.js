﻿"use strict";

r8.controllers.App = class extends simple.Controller {
  get properties() {
    return { route: "App", name: "App" };
  }

  constructor(resolver) {
	  super({
		  resolver,
		  elements:
		  {
			  AppView: "app_view",
			  AppOverlay: "app_overlay",
			  AppOverlayMessage: "app_overlay_message",
			  AppOverlayErrorMessage: "app_overlay_error_message",
			  AppMenu: "app_menu",
			  AppMenuOverlay: "app_menu_overlay",
			  AppAppsOverlay: "app_apps_overlay",
			  UserName: "user_name",
			  AppMenuUserName: "app_menu_user_name",
			  AppAuthenticateOverlay: "app_authenticate_overlay",
			  AppMenuLogin: "app_menu_login",
			  AppUser: "app_user",
			  AppMenuLauncher: "app_menu_launcher",
			  AppViewHeader: "app_view_header",
			  AppAppsBack: "app_apps_back",
			  AppAppsLauncher: "app_apps_launcher",
			  AppMenuBack: "app_menu_back"
		  },
		  states: []
	  });
  }

  enter() {
    if (this.initialized !== true) {
      this.init();

      this.initialized = true;
    }
  }

  leave({ transition }) {
    const toControllerProperties = simple.Application.getControllerProperties({ container: this.getStateContainer(), name: transition.to });
    this.getElement({ name: "AppView"}).innerHTML = toControllerProperties.view();
  }

	authenticate({ allowGuests }) {
		debugger;
		this.executeState({ batch: { descriptors: ["App$Authenticate$Enter"] } });
		debugger;
	}

	static templates() {
    return [];
  }
}