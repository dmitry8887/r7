﻿"use strict";

r8.controllers.Contribute = class extends simple.Stateful {
    get routing() {
        return { route: "App$Contribute", "default": true, hash: "contribute" };
    }

    constructor(resolver){
        super({ elements: [], states:[] });

        this._resolver = resolver;
    }

    get resolver() {
        return this._resolver;
    }

    get appContainer() {
        return this._appContainer();
    }


    enter({ transition }) {
        document.querySelector("#view").innerText = "Contribute";

        if (this.initialized !== true) {
            this.init(this.resolver);

            this.initialized = true;
        }

        //console.warn(transition);
    }

    leave({ transition }) {
        //console.warn(transition);
    };
}