﻿r7.app.controllers.app.contribute = new function(dependencies) {
    this.route = "app$app.contribute";
    this.hash = "contribute";
    this.header = "Contribute";

    var cache = dependencies.cache;

    var states = {
        chart: {
            enter: function() {
                alert("enter chart");
            }
        },
        contributions: {
            enter: function() {

            }
        },
        contribution: {
            enter: function() {

            }
        }
    };

    var init = function(context) {
        return new window.Promise(function(resolve, reject) {
            var $view = $("#view").html(cache.view);

            $view.find("#names_and_dates").on("click", function() { alert("OK"); });

            r7.lib.chart.init({ container: $view.find("#chart") });

            var $list = $view.find("#list");

            r7.lib.list.init({ container: $list, mode: "Collapsed" });

            resolve(context);
        });
    };

    this.enter = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                init(context).then(resolve(context));
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
}({
    cache: {
        view: r7.lib.state.getCasheItem({ name: "app.views.contribute" })
    },
    services: {
        getContributions: function() {
            return [{ text: "A" }, { text: "B" }, { text: "C" }, { text: "D" }, { text: "E" }];
        }
    }
});