﻿namespace r8.Models
{
  public class Restore
  {
    public string UserNameOrEmail { get; set; }
  }
}