﻿"use strict";

r8.controllers.Labs = new class extends simple.Controller {
  constructor() {
    super({
      name: "Labs",
      routes:
        [
          {
            hash: "#labs",
            handle: function ({ container, store }) {
              this.ensureContainer({ container, store });
              return Promise.resolve();
            }
          }
        ]
    });
  }

  create() {
    if (!this.initialized) {
      this.init();
    }
  }

  init({ container, store }) {

  }

  ensureContainer({ container, store }) {
    const placeholder = simple.Dom.getElement({ container, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.initElement({ element: placeholder });

    const getContainer = () => simple.Dom.getElement({ container: placeholder, id: "labs" });

    if (placeholder.expandos.viewName !== "Labs") {
      // TODO: create simple.Dom.setInnerHtml which would take care about removing existing content
      placeholder.innerHTML = simple.Dom.getHtmlImportText({ name: "Labs" });

      container = getContainer();

      this.init({ container, store });
      placeholder.expandos.viewName == "Labs";
    }
    else {
      container = getContainer();
    }

    return container;
  }
};