﻿"use strict";

// TODO: create a group for Research, Lab, Contribute
const ResearchController = class extends simple.Controller {
  constructor({ context }) {
    super({
      elements: {
        ResearchDebug: { id: "research_debug" }
      },
      routes:
        [
          {
            hash: "#research",
            handle: () => this.debug()
          }
        ],
      name: "Research",
      context
    });
  }

  debug() {
    debugger;
    return Promise.resolve();
  }

  create({ element }) {
    const placeholderElement = simple.Dom.getElement({ element, dataAttributeName: "data-app-view-placeholder" });
    const { content } = simple.Dom.setInnerHtml({ element: placeholderElement, name: this.name });

    return content;
  }

  init() {
    super.init();
    this.getElement({ name: "ResearchDebug" }).innerHTML = "Research Debug";
  }
}