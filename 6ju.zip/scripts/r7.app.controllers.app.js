﻿r7.app.controllers.app = new function() {
    this.route = "app";

    var states = {
        
    };

    var init = function() {
        r7.lib.menu.init({
            launcher: $("#app_menu"),
            container: $("#app_overlay"),
            items: [
                { text: "Contribute", url: "index.html#contribute" },
                { text: "Research", url: "index.html#research" },
                { text: "Lab", url: "index.html#labs" }
            ]
        });
    };

    this.enter = function(context) {
        var from = this.from;

        return new window.Promise(function(resolve, reject) {
            try {
                if (!this.from) {
                    init();
                }

                console.log("entering app...");
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        var to = this.to;

        return new window.Promise(function(resolve, reject) {
            try {
                console.log("leaving app...");
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
};