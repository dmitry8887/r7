﻿"use strict";

r8.controllers.Research = class extends simple.Stateful {
    get routing() {
        return { route: "App$Research", hash: "research" };
    }

    constructor({ container }) {
        super({ ownedElementIds: [], states: [] });
    }

    enter({ transition }) {
        document.querySelector("#view").innerText = "Research";

        console.warn(transtion);
    }

    leave({ transition }) {
        console.warn(transtion);
    };
}