﻿"use strict";

const ResearchController = new class extends simple.Controller {
  constructor() {
    super({
      name: "Research",
      routes:
        [
          {
            hash: "#research",
            handle: function ({ container, store }) {
              this.ensureContainer({ container, store });
              return Promise.resolve();
            }
          }
        ]
    });
  }

  enter() {
    if (!this.initialized) {
      this.init();
    }
  }

  init({ container, store }) {
  }

  ensureContainer({ container, store }) {
    const placeholder = simple.Dom.getElement({ container, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.initElement({ element: placeholder });

    const getContainer = () => simple.Dom.getElement({ container: placeholder, id: "research" });

    if (placeholder.expandos.viewName !== "Research") {
      // TODO: create simple.Dom.setInnerHtml which would take care about removing existing content
      placeholder.innerHTML = simple.Dom.getHtmlImportText({ name: "Research" });

      container = getContainer();

      this.init({ container, store });
      placeholder.expandos.viewName == "Research";
    }
    else {
      container = getContainer();
    }

    return container;
  }
}