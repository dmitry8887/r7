﻿r7.app.controllers.app = new function() {
    this.route = "app";

    var states = {
        busy: function () {
            var $overlay = $("#app_busy_overlay");

            $overlay.find("#error_message").hide();
            $overlay.find("#message").show();

            $overlay.show();
        },
        free: function () {
            $("#app_overlay").hide();
        },
        error: function (e) {
            var $overlay = $("#app_busy_overlay");

            var $errorMessage = $overlay.find("#error_message");

            $errorMessage.html(e.message);

            $overlay.find("#message").hide();
            $errorMessage.show();

            $overlay.show();
        },
        navigated: function(e) {
            $("#app_view_header").html(e.controller.header);
        }
    };

    var init = function() {
        r7.lib.menu.init({
            launcher: $("#app_menu"),
            container: $("#app_menu_overlay"),
            items: [
                { text: "Contribute", url: "index.html#contribute" },
                { text: "Research", url: "index.html#research" },
                { text: "Lab", url: "index.html#labs" }
            ]
        });
    };

    this.enter = function(context) {
        var from = this.from;

        return new window.Promise(function(resolve, reject) {
            try {
                if (!this.from) {
                    init();
                }

                console.log("entering app...");
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        var to = this.to;

        return new window.Promise(function(resolve, reject) {
            try {
                console.log("leaving app...");
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.on = function(e) {
        var name = e.name;
        switch (name) {
        case "Navigating":
            debugger;
            break;
        case "Navigated":
            debugger;
        default:
            throw "Invalid Name: " + name;
        }
    };
};