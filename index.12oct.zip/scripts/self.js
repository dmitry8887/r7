const blocks = (self = {}) => {
    self.Symbols = {
        path: Symbol("path"),
        expandos: Symbol("expandos"),
        elements: Symbol("elements"),
        states: Symbol("states"),
        commands: Symbol("commands")
    };

    self.Object = {};

    self.Object.check = target => {
        const type = typeof target;
        const [isObject, isSymbol, isFunction, isString, isNumber, isArray = isObject && Array.isArray(target)] = ["object", "symbol", "function", "string", "number"].map(typeName => typeName === type);

        return { isObject, isSymbol, isFunction, isString, isNumber, isArray };
    };

    self.Object.import = ({ target = {}, path, handler }) => {
        target = Object.assign(self.Object.untrap(target), { [self.Symbols.path]: path });

        const process = target => Object.entries(target).forEach(([key, value]) => {
            const path = self.Object.getPath({ target, key });
            const isObject = self.Object.check(value).isObject;

            if (isObject) {
                value[self.Symbols.path] = path;
                process(value);
            }

            if (handler) {
                handler({ path, value });
            }
        });

        process(target);

        return target;
    }

    self.Object.getPath = ({ target, key }) => [target[self.Symbols.path], key].filter(path => path !== undefined).join(".");

    self.Object.trap = ({ target, handler, isBound, allowDynamicProperties }) => {
        const getContextHandler = context => ({
            get: function (target, key) {
                const isUntrappable = ["toJSON"].includes(key);
                if (isUntrappable) {
                    return target[key];
                }

                const path = self.Object.getPath({ target, key });

                let value = target[key];
                if (value === undefined) {
                    if (!allowDynamicProperties) {
                        throw `'${key}' doesn't exist on '{value}'`;
                    }

                    value = self.Object.import({ path });
                    target[key] = value;
                }

                const { isObject, isFunction } = self.Object.check(value);
                if (isObject) {
                    value[self.Symbols.path] = path;

                    if (isBound(path)) {
                        context = { target: value };
                    }
                    else if (self.Object.check(target).isArray
                        && !this.state.ignoreChanges) {

                        if (isBound(path)) {
                            context = { target, item: value };
                        }
                    }

                    value = new Proxy(value, getContextHandler(context));
                }
                else if (isFunction) {
                    const arrayMutatingMethods = ["splice", "pop", "push", "shift", "unshift", "delete"];
                    if (arrayMutatingMethods.includes(key)) {
                        this.state.ignoreChanges = true;
                    }
                }

                return value;
            },
            set: function (target, key, value) {
                const path = self.Object.getPath({ target, key });

                value = self.Object.check(value).isObject ? self.Object.import({ target: value, path }) : value;

                target[key] = value;

                const hasContext = () => context !== undefined;
                if (!hasContext() && isBound(path)) {
                    context = { target: value };
                }

                if (hasContext()) {
                    const { isArray } = $.Object.check(context.target);
                    const isDirect = target === context.target;
                    const arrayChange = isArray;
                    const arrayMemberChange = arrayChange && (!isDirect || (isDirect && !this.state.ignoreChanges));
                    const arrayLengthChange = arrayChange && isDirect && key === "length";

                    if (!arrayChange
                        || arrayMemberChange
                        || arrayLengthChange) {

                        handler(Object.assign({
                            isInitial: false, originalValue: value, value: context.target, originalPath: path, path: self.Object.getPath({ target: context.target })
                        }, {}));

                        this.state.ignoreChanges = false;
                    }
                }

                return true;
            },
            state: { ignoreChanges: false }
        });

        self.Object.import({
            target, handler: ({ path, value }) => {
                if (isBound(path)) {
                    handler({ isInitial: true, originalPath: path, path, originalValue: value, value });
                }
            }
        });

        return new Proxy(target, getContextHandler());
    };

    self.Object.untrap = proxy => JSON.parse(JSON.stringify(proxy));

    self.Element = {};

    self.Element.init = ({ element, elements = {}, states = {}, commands = {} }) => {
        element[self.Symbols.expandos] = Object.values(element.dataset).reduce((previuosValue, currentValue) => {
            previuosValue = Object.assign(previuosValue, JSON.parse(currentValue));
            return previuosValue;
        }, {});

        element[self.Symbols.elements] = Object.values(elements).forEach(element => {
            const { init } = element;
            if (init) {
                element.init = init.bind(this);
            }
        });

        element[self.Symbols.states] = Object.values(states).forEach(state => {
            const { enter, leave } = state;
            if (enter) {
                state.enter = enter.bind(this);
            }
            if (leave) {
                state.leave = leave.bind(this);
            }
        });

        element[self.Symbols.commands] = Object.values(commands).forEach(command => {
            const { execute } = command;
            if (!execute) {
                debugger;
            }

            command.execute = execute.bind(this);
            this[key] = command.execute; // TODO: review
        });
    };

    self.Element.execute = ({ element, batch, command, context }) => {
        if (batch !== undefined) {
            const { descriptors, states = descriptors.map(descriptor => ({ descriptor })), transient = false } = batch;
            const backableDescriptors = [];

            states.forEach(({ descriptor, value }) => {
                const [name, direction] = descriptor.split("$");

                const state = element[self.Symbols.states];
                if (!state) {
                    console.warn(`State: '${name}' is virtual.`);
                }

                const reEntryAction = state ? (state.reEntryAction || "Error") : "Error";

                if (direction === "Enter" && context) {
                    if (context.isEntered({ name })) {
                        switch (reEntryAction) {
                            case "Error":
                                throw `Entering already entered state: ${name}`;
                            case "Ignore":
                                console.error(`Ignored state: ${name}`);
                                return;
                        }
                    }
                }

                if (state) {
                    const group = state.group;

                    if (group && direction === "Enter") {
                        const groupLeaveStateDescriptors = Object.keys(this.states)
                            .filter(stateName => stateName != name)
                            .map(name => Object.assign(this.states[name], { name }))
                            .filter(state => state.group === group)
                            .map(state => [state.name, "Leave"].join("$")); // TODO: use getAsLeave

                        this.execute({ element, appContext, batch: { descriptors: groupLeaveStateDescriptors, transient } });
                    }

                    let handle = direction === "Enter" ? state.enter : state.leave;

                    if (handle) {
                        handle({ element, state, value });
                    }
                }

                Object.values(this.elements).map(element => element.id).forEach(id =>
                    simple.Element.setElementVisibility({ element: simple.Element.getElement({ id, element }), descriptor }));

                if (!transient) {
                    appContext.set({ name, value: (direction === "Enter") });
                }

                if (!transient && direction === "Enter") {
                    console.warn(`Backable State Descriptor: '${descriptor}' for:'${element.id}'`);
                    backableDescriptors.push(simple.Component.descriptor.reverse({ descriptor }));
                }
            });

            if (backableDescriptors.length > 0) {
                appContext.addBackHandle({ handle: () => this.execute({ element, appContext, batch: { descriptors: backableDescriptors.reverse() } }) });
            }
        }
    };

    return self;
};