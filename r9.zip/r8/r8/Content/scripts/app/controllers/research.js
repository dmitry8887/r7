﻿"use strict";

// TODO: create a group for Research, Lab, Contribute
const ResearchController = class extends simple.Controller {
  constructor({ resolver }) {
    super({
      name: "Research",
      elements: {
        ResearchDebug: { id: "research_debug" }
      },
      routes:
        [
          {
            hash: "#research",
            handle: () => this.debug()
          }
        ],
      resolver
    });
  }

  debug() {
    debugger;
    return Promise.resolve();
  }

  create({ element }) {
    const placeholderElement = simple.Element.getElement({ element, dataAttributeName: "data-element-slot" });
    const { content } = simple.Element.setInnerHtml({ element: placeholderElement, name: this.name });

    return content;
  }

  init() {
    super.init();
    this.getElement({ name: "ResearchDebug" }).innerHTML = "Research Debug";
  }
}