﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using Dapper;
using r8.Models;
using r8.Services;

namespace r8.Controllers
{
    // TODO: remove
    //[EnableCors("*", "*", "*")]
    public class PostsController : ApiController
    {
        private static readonly string ConnectionString =
            ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

        public PostsResult Get(int externalId)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                string sql = $@"SELECT post.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, post.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = post.[Id] AND ReactionType = 'Like' AND TargetType = 'Post') AS LikeCount,
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK)
                          INNER JOIN dbo.[Post] post WITH(NOLOCK) on post.[ExternalId] = contribution.[Id]
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON post.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE ExternalId = ${externalId}";

                var posts = connection.Query<Post>(sql).ToList();
                var result = new PostsResult();

                result.AddRange(posts);

                connection.Close();

                return result;
            }
        }

        // POST api/<controller>
        public Post Post(Post post)
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                if (!string.IsNullOrEmpty(token))
                {
                    int appUserId;
                    if (UserServices.TryGetAppUserId(token, connection, out appUserId))
                    {
                        post.UserId = appUserId;
                    }
                    else
                    {
                        // TODO: throw & log
                        throw new Exception("Invalid Token.");
                    }
                }

                post.CreatedDate = DateTime.UtcNow;
                post.Ip = Utils.GetCallerIp();
                post.Id = connection.Query<int>(Utils.GenerateInsertSql("dbo.[Post]", new[]
                        {
                            "ParentPostId", "Comment", "ExternalId", "UserId", "CreatedDate", "Ip"
                        }),
                        post.Sanitize())
                    .Single();

                connection.Close();
            }

            return post;
        }
    }
}