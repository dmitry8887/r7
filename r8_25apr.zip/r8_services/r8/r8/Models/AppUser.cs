﻿namespace r8.Models
{
  public class AppUser
  {
    public int Id
    {
      get;
      set;
    }

    public string Name
    {
      get;
      set;
    }
  }
}