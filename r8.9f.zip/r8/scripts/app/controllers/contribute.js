﻿"use strict";

r8.controllers.Contribute = class extends simple.Controller {
  get properties() {
    return { route: "App$Contribute", "default": true, hash: "contribute", name: "Contribute", view:()=> simple.Storage.getText({ name: "r8.views.contribute" }) };
  }

  constructor(resolver) {
    super({
      resolver,
      elements: {
        DateRange: "date_range",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor",
        Contribute: "contribute",
        Chart: "chart",
        ContributionsLauncher: "contributions_launcher",
        ContributionsPanel: "contributions_panel",
        DatesEditor: "dates_editor",
        DatesEditorSlider: "dates_editor_slider",
        DatesEditorDateRange: "dates_editor_date_range",
        DatesEditorDone: "dates_editor_done"
      },
      states: 
      [
        { 
          descriptor: "App.Contribute$NamesEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "NamesEditor" }), items: r8.services.metadata.names(), selectedIds: stored.nameIds });
          }
        },
        {
          descriptor: "App.Contribute$TagsEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "TagsEditor" }), items: r8.services.metadata.tags(), selectedIds: stored.tagIds });
          }
        },
        {
          descriptor: "App.Contribute$DatesEditor$Enter",
          handle: ({ descriptor }) => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.DateRange.setValue({ container: this.getElement({ name: "DatesEditorDateRange"}), descriptor, from: stored.from, to: stored.to });
          }
        },
        {
          descriptor: "App.Contribute$DatesEditor$Leave",
          handle: () => {
            simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) });
          }
        }
      ]
    });
  }

  enter() {
    if (this.initialized !== true) {
      const appContainer = this.getAppContainer();
      const container = this.getContainer();

      this.init();

      const $dateRange = this.getElement({ name: "DateRange" });
      const $datesEditorDateRange = this.getElement({ name: "DatesEditorDateRange" });
      const $names = this.getElement({ name: "Names" });
      const $tags = this.getElement({ name: "Tags" });
      const $namesEditors = this.getElement({ name: "NamesEditor" });
      const $tagsEditor = this.getElement({ name: "TagsEditor" });
      const $contribute = this.getElement({ name: "Contribute" });

      const applyState = ({ state }) => {
        simple.List.setItems({
          container: $names,
          items: r8.services.metadata.names().filter(name => state.nameIds.indexOf(name.id) > -1),
          selectedIds: [state.activeNameId]
        });

        simple.List.setItems({
          container: $tags,
          items: r8.services.metadata.tags().filter(tag => state.tagIds.indexOf(tag.id) > -1),
          selectedIds: state.tagIds
        });

        simple.DateRange.setValue({ container: $dateRange, from: state.from, to: state.to });

        simple.Data.request({ container: $contribute, request: state });
      };

      // INIT
      simple.DateRange.init({ container: $dateRange, appContainer, on:({ name, descriptor }) => {
        if (name === "Activate"){
          this.executeState({ container, appContainer, batch: { states: [{descriptor:"App.Contribute$DatesEditor$Enter", value: { descriptor }}], backHandleMode: "All"}});
        }
      }});

      simple.DateRange.init({ container: $datesEditorDateRange,
        appContainer,
        getSlider: ()=> this.getElement({ name: "DatesEditorSlider" }),
        on: ({ name })=> { 
         
        }});
      
      simple.List.init({
        container: $names,
        appContainer,
        on: ({ ids, selectedIds }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute", mutator: (value) => {
              value.nameIds = ids;
              value.activeNameId = selectedIds[0];

              return value;
            }
          });
          applyState({ state });
        }
      });
      
      simple.List.init({
        container: $tags,
        appContainer,
        on: ({ ids }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute",
            mutator: (value) => {
              value.tagIds = ids;
              return value;
            }
          });
          applyState({ state } );
        }
      });
      
      simple.Picker.init({
        container: $namesEditors,
        appContainer,
        on: ({ selectedIds }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute",
            mutator: (value) => {
              const nameIds = selectedIds;
              let activeNameId = value.activeNameId;

              if (nameIds.indexOf(activeNameId) < 0) {
                activeNameId = nameIds[0];
              }

              value.nameIds = nameIds;
              value.activeNameId = activeNameId;

              return value;
            }
          });

          applyState({ state });
          simple.Navigator.apply();
        }
      });
      
      simple.Picker.init({
        container: $tagsEditor,
        appContainer,
        on: ({ selectedIds }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute",
            mutator: (value) => {
              value.tagIds = selectedIds;
              return value;
            }
          });

          applyState({ state });
          simple.Navigator.apply(); // Swap?
        }
      });

      simple.Chart.init({ container: this.getElement({ name: "Chart"} ), appContainer,
        on: ({ name, value }) => {
          switch(name){
            case "Drag":
              let request = simple.Data.getRequest({ container: $contribute });
              request = Object.assign(request, { from: value.min, to: value.max });
              
              simple.Data.request({ container: $contribute, request });
              break;
            case "DragStop":
              
              const from = value.min;
              const to = value.max;

              applyState({ state: simple.Storage.setValue({
                name: "r8.storage.contribute",
                mutator: (value) => {
                  value.from = from;
                  value.to = to;
                  return value;
                }
              })});

              break;
          }
        }});

      simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }), appContainer, side: "Top" });

      simple.Data.init({
        container: $contribute,
        providers: [r8.providers.quotes],
        on: ({ data }) => {
          const quotes = data[r8.providers.quotes.name];
          if (quotes){
            simple.Chart.setData({ container: this.getElement({ name: "Chart"}), data: quotes });
          }
        }
      });

      const state = simple.Storage.getValue({ name: "r8.storage.contribute", defaultValue: r8.services.contribute.getDefaultData() });
      
      applyState({ state });
      
      this.initialized = true;
    }
  }

  leave() {
  }

  static templates() {
    return [
      { name: "r8.views.contribute", url: "../html/app/views/contribute.html" }
    ];
  }
}