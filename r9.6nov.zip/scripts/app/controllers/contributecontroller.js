const ContributeController = ({ application }) => {
    const { Element, Symbols, Browser } = Utils;

    const getData = () => Promise.resolve();

    return (new class extends Controller {
        constructor() {
            super({
                elements: {
                },
                states: {
                },
                application,
                routes: [
                    {
                        hash: "#contribute", default: true, fallBack: true,
                        handle: ({ controllers }) => {
                            debugger;

                            return getData();
                        }
                        // this.GetData().then(this.SetData).then(this.execute({ batch: { descriptors: ["Chart$Enter"] } }))

                    },
                    {
                        hash: "#contribute/contributions",
                        handle: () => this.GetData({ providers: [r8.QuotesProvider] }).then(() => this.execute({ batch: { descriptors: ["Contributions$Enter"] } }))
                    },
                    {
                        hash: "#contribute/contributions/create", handle: () => {
                            this.execute({ batch: { states: [{ descriptor: "Contribution$Enter", value: { mode: "Add" } }] } });
                            return Promise.resolve();
                        }
                    }
                ],
                init: target => {
                    debugger;
                }
            });

        }

        run({ handle, options }) {
            const busy = options => this.execute({ batch: { states: [{ descriptor: "Overlay$Enter", value: options }], transient: true } });
            const free = () => this.execute({ batch: { descriptors: ["Overlay$Leave"], transient: true } });

            return new Promise(resolve => {
                busy(options);
                handle().then(result => {
                    free();
                    resolve(result);
                });
            });
        }
    });
}