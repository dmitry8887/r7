﻿"use strict";

const LabsController = class extends simple.Controller {
  constructor({ context }) {
    super({
      elements: {
        LabsDebug: { id: "labs_debug" }
      },
      name: "Labs",
      routes:
        [
          { hash: "#labs", handle: () => this.debug() }
        ],
      context
    });
  }

  debug() {
    debugger;
    return Promise.resolve();
  }

  create({ app }) {
    const container = simple.Dom.getElement({ container: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ container, name: this.name });
    debugger;

    return { container: container.children[0] };
  }

  init() {
    debugger;
    super.init();

    this.getElement({ name: "LabsDebug" }).innerHTML = "Lab Debug";
  }
};