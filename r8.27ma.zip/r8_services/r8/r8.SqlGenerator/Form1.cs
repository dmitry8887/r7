﻿using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace r8.SqlGenerator
{
  public partial class Form1 : Form
  {
    public Form1()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e)
    {
        //
      string template = File.ReadAllText(@"Templates/Name.txt");

      int[] frames = {5, 15, 30, 60, 120, 240, 480, 1440, 10080, 43200};

      SqlTextBox.Text = frames.Select((frame) => string.Format(template, NameTextBox.Text, frame))
        .Aggregate((f, s) => f + Environment.NewLine + Environment.NewLine + s);
    }
  }
}
