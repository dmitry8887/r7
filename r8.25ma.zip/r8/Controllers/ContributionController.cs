﻿using r8.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace r8.Controllers
{
    public class ContributionController: ApiController
    {
        private static readonly string ConnectionString =
           ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

        public ContributionResult Get(int id)
        {
            string sql;


            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                string sql = $@"SELECT post.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, post.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = post.[Id] AND ReactionType = 'Like' AND TargetType = 'Post') AS LikeCount,
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK)
                          INNER JOIN dbo.[Post] post WITH(NOLOCK) on post.[ExternalId] = contribution.[Id]
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON post.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE ExternalId = ${externalId} AND post.Id > {minId}";

                var posts = connection.Query<Post>(sql).ToList();
                var result = new PostsResult();

                result.AddRange(posts);

            }


            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            using (SqlConnection connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                string sql = $@"SELECT post.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, post.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = post.[Id] AND ReactionType = 'Like' AND TargetType = 'Post') AS LikeCount,
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK)
                          INNER JOIN dbo.[Post] post WITH(NOLOCK) on post.[ExternalId] = contribution.[Id]
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON post.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id] 
                            AND appUserSession.Active = 1
                        WHERE ExternalId = ${externalId} AND post.Id > {minId}";

                var posts = connection.Query<Post>(sql).ToList();
                var result = new PostsResult();

                result.AddRange(posts);

                connection.Close();

                return result;
            }
        }
    }
}