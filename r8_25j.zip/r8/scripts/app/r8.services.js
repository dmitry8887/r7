﻿r8.services = {};
r8.services.metadata = {}
r8.services.metadata.names = ()=> ["GLTZUR", "VNRODG", "DUSVJL"].map(name=>({ id: name, text: name }));

r8.services.metadata.tags = () => {
  const tags = [];
  for (let i = 0; i < 10; i++) {
    tags.push({ id: "T" + i, text: "T" + i });
  }
  return tags;
}

r8.services.metadata.getSelectedIds = (ids) => ids.filter(id => id.indexOf("*") > -1).map(id => id.replace("*", ""));

r8.services.metadata.getFilteredNames = ({ ids }) => {
  ids = ids.map(id=> id.replace("*", ""));
  return r8.services.metadata.names().filter(name => ids.indexOf(name.id)> -1 );
};

r8.services.metadata.getFilteredTags = ({ ids }) => {
  ids = ids.map(id=> id.replace("*", ""));
  return r8.services.metadata.tags().filter(tag => ids.indexOf(tag.id)> -1 );
};