const { Json } = Lib;

Application.init((({ name, dependencies }) => ({
    target: document.getElementById("app"),
    controllers: [AppController, ContributeController, LabsController, ResearchController, ContributionController],
    services: {
        Metadata: {
            get: ({ name }) => {
                const metadata = {
                    N1: {},
                    N2: {},
                    N3: {}
                };

                const nameMetadata = metadata[name];
                if (!nameMetadata) {
                    debugger;
                    throw `Missing metadata: '${name}'`;
                }
                return nameMetadata;
            }
        },
        Formatting: {
            name: ({ name }) => {
                const colors = {
                    N1: "green",
                    N2: "transparent",
                    N3: "transparent"
                };
                let color = colors[name];
                if (!color) {
                    //debugger;
                    //throw `Missing formatting: '${name}'`;
                    color = "#ccc";
                }
                return { color };
            }
        },
        Lookup: {
            Names: parameters =>
                parameters === undefined
                    ? Array.from(Array(100).keys()).map(id => ({ id: `N${id + 1}`, text: `Name${id + 1}` }))
                    : parameters.ids.map(id => {
                        id = parseInt(id.substring(1, id.length));
                        return { id: `N${id}`, text: `Name${id}` };
                    }),
            Tags: parameters => {
                if (!parameters || !parameters.ids) {
                    debugger;
                }

                return parameters === undefined
                    ? Array.from(Array(100).keys()).map(id => ({ id: `T${id + 1}`, text: `Tag${id + 1}` }))
                    : parameters.ids.map(id => {
                        id = parseInt(id.substring(1, id.length));
                        return { id: `T${id}`, text: `Tag${id}` };
                    });
            },
            TShirtSizes: () => ["XS", "S", "M", "L", "XL"].map(size => ({ id: size, text: size })),
            Frames: () => ["1M", "5M", "15M"].map(frame => ({ id: frame, text: frame }))
        },
        Data: {
            Quotes: {
                fetch: ({ dates, names, tags, area = "Quotes" }) => {
                    const generate = ({ dates, names }) => {
                        const { from, to, step } = dates;
                        return names.map(name => {
                            const level = Random.generateInt({ min: 1, max: 5 });
                            const yMin = 0;
                            const yMax = level * 2 / 10;
                            const seria = { name, level, data: [] };

                            for (let x = from; x <= to; x = x + step) {
                                let y = yMin + Math.random() * (yMax - yMin);
                                if (y < yMin) {
                                    y = yMin;
                                }
                                if (y > yMax) {
                                    y = yMax;
                                }
                                seria.data.push({ x, y: parseFloat(y.toFixed(4)) });
                            }

                            return seria;
                        });
                    };

                    return Promise.resolve([area, generate({ dates, names: names.ids, tags: tags.ids })]);
                },
                reduce: ({ previousValue, currentValue }) => {
                    debugger;
                },
                filter: ({ dates, data }) => {
                    const { from, to } = dates;
                    data = data.reduce((previous, { data, ...rest }) => {
                        let min = Number.POSITIVE_INFINITY, max = Number.NEGATIVE_INFINITY;

                        data = data.filter(({ x, y }) => {
                            if (x >= from && x <= to) {
                                min = Math.min(y, min);
                                max = Math.max(y, min);
                                return true;
                            }
                            return false;
                        });

                        previous.push({ data, min, max, ...rest });
                        return previous;
                    }, []);

                    return { data };
                }
            },
            Contributions: {
                fetch: ({ dates, names, tags, area = "Contributions" }) => {
                    const generate = ({ dates, names, tags }) => {
                        const data =
                            [
                                { type: { selectedIds: ["Range"] }, id: 1, user: 1, comments: "Mine_1" },
                                { type: { selectedIds: ["Point"] }, id: 2, user: 2, comments: "Theirs_2" },
                                { type: { selectedIds: ["Range"] }, id: 3, user: 2, comments: "Theirs_3" },
                                { type: { selectedIds: ["Point"] }, id: 4, user: 2, comments: "Theirs_4" }
                            ];
                        return data;
                    };

                    return Promise.resolve([area, generate({ dates, names: names.ids, tags: tags.ids })]);
                },
                reduce: ({ previousValue, currentValue }) => {
                    debugger;
                },
                filter: ({ names, tags, dates, data }) => {
                    data.summary = `*${data.length}*`;
                    return data;
                }
            },
            Posts: {
                get: () => { },
                merge: () => { },
                filter: () => { }
            },
            Reactions: {
                get: () => { },
                merge: () => { },
                filter: () => { }
            }
        },
        // TODO: check if we need binding and remove it if we don't
        Contributions: Functions.bind({
            target: {
                generate: ({ names, from, to }) => {
                    const data =
                        [
                            { type: { selectedIds: ["Range"] }, id: 1, user: 1, comments: "Mine_1" },
                            { type: { selectedIds: ["Point"] }, id: 2, user: 2, comments: "Theirs_2" },
                            { type: { selectedIds: ["Range"] }, id: 3, user: 2, comments: "Theirs_3" },
                            { type: { selectedIds: ["Point"] }, id: 4, user: 2, comments: "Theirs_4" }
                        ];

                    if (!Mocks.get({ key: "contributions" })) {
                        Mocks.set({ key: "contributions", value: data });
                    }
                    return Mocks.get({ key: "contributions" });
                },
                details: ({ id }) => {
                    return new Promise((resolve, reject) => {
                        setTimeout(() => {
                            const discussion =
                                [
                                    { id: 1, text: "One", level: 0 },
                                    { id: 2, parentId: 1, text: "Two\nLine Two\nLine Three", level: 1 },
                                    { id: 3, parentId: 2, text: "Three", level: 2 },
                                    { id: 4, parentId: 3, text: "Four", level: 3 },
                                    { id: 5, parentId: 3, text: "Four", level: 4 },
                                    { id: 6, text: "One Two", level: 0 },
                                    { id: 7, parentId: 6, text: "Six One", level: 1 },
                                    { id: 8, parentId: 6, text: "Six One", level: 1 }
                                ];

                            resolve({ discussion, name: "Contribution" });
                        }, 0);
                    });
                }
            }
        }),
        AppState: {
            get: function ({ path, fallback }) {
                const target = JSON.parse(localStorage[name] || "{}");
                const storage = {
                    get: ({ path }) => Json.get({ target, path }),
                    set: ({ path, value }) => localStorage[name] = JSON.stringify(Json.set({ target, path, value }))
                };

                let state = storage.get({ path });
                if (!state) {
                    storage.set({ path, value: fallback });
                }

                return state || fallback;
            },
            set: ({ path, value }) => {
                const target = JSON.parse(localStorage[name] || "{}");
                const storage = {
                    get: ({ path }) => Json.get({ target, path }),
                    set: ({ path, value }) => localStorage[name] = JSON.stringify(Json.set({ target, path, value }))
                };
                storage.set({ path, value });
            }
        },
        Login: {
            execute: () => { }
        },
        Register: {
            execute: () => { }
        },
        Confirm: {
            execute: () => { }
        },
        Restore: {
            execute: () => { }
        },
        AppAuth: {
            user: {
                get: () => JSON.parse(localStorage["User"]),
                set: ({ user }) => {
                    localStorage["User"] = JSON.stringify(user);
                },
                remove: () => {
                    localStorage.removeItem("User");
                }
            },
            isAuthenticated: () => {
                const { email, id } = JSON.parse(localStorage["User"] || "{}");
                return [email, id].every(value => value !== undefined);
            },
            anonymous: () => JSON.parse(localStorage["User"] || "{}").anonymous !== undefined
        }
    }
}))({
    name: "App",
    dependencies:
    {
        // register | confirm | login | restore | get | insert | update | delete
    }
}));