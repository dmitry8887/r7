﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(r8.Startup))]

namespace r8
{
  public partial class Startup
  {
    public void Configuration(IAppBuilder app)
    {
      ConfigureAuth(app);
    }
  }
}
