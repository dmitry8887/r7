﻿"use strict";

r8.controllers.App = class extends simple.Controller {
  get properties() {
    return { route: "App", name: "App" };
  }

	constructor({ resolver }) {
		super({
			resolver,
			getContainer: ({ stateContainer }) => stateContainer,
			elements:
			{
				AppOverlay: "app_overlay",
				//AppOverlayMessage: "app_overlay_message",
				//AppOverlayErrorMessage: "app_overlay_error_message",
				AppMenu: "app_menu",
				AppMenuOverlay: "app_menu_overlay",
				AppAppsOverlay: "app_apps_overlay",
				UserName: "user_name",
				AppMenuUserName: "app_menu_user_name",
				AppAuthenticateOverlay: "app_authenticate_overlay",
				AppMenuLogin: "app_menu_login",
				AppMenuLogout: "app_menu_logout",
				AppUser: "app_user",
				AppMenuLauncher: "app_menu_launcher",
				AppViewHeader: "app_view_header",
				AppAppsBack: "app_apps_back",
				AppAppsLauncher: "app_apps_launcher",
				AppMenuBack: "app_menu_back",
				AppTheme: "app_theme"
			},
			states:
			[
				{
					descriptor: "App$Authenticated$Enter",
					handle: ({ user }) => {
						debugger;
					}
				},
				{
					descriptor: "App$Authenticated$Leave",
					handle: () => {
						["UserName", "AppMenuUserName"].forEach(name => {
							this.getElement({ name }).innerHTML = "Guest";
						});
					}
				}
			]
		});
	}

	enter( /*{ from, to }*/) {
		if (this.initialized !== true) {
			this.init();
			
			const stateContainer = this.getStateContainer();

			const state = simple.Storage.getValue({
				name: "r8",
				defaultValue: r8.services.app.getDefaultState()
			});

			simple.List.init({
				container: this.getElement({ name: "AppMenu" }),
				stateContainer,
				template: (({ item }) => {
					return simple.Utils.interpolate({ name: "App.MenuItem", context: item });
				}),
				items: [
					{ label: "Contribute", description: "Contribute Description", href: "#contribute" },
					{ label: "Research", description: "Research Description", href: "#research" },
					{ label: "Labs", description: "Labs Description", href: "#labs" }
				]
			});

			simple.Authentication.init({
				container: this.getElement({ name: "AppAuthenticateOverlay" }),
				stateContainer,
				on: ({ name, value }) => {
					switch (name) {
					case "Login":
						this.executeState({ batch: { descriptors: ["App$Overlay$Enter"] } });
						r8.services.app.authenticate({ user: value }).then(({ success }) => {
							this.executeState({ batch: { descriptors: ["App$Overlay$Leave"] } });
							if (success) {
								container.expandos.resolve({ continue: true }); // hack
							} else {
								alert("cannot login");
							}
						});

						break;
					}
				}
			});

			const setTheme = ({ theme }) => {
				const name = {
					dark: "dark",
					light: "light"
				}[theme];
				document.querySelector("[data-app-theme-stylesheet]").href = `styles/themes/${name}.css`;
			};

			simple.RadioList.init({
				container: this.getElement({ name: "AppTheme" }),
				items: r8.services.metadata.themes(),
				selectedId: state.theme,
				on: ({ id, manual }) => {

					simple.Storage.setValue({
						name: "r8",
						mutator: (value) => {
							value.theme = id;
							return value;
						}
					});

					setTheme({ theme: id });
					simple.Application.apply();
				}
			});

			setTheme({ theme: state.theme });
			
			const authenticated = r8.services.app.authenticated();
			const batch = (authenticated)
				? { states: [{ descriptor: "App$Authenticated$Enter", value: { user: r8.services.app.getUser() } }] }
				: { descriptors: ["App$Authenticated$Leave"] };

			this.executeState({batch});

			this.addEventsHandle({
				name: "AppMenuLogin",
				events: "click",
				handle: () => {
					this.authenticate({ allowGuestLogin: false }).then(() => {
						debugger;
						alert("1");
					});
				}
			});

			this.addEventsHandle({
				name: "AppMenuLogout",
				events: "click",
				handle: () => {
					alert("Logout");
				}
			});

			this.initialized = true;
		}
	}

	leave(/*{ from, to }*/) {
  }

  authenticate({ allowGuestLogin }) {
    this.executeState({ batch: { descriptors: ["App$Authenticate$Enter"] } });
    return simple.Authentication.authenticate({
      container: this.getElement({ name: "AppAuthenticateOverlay" }),
      stateContainer: this.getStateContainer(),
      allowGuestLogin
    }).then((result) => {
      this.executeState({ batch: { descriptors: ["App$Authenticate$Leave"] } });
      return result;
    });
  }

  busy() {
  }

  free() {
  }
}