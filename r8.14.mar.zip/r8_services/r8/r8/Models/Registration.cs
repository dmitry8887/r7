﻿using System;

namespace r8.Models
{
  public class Registration
  {
    public string UserName
    {
      get;
      set;
    }

    public string Email
    {
      get;
      set;
    }

    public string Hash
    {
      get;
      set;
    }

    public string Ip
    {
      get;
      set;
    }

    public DateTime CreatedDate
    {
      get;
      set;
    }
  }
}