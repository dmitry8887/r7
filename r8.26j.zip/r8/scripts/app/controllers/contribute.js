﻿// 114
// 95
"use strict";

r8.controllers.Contribute = class extends simple.Controller {
  get routing() {
    return { route: "App$Contribute", "default": true, hash: "contribute" };
  }

  constructor(resolver) {
    super({
      resolver,
      elements: {
        DateFrom: "date_from",
        DateTo: "date_to",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor"
      },
      states: 
      [
        { 
          descriptor: "App.Contribute$NamesEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "NamesEditor" }), items: r8.services.metadata.names(), selectedIds: stored.nameIds });
          }
        },
        {
          descriptor: "App.Contribute$TagsEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "TagsEditor" }), items: r8.services.metadata.tags(), selectedIds: stored.tagIds });
          }
        }
      ]
    });

    this._resolver = resolver;
  }

  enter() {
    if (this.initialized !== true) {
      this.getAppContainer().querySelector("#view").innerHTML = simple.Storage.getText({ name: "r8.views.contribute" });
      this.init();

      const stored = simple.Storage.getValue({
        name: "r8.storage.contribute",
        defaultValue: {
          from: 24056640,
          to: 24145920,
          frame: 1440,
          nameIds: ["GLTZUR", "DUSVJL"],
          activeNameIds:["GLTZUR"],
          tagIds: ["T1", "T3"]
        }
      });
      
      simple.Date.init({ container: this.getElement({ name: "DateFrom" }), value: stored.from });
      simple.Date.init({ container: this.getElement({ name: "DateTo" }), value: stored.to });

      simple.List.init({
        container: this.getElement({ name: "Names" }),
        items: r8.services.metadata.getFilteredNames({ ids: stored.nameIds }),
        selectedIds: stored.activeNameIds
        //on:({ name, id, manual }) => {
        //  if (manual===true){
        //    // alert(id);
        //  }
        //}
      });

      simple.List.init({
        container: this.getElement({ name: "Tags" }),
        items: r8.services.metadata.getFilteredTags({ ids: stored.tagIds }),
        selectedIds: stored.tagIds
      });

      simple.Picker.init({ container: this.getElement({ name: "NamesEditor" }) });
      simple.Picker.init({ container: this.getElement({ name: "TagsEditor" }) });

      this.initialized = true;
    }
  }

  leave() {
  }

  static templates() {
    return [
      { name: "r8.views.contribute", url: "../html/app/views/contribute.html" }
    ];
  }
}