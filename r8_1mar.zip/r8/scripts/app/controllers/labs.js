﻿"use strict";

r8.controllers.Labs = class extends simple.Controller {
	get properties() {
		return { route: "App$Labs", hash: "labs", view: () => "Labs", name: "Labs" };
	}

	constructor({ resolver }) {
    super({
      resolver,
      getContainer: ({ stateContainer }) => stateContainer.querySelector("#app_view_container"),
      elements: {},
      states: []
    });
	}

	enter() {
		debugger;
		//console.warn(transition);
	}

	leave() {
		debugger;
		//console.warn(transition);
	}

	static templates() {
		return [
			{ name: "r8.views.labs", url: "../html/app/views/labs.html" }
		];
	}
}