﻿"use strict";

r8.controllers.Contribute = class extends simple.Controller {
	get properties() {
		return {
			route: "App$Contribute",
			"default": true,
			hash: "contribute",
			name: "Contribute",
			view: () => simple.Storage.getText({ name: "r8.views.contribute" })
		};
	}

	constructor(resolver) {
		super({
			resolver,
			elements: {
				DateRange: "date_range",
				Names: "names",
				Tags: "tags",
				NamesEditorLauncher: "names_editor_launcher",
				NamesEditor: "names_editor",
				TagsEditorLauncher: "tags_editor_launcher",
				TagsEditor: "tags_editor",
				Contribute: "contribute",
				Chart: "chart",
				Contributions: "contributions",
				ContributionsFilter: "contributions_filter",
				ContributionsLauncher: "contributions_launcher",
				ContributionsSummary: "contributions_summary",
				ContributionsPanel: "contributions_panel",
				DatesEditor: "dates_editor",
				DatesEditorSlider: "dates_editor_slider",
				DatesEditorDateRange: "dates_editor_date_range",
				DatesEditorDone: "dates_editor_done",
				DataSummary: "data_summary",
				ChartZoom: "chart_zoom",
				Add: "add",
				ContributionNames: "contribution_names",
				ContributionTags: "contribution_tags",
				ContributionNamesEditor: "contribution_names_editor",
				ContributionTagsEditor: "contribution_tags_editor",
				ContributionNamesEditorLauncher: "contribution_names_editor_launcher",
				ContributionTagsEditorLauncher: "contribution_tags_editor_launcher",
				ContributionOverlay: "contribution_overlay",
				ContributionDateRange: "contribution_date_range",
				ContributionDatesEditorDateRange: "contribution_dates_editor_date_range",
				ContributionDatesEditor: "contribution_dates_editor",
				ContributionDatesEditorSlider: "contribution_dates_editor_slider",
				ContributionType: "contribution_type",
				ContributionPointDirection: "contribution_point_direction",
				ContributionPoint: "contribution_point",
				ContributionPointCloseMode: "contribution_point_close_mode",
				ContributionPointRiskEstimate: "contribution_point_risk_estimate",
				ContributionPointVolumeEstimate: "contribution_point_volume_estimate",
				ContributionPointLeverageEstimate: "contribution_point_leverage_estimate",
				ContributionPointAddCloseButton: "contribution_point_add_close_button",
				ContributionPointRemoveCloseButton: "contribution_point_remove_close_button",
				ContributionPointCloseRow: "contribution_point_close_row",
				ContributionPointMoreButton: "contribution_point_more_button",
				ContributionPointLessButton: "contribution_point_less_button",
				ContributionPointVolumeRow: "contribution_point_volume_row",
				ContributionPointLeverageRow: "contribution_point_leverage_row",
				ContributionDatesEditorDone: "contribution_dates_editor_done",
				DiscussionOverlay: "discussion_overlay",
				DiscussionContext: "discussion_context",
				Discussion: "discussion"
			},
			states:
			[
				{
					descriptor: "App.Contribute$NamesEditor$Enter",
					group: "Editors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "NamesEditor" }),
							items: r8.services.metadata.names(),
							selectedIds: simple.Storage.getValue({ name: "r8.storage.contribute" }).names
						});
					}
				},
				{
					descriptor: "App.Contribute$TagsEditor$Enter",
					group: "Editors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "TagsEditor" }),
							items: r8.services.metadata.tags(),
							selectedIds: simple.Storage.getValue({ name: "r8.storage.contribute" }).tags
						});
					}
				},
				{
					descriptor: "App.Contribute$DatesEditor$Enter",
					handle: ({ descriptor }) => {
						const { from, to } = simple.Storage.getValue({ name: "r8.storage.contribute" });
						simple.DateRange.setOptions({
							container: this.getElement({ name: "DatesEditorDateRange" }),
							stateContainer: this.getStateContainer(),
							descriptor,
							from,
							to
						});
					}
				},
				{
					descriptor: "App.Contribute$DatesEditor$Leave",
					handle: () => simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) })
				},
				{
					descriptor: "App.Contribute$Contribution$Enter",
					childDescriptors: ["App.Contribute$ContributionRange$Enter"],
					handle: () => {
						const { from, to, names, tags } = simple.Storage.getValue({ name: "r8.storage.contribute" });
						simple.DateRange.setOptions({
							container: this.getElement({ name: "ContributionDateRange" }),
							stateContainer: this.getStateContainer(),
							from,
							to
						});

						simple.List.setItems({
							container: this.getElement({ name: "ContributionNames" }),
							items: r8.services.metadata.names().filter(name => names.includes(name.id)),
							selectedIds: names
						});

						simple.List.setItems({
							container: this.getElement({ name: "ContributionTags" }),
							items: r8.services.metadata.tags().filter(tag => tags.includes(tag.id)),
							selectedIds: tags
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionRange$Enter",
					group: "Contribution",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Enter"],
					handle: () => simple.RadioList.setSelectedId({
						container: this.getElement({ name: "ContributionType" }),
						id: "range"
					})
				},
				{
					descriptor: "App.Contribute$ContributionPoint$Enter",
					group: "Contribution",
					childDescriptors: ["App.Contribute$ContributionPointMore$Leave", "App.Contribute$ContributionPointHasClose$Leave"],
					handle: () => {
						["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(
							name => simple.Spinner.setSelectedId({ container: this.getElement({ name }), id: "None" }));
					}
				},
				{
					descriptor: "App.Contribute$ContributionPointHasClose$Enter",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Enter"]
				},
				{
					descriptor: "App.Contribute$ContributionPointHasClose$Leave",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Leave"]
				},
				{
					descriptor: "App.Contribute$ContributionDatesEditor$Enter",
					handle: ({ descriptor }) => {
						const { from, to, hasToDate } =
							simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDateRange" }) });
						debugger;

						simple.DateRange.setOptions({
							container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
							stateContainer: this.getStateContainer(),
							descriptor,
							hasToDate,
							from,
							to
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionNamesEditor$Enter",
					group: "ContributionEditors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "ContributionNamesEditor" }),
							items: r8.services.metadata.names(),
							selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionNames" }) })
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionTagsEditor$Enter",
					group: "ContributionEditors",
					handle: () => {
						simple.Picker.setItems({
							container: this.getElement({ name: "ContributionTagsEditor" }),
							items: r8.services.metadata.tags(),
							selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionTags" }) })
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionHasToDate$Enter",
					handle: () => {
						simple.DateRange.setHasToDate({
							container: this.getElement({ name: "ContributionDateRange" }),
							stateContainer: this.getStateContainer(),
							hasToDate: true
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionHasToDate$Leave",
					handle: () => {
						simple.DateRange.setHasToDate({
							container: this.getElement({ name: "ContributionDateRange" }),
							stateContainer: this.getStateContainer(),
							hasToDate: false
						});
					}
				},
				{
					descriptor: "App.Contribute$ContributionPoint$Leave",
					childDescriptors: ["App.Contribute$ContributionHasToDate$Leave"]
				}
			],
			commands:
			[
				{
					name: "App.Contribute$LoadState",
					handle: function() {
						const stateContainer = this.getStateContainer();
						const state = simple.Storage.getValue({
							name: "r8.storage.contribute",
							defaultValue: r8.services.contribute.getDefaultData()
						});

						simple.List.setItems({
							container: this.getElement({ name: "Names" }),
							items: r8.services.metadata.names().filter(name => state.names.includes(name.id)),
							selectedIds: [state.activeName]
						});

						simple.List.setItems({
							container: this.getElement({ name: "Tags" }),
							items: r8.services.metadata.tags().filter(tag => state.tags.includes(tag.id)),
							selectedIds: state.tags
						});

						simple.DateRange.setOptions({
							container: this.getElement({ name: "DateRange" }),
							stateContainer,
							from: state.from,
							to: state.to
						});

						simple.Data.request({ container: this.getElement({ name: "Contribute" }), request: state });
					}
				},
				{
					name: "App.Contribute$ContributionDatesEditorDone",
					handle: function() {
						const { from, to } =
							simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDatesEditorDateRange" }) });
						simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDatesRange" }, from, to) });
					}
				},
				{
					name: "App.Contribute$DatesEditorDone",
					handle: function() {
						const { from, to } =
							simple.DateRange.getOptions({ container: this.getElement({ name: "DatesEditorDateRange" }) });

						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								value.from = from;
								value.to = to;
								return value;
							}
						});

						simple.Navigator.apply();
						this.executeCommand({ command: { name: "App.Contribute$LoadState" } });
					}
				},
				{
					name: "App.Contribute$Names$On",
					handle: function({ ids, selectedIds, name }) {
						switch (name) {
						case "Change":
						case "Select":
							simple.Storage.setValue({
								name: "r8.storage.contribute",
								mutator: (value) => {
									value.names = ids;
									value.activeName = selectedIds[0];
									return value;
								}
							});

							this.executeCommand({ command: { name: "App.Contribute$LoadState" } });

							break;
						default:
							throw `Invalid Event:${name}`;
						}
					}
				},
				{
					name: "App.Contribute$Tags$On",
					handle: function({ ids, selectedIds, name }) {
						switch (name) {
						case "Change":
							simple.Storage.setValue({
								name: "r8.storage.contribute",
								mutator: (value) => {
									value.tags = ids;
									return value;
								}
							});

							this.executeCommand({ command: { name: "App.Contribute$LoadState" } });
							break;
						default:
							throw `Invalid Event:${name}`;
						}
					}
				},
				{
					name: "App.Contribute$NamesEditor$On",
					handle: function({ selectedIds }) {
						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								const names = selectedIds;
								let activeName = value.activeName;
								if (!names.includes(activeName)) {
									activeName = names[0];
								}
								value.names = names;
								value.activeName = activeName;
								return value;
							}
						});

						simple.Navigator.apply();
						this.executeCommand({ command: { name: "App.Contribute$LoadState" } });
					}
				},
				{
					name: "App.Contribute$TagsEditor$On",
					handle: function({ selectedIds }) {
						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								value.tags = selectedIds;
								return value;
							}
						});

						simple.Navigator.apply();
						this.executeCommand({ command: { name: "App.Contribute$LoadState" } });
					}
				},
				{
					name: "App.Contribute$Like",
					handle: ({ originator, id }) => {
						debugger;
					}
				},
				{
					name: "App.Contribute$Discuss",
					handle: ({ /*originator,*/ id }) => {
						this.getElement({ name: "DiscussionContext" }).innerHTML =
							simple.List.exportItem({ container: this.getElement({ name: "Contributions" }), id });

						// Get data then execute state
						const request = Object.assign(simple.Data.getRequest({ container: this.getElement({ name: "Contribute" }) }),
							{ targetId: id });
						
						simple.Data.request({ container: this.getElement({ name: "Contribute" }), request });
					}
				},
				{
					name: "App.Contribute$Share",
					handle: ({ originator, id }) => {
						debugger;
					}
				}
			]
		});
	}

	enter() {
		if (this.initialized !== true) {
			const stateContainer = this.getStateContainer();
			
			super.init();

			simple.DateRange.init({
				container: this.getElement({ name: "DateRange" }),
				stateContainer,
				on: ({ name, descriptor }) => {
					if (name === "Activate") {
						this.executeState({
							batch: {
								states: [{ descriptor: "App.Contribute$DatesEditor$Enter", value: { descriptor } }],
								backHandleMode: "All"
							}
						});
					}
				}
			});

			simple.DateRange.init({
				container: this.getElement({ name: "DatesEditorDateRange" }),
				stateContainer,
				getSlider: () => this.getElement({ name: "DatesEditorSlider" })
			});

			simple.List.init({
				container: this.getElement({ name: "Names" }),
				stateContainer,
				on: this.getCommand({ name: "App.Contribute$Names$On" }).handle
			});

			simple.List.init({
				container: this.getElement({ name: "Tags" }),
				stateContainer,
				on: this.getCommand({ name: "App.Contribute$Tags$On" }).handle
			});

			simple.Picker.init({
				container: this.getElement({ name: "NamesEditor" }),
				stateContainer,
				on: this.getCommand({ name: "App.Contribute$NamesEditor$On" }).handle
			});

			simple.Picker.init({
				container: this.getElement({ name: "TagsEditor" }),
				stateContainer,
				on: this.getCommand({ name: "App.Contribute$TagsEditor$On" }).handle
			});

			simple.Chart.init({
				container: this.getElement({ name: "Chart" }),
				stateContainer,
				bands: [r8.bands.weekDays],
				on: ({ name, value }) => {
					const $contribute = this.getElement({ name: "Contribute" });
					const from = value ? value.from : null;
					const to = value ? value.to : null;

					switch (name) {
					case "Drag":
						simple.Data.request({
							container: $contribute,
							request: Object.assign(simple.Data.getRequest({ container: $contribute }), { from, to })
						});

						break;
					case "DragStop":
						simple.Storage.setValue({
							name: "r8.storage.contribute",
							mutator: (value) => {
								value.from = from;
								value.to = to;
								return value;
							}
						});

						this.executeCommand({ command: { name: "App.Contribute$LoadState" } });

						break;
					}
				}
			});

			simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }) });

			simple.List.init({
				container: this.getElement({ name: "Contributions" }),
				template: ({ item, mode }) => {
					const name = {
						"Range.Render": "r8.views.contribute.contribution.range.render",
						"Range.Export": "r8.views.contribute.contribution.range.export",
						"Point.Render": "r8.views.contribute.contribution.point.render",
						"Point.Export": "r8.views.contribute.contribution.point.export"

					}[`${item.type}.${mode}`];

					return simple.Utils.interpolate({ name, context: { item } });
				},
				commands:
				[
					{ name: "Like", handle: this.getCommand({ name: "App.Contribute$Like" }).handle },
					{ name: "Discuss", handle: this.getCommand({ name: "App.Contribute$Discuss" }).handle },
					{ name: "Share", handle: this.getCommand({ name: "App.Contribute$Share" }).handle }
				]
			});

			simple.List.init({ container: this.getElement({ name: "ContributionNames" }), stateContainer });

			simple.List.init({ container: this.getElement({ name: "ContributionTags" }), stateContainer });

			simple.Picker.init({
				container: this.getElement({ name: "ContributionNamesEditor" }),
				stateContainer,
				on: ({ name, selectedIds }) => {
					switch (name) {
					case "Change":
						simple.List.setItems({
							container: this.getElement({ name: "ContributionNames" }),
							items: r8.services.metadata.names().filter(name => selectedIds.includes(name.id)),
							selectedIds
						});
						simple.Navigator.apply();
						break;
					}
				}
			});

			simple.Picker.init({
				container: this.getElement({ name: "ContributionTagsEditor" }),
				stateContainer,
				on: ({ name, selectedIds }) => {
					switch (name) {
					case "Change":
						simple.List.setItems({
							container: this.getElement({ name: "ContributionTags" }),
							items: r8.services.metadata.tags().filter(name => selectedIds.includes(name.id)),
							selectedIds: selectedIds
						});
						simple.Navigator.apply();
						break;
					}
				}
			});

			simple.DateRange.init({
				container: this.getElement({ name: "ContributionDateRange" }),
				stateContainer,
				on: ({ name, descriptor }) => {
					if (name === "Activate") {
						this.executeState({
							batch: {
								states: [{ descriptor: "App.Contribute$ContributionDatesEditor$Enter", value: { descriptor } }],
								backHandleMode: "All"
							}
						});
					}
				}
			});

			simple.Slider.init({ container: this.getElement({ name: "ContributionDatesEditorSlider" }), stateContainer });

			simple.DateRange.init({
				container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
				stateContainer,
				getSlider: () => this.getElement({ name: "ContributionDatesEditorSlider" })
			});

			simple.RadioList.init({
				container: this.getElement({ name: "ContributionType" }),
				items: r8.services.metadata.contributionTypes(),
				selectedId: "range",
				on: ({ name, id, manual }) => {
					const descriptor = {
						range: "App.Contribute$ContributionRange$Enter",
						point: "App.Contribute$ContributionPoint$Enter"
					}[id];

					switch (name) {
					case "Select":
						if (!descriptor) {
							throw `Invalid Contribution Type: '${id}'`;
						}
						this.executeState({ batch: { descriptors: [descriptor] } });
						break;
					default:
						throw `Invalid Command: '${name}'`;
					}
				}
			});

			simple.RadioList.init({
				container: this.getElement({ name: "ContributionPointDirection" }),
				items: r8.services.metadata.contributionPointDirections(),
				selectedId: "b"
			});

			simple.RadioList.init({
				container: this.getElement({ name: "ContributionPointCloseMode" }),
				items: r8.services.metadata.contributionPointCloseModes(),
				selectedId: "manual"
			});

			["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(
				name => simple.Spinner.init({ container: this.getElement({ name }), items: r8.services.metadata.estimates() }));

			simple.Discussion.init({
				container: this.getElement({ name: "Discussion" }),
				stateContainer,
				template: ({ item, mode }) => {
					const name = {
						"Post.Render": "r8.views.contribute.discussion.post.render",
						"Post.Export": "r8.views.contribute.discussion.post.export"
					}[`Post.${mode}`];

					return simple.Utils.interpolate({ name, context: { item } });
				},
				commands:
				[
					{ name: "Like", handle: this.getCommand({ name: "App.Contribute$Like" }).handle }
				],
				indent: 30
			});

			// TODO: change to use then instead of on, as on'd force handling in one place (?)
			simple.Data.init({
				container: this.getElement({ name: "Contribute" }),
				providers: [r8.providers.quotes, r8.providers.contributions, r8.providers.posts],
				on: ({ data, request }) => {
					const { left, right } = data;
					simple.Data.renderSummary({ container: this.getElement({ name: "DataSummary" }), left, right });

					const quotes = data[r8.providers.quotes.name];
					if (quotes) {
						simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
					}

					const contributions = data[r8.providers.contributions.name];
					if (contributions) {
						simple.List.setItems({ container: this.getElement({ name: "Contributions" }), items: contributions });
					}

					const posts =  data[r8.providers.posts.name];
					if (posts && request.targetId) {
						simple.Discussion.setItems({ container: this.getElement({ name: "Discussion" }), items: posts });

						this.executeState({ batch: { descriptors: ["App.Contribute$Discussion$Enter"], backHandleMode: "All" } });
					}
				}
			});

			this.executeCommand({ container, stateContainer, command: { name: "App.Contribute$LoadState" } });

			this.initialized = true;
		}
	}

	leave() {
	}

	static templates() {
		return [
			{ name: "r8.views.contribute", url: "../html/app/views/contribute.html" },
			{
				name: "r8.views.contribute.contribution.range.render",
				url: "../html/app/views/contribute/contribution.range.render.html"
			},
			{
				name: "r8.views.contribute.contribution.range.export",
				url: "../html/app/views/contribute/contribution.range.export.html"
			},
			{
				name: "r8.views.contribute.contribution.point.render",
				url: "../html/app/views/contribute/contribution.point.render.html"
			},
			{
				name: "r8.views.contribute.contribution.point.export",
				url: "../html/app/views/contribute/contribution.point.export.html"
			},
			{
				name: "r8.views.contribute.discussion.post.render",
				url: "../html/app/views/contribute/discussion.post.render.html"
			},
			{
				name: "r8.views.contribute.discussion.post.export",
				url: "../html/app/views/contribute/discussion.post.export.html"
			}
		];
	}
}