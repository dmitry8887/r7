﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace r8.Models
{
    public class ContributionResult
    {
        [JsonProperty(PropertyName = "contribution")]
        public Contribution Contribution { get; set; }

        [JsonProperty(PropertyName = "posts")]
        public List<Post> Posts { get; set; }
    }
}