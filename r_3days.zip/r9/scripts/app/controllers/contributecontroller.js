const ContributeController = ({ application }) => {
    const { Element, Symbols, Browser } = Utils;

    const getData = () => alert("getData!");

    return (new class extends Controller {
        constructor() {
            super({
                elements: {
                },
                states: {
                },
                application,
                routes:
                    [
                        {
                            hash: "#contribute", default: true, fallBack: true,
                            handle: () => getData()
                            // this.GetData().then(this.SetData).then(this.execute({ batch: { descriptors: ["Chart$Enter"] } }))

                        },
                        {
                            hash: "#contribute/contributions",
                            handle: () => this.GetData({ providers: [r8.QuotesProvider] }).then(() => this.execute({ batch: { descriptors: ["Contributions$Enter"] } }))
                        },
                        {
                            hash: "#contribute/contributions/create", handle: () => {
                                this.execute({ batch: { states: [{ descriptor: "Contribution$Enter", value: { mode: "Add" } }] } });
                                return Promise.resolve();
                            }
                        }
                    ],
                create: container => {
                    throw "Not Implmeneted";
                }
            });
        }
    });
}