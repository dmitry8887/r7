﻿r8.providers.quotes = {
  name: "Quotes",
  fetch: ({ request }) => r8.services.quotes.get(request).then(data => Object.assign(data, { name: r8.providers.quotes.name })),
  merge: ({ container, data }) => {
    const providerName = r8.providers.quotes.name;
    const setData = ({ data }) => container.expandos.data[providerName] = data;
    const getData = ()=> container.expandos.data[providerName];

    const existingData = getData();

    if (existingData) {
      debugger;
      data = existingData.map((seria, index) => [seria, ...data[index]]);
    }

    setData({ data });
  },
  filter: ({ container, request }) => {
    const providerName = r8.providers.quotes.name;
    const data = container.expandos.data[r8.providers.quotes.name];
    const { from, to } = request;
    
    const filteredData = data.map(seria => seria.points.filter(point => {
      seria.min = Math.min(seria.minM || Number.POSITIVE_INFINITY, point.m);
      seria.max = Math.max(seria.maxM || Number.NEGATIVE_INFINITY, point.m);

      return point.o >= from && point.o <= to;
    })); 

    filteredData.forEach((seria, index) => {
      seria.min = data[index].min;
      seria.max = data[index].max;
    });

    filteredData.name = r8.providers.quotes.name;
    filteredData.from = request.from;
    filteredData.to = request.to;
    filteredData.frame = request.frame;
    
    return filteredData;
  }
};

r8.providers.contributions = {
  name: "Contributions",
  fetch: ({ request }) => r8.services.contributions.get(request).then(data => Object.assign(data, { name: r8.providers.contributions.name })),
  merge: ({ container, data }) => {
    const name = r8.providers.contributions.name;
    const setData = ({ data }) => container.expandos.data[name] = data;
    const getData = ()=> container.expandos.data[name];
    const existingData = getData();
    if (existingData) {
      debugger;
      data = existingData.map((seria, index) => [seria, ...data[index]]);
    }
    setData({ data });
  },
  filter: ({ container, request }) => {
    const name = r8.providers.contributions.name;
    const data = container.expandos.data[name];
    data.name = name;
    return data;
  }
};

r8.providers.posts = {
	name: "Posts",
	fetch: ({ request }) => r8.services.posts.get(request).then(data => Object.assign(data, { name: r8.providers.posts.name })),
	merge: ({ container, data }) => {
		const name = r8.providers.posts.name;
		const setData = ({ data }) => container.expandos.data[name] = data;
		const getData = ()=> container.expandos.data[name];
		const existingData = getData();

		if (existingData) {
			debugger;
			data = existingData.map((seria, index) => [seria, ...data[index]]);
		}

		setData({ data });
	},
	filter: ({ container, request }) => {
		const name = r8.providers.posts.name;
		return request.targetId ? Object.assign(container.expandos.data[r8.providers.posts.name], { name }) : { name };
	}
};