﻿// 114
// 95
// 125 (+)
"use strict";

r8.controllers.Contribute = class extends simple.Controller {
  get routing() {
    return { route: "App$Contribute", "default": true, hash: "contribute" };
  }

  constructor(resolver) {
    super({
      resolver,
      elements: {
        DateFrom: "date_from",
        DateTo: "date_to",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor",
        Contribute: "contribute"
      },
      states: 
      [
        { 
          descriptor: "App.Contribute$NamesEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "NamesEditor" }), items: r8.services.metadata.names(), selectedIds: stored.nameIds });
          }
        },
        {
          descriptor: "App.Contribute$TagsEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "TagsEditor" }), items: r8.services.metadata.tags(), selectedIds: stored.tagIds });
          }
        }
      ]
    });
  }

  enter() {
    if (this.initialized !== true) {
      this.getAppContainer().querySelector("#view").innerHTML = simple.Storage.getText({ name: "r8.views.contribute" });
      this.init();

      const stored = simple.Storage.getValue({
        name: "r8.storage.contribute",
        defaultValue: {
          from: 24056640,
          to: 24145920,
          frame: 1440,
          nameIds: ["GLTZUR", "DUSVJL"],
          activeNameId: "GLTZUR",
          tagIds: ["T1", "T3"]
        }
      });
      
      simple.Date.init({ container: this.getElement({ name: "DateFrom" }), value: stored.from });
      simple.Date.init({ container: this.getElement({ name: "DateTo" }), value: stored.to });

      simple.List.init({
        container: this.getElement({ name: "Names" }),
        items: r8.services.metadata.names().filter(name=> stored.nameIds.indexOf(name.id) > -1),
        selectedIds: [stored.activeNameId],
        on: ({ ids, selectedIds }) => {
          simple.Storage.setValue({ name: "r8.storage.contribute", mutator:(value) => {
            value.nameIds = ids;
            value.activeNameId = selectedIds[0];

            return value;
          }});
        }
      });

      simple.List.init({
        container: this.getElement({ name: "Tags" }),
        items: r8.services.metadata.tags().filter(tag => stored.tagIds.indexOf(tag.id) > -1),
        selectedIds: stored.tagIds,
        on: ({ ids }) => {
          simple.Storage.setValue({ name: "r8.storage.contribute", mutator:(value)=> {
            value.tagIds = ids; 
            return value;
          }});
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "NamesEditor" }),
        on: ({ selectedIds }) => {
          simple.Storage.setValue({name: "r8.storage.contribute", mutator:(value) => {
            const nameIds = selectedIds;
            let activeNameId = value.activeNameId;

            if (nameIds.indexOf(activeNameId) < 0){
              activeNameId = nameIds[0];
            }

            value.nameIds = nameIds;
            value.activeNameId = activeNameId;
            debugger;

            return value;
          }});

          simple.Navigator.apply();
        }
      });

      simple.Picker.init({ 
        container: this.getElement({ name: "TagsEditor" }), on: ({ selectedIds }) => {
          simple.Storage.setValue({ name: "r8.storage.contribute", mutator:(value) => {
            value.tagIds = selectedIds; 
            return value;
          }});

          simple.Navigator.apply();
        }
      });

      const contribute =  this.getElement({ name:"Contribute"});

      simple.Data.init({ container: contribute,
        provodiers: 
          [
            r8.providers.quotes, r8.providers.bands
          ] // check if they are really async
      , on: (results) =>{
      }});


      simple.Data.request({container: contribute});

      this.initialized = true;
    }
  }

  leave() {
  }

  static templates() {
    return [
      { name: "r8.views.contribute", url: "../html/app/views/contribute.html" }
    ];
  }
}