﻿using System;
using System.Data;

namespace BookKeeper.Models
{
    public class Expense
    {
        public static readonly Func<IDataReader, Expense> DataReaderCreator = (reader) => new Expense()
        {
            Id = (int)reader["Id"],
            UserId = (int)reader["UserId"],
            Date = (DateTime)reader["Date"],
            CategoryId = (int)reader["CategoryId"],
            Amount = (decimal)reader["Amount"]
        };
        
        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public int Id { get; private set; }

        public int UserId { get; set; }

        public int CategoryId { get; set; }
        
        public DateTime Date { get; set; }

        public decimal Amount { get; set; }
    }
}
