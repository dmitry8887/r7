﻿"use strict";

// TODO: exclude asynchornous for Discuss.Enter

r8.controllers.Contribute = class extends simple.Controller {

  // TODO: possibly move configuration to the routing
  get properties() {
    return { route: "App$Contribute", startup: true, fallback: true, hash: "contribute", name: "Contribute" };
  }

  get authenticate() {
    var appController = simple.Application.getController({ container: this.getStateContainer(), name: "App" });

    return appController.authenticate.bind(appController);
  }

  get run() {
    var appController = simple.Application.getController({ container: this.getStateContainer(), name: "App" });
    return appController.run.bind(appController);
  }

  constructor({ resolver }) {
    super({
      resolver,
      init: function({ appContainer }) {
        appContainer.querySelector("#app_view_container").innerHTML =
          simple.Utils.getHtmlImportText({ name: "Contribute" });
        return appContainer.querySelector("#contribute");
      },
      elements: {
        Contribute: "contribute",
        DateRange: "date_range",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor",
        Chart: "chart",
        Contributions: "contributions",
        ContributionsFilter: "contributions_filter",
        ContributionsLauncher: "contributions_launcher",
        ContributionsSummary: "contributions_summary",
        ContributionsPanel: "contributions_panel",
        DatesEditor: "dates_editor",
        DatesEditorSlider: "dates_editor_slider",
        DatesEditorDateRange: "dates_editor_date_range",
        DatesEditorDone: "dates_editor_done",
        DataPadding: "data_padding",
        DataZoom: "data_zoom",
        ContributionCreate: "contribution_create",
        ContributionAdd: "contribution_add",
        Contribution: "contribution",
        ContributionNames: "contribution_names",
        ContributionTags: "contribution_tags",
        ContributionNamesEditor: "contribution_names_editor",
        ContributionTagsEditor: "contribution_tags_editor",
        ContributionNamesEditorLauncher: "contribution_names_editor_launcher",
        ContributionTagsEditorLauncher: "contribution_tags_editor_launcher",
        ContributionOverlay: "contribution_overlay",
        ContributionDateRange: "contribution_date_range",
        ContributionDatesEditorDateRange: "contribution_dates_editor_date_range",
        ContributionDatesEditor: "contribution_dates_editor",
        ContributionDatesEditorSlider: "contribution_dates_editor_slider",
        ContributionType: "contribution_type",
        ContributionPointDirection: "contribution_point_direction",
        ContributionPoint: "contribution_point",
        ContributionPointCloseMode: "contribution_point_close_mode",
        ContributionPointRiskEstimate: "contribution_point_risk_estimate",
        ContributionPointVolumeEstimate: "contribution_point_volume_estimate",
        ContributionPointLeverageEstimate: "contribution_point_leverage_estimate",
        ContributionPointAddCloseButton: "contribution_point_add_close_button",
        ContributionPointRemoveCloseButton: "contribution_point_remove_close_button",
        ContributionPointCloseRow: "contribution_point_close_row",
        ContributionPointMoreButton: "contribution_point_more_button",
        ContributionPointLessButton: "contribution_point_less_button",
        ContributionPointVolumeRow: "contribution_point_volume_row",
        ContributionPointLeverageRow: "contribution_point_leverage_row",
        ContributionPointOpenLower: "contribution_point_open_lower",
        ContributionPointOpenHigher: "contribution_point_open_higher",
        ContributionDatesEditorDone: "contribution_dates_editor_done",
        DiscussionOverlay: "discussion_overlay",
        DiscussionContext: "discussion_context",
        Discussion: "discussion"
      },
      states:
      [
        {
          name: "Contribute$NamesEditor",
          group: "Editors",
          enter: () => simple.Picker.setItems({
            container: this.getElement({ name: "NamesEditor" }),
            stateContainer: this.getStateContainer(),
            items: r8.services.metadata.names(),
            selectedIds: simple.List.selectedIds
              .parse({ ids: simple.Storage.getValue({ path: "r8.contribute" }).names }).ids
          })
        },
        {
          name: "Contribute$TagsEditor",
          group: "Editors",
          enter: () => simple.Picker.setItems({
            container: this.getElement({ name: "TagsEditor" }),
            stateContainer: this.getStateContainer(),
            items: r8.services.metadata.tags(),
            selectedIds: simple.Storage.getValue({ path: "r8.contribute" }).tags
          })
        },
        {
          name: "Contribute$DatesEditor",
          enter: ({ descriptor, from, to, hasToDate }) => simple.DateRange.setOptions({
            container: this.getElement({ name: "DatesEditorDateRange" }),
            stateContainer: this.getStateContainer(),
            descriptor,
            from,
            to,
            hasToDate
          }),
          leave: () => simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) })
        },
        {
          name: "Contribute$Contribution",
          enter: () => {
            this.executeState({ batch: { descriptors: ["Contribute$ContributionRange$Enter"] } });

            const { from, to, names, tags } = simple.Storage.getValue({ path: "r8.contribute" });
            const { ids } = simple.List.selectedIds.parse({ ids: names });

            simple.DateRange.setOptions({
              container: this.getElement({ name: "ContributionDateRange" }),
              from,
              to
            });

            simple.List.setItems({
              container: this.getElement({ name: "ContributionNames" }),
              stateContainer: this.getStateContainer(),
              items: r8.services.metadata.names().filter(name => ids.includes(name.id)),
              selectedIds: ids
            });

            simple.List.setItems({
              container: this.getElement({ name: "ContributionTags" }),
              stateContainer: this.getStateContainer(),
              items: r8.services.metadata.tags().filter(tag => tags.includes(tag.id)),
              selectedIds: tags
            });
          }
        },
        {
          name: "Contribute$ContributionRange",
          group: "ContributionType",
          backable: false,
          enter: function() {
            this.executeState({ batch: { descriptors: ["Contribute$ContributionHasToDate$Enter"] } });
            simple.RadioList.setSelectedId({
              container: this.getElement({ name: "ContributionType" }),
              id: "Range"
            });
          }
        },
        {
          name: "Contribute$ContributionPoint",
          group: "ContributionType",
          backable: false,
          enter: function() {
            this.executeState({
              batch: {
                descriptors: [
                  "Contribute$ContributionPointMore$Leave",
                  "Contribute$ContributionPointHasClose$Leave"
                ]
              }
            });

            // TODO: use Input.clear()
            [
              "ContributionPointRiskEstimate", "ContributionPointVolumeEstimate",
              "ContributionPointLeverageEstimate"
            ].forEach(
              name =>
              simple.Spinner.setSelectedId({ container: this.getElement({ name }), id: "None" }));
          }
          // leave: () => simple.DateRange.setHasToDate({ container: this.getElement({ name: "ContributionDateRange" }), appContainer: this.getAppContainer(), hasToDate: true })
        },
        {
          name: "Contribute$ContributionPointHasClose",
          enter: () => simple.DateRange.setHasToDate({
            container: this.getElement({ name: "ContributionDateRange" }),
            stateContainer: this.getStateContainer(),
            hasToDate: true
          }),
          leave: () => simple.DateRange.setHasToDate({
            container: this.getElement({ name: "ContributionDateRange" }),
            stateContainer: this.getStateContainer(),
            hasToDate: false
          })
        },
        {
          name: "Contribute$ContributionDatesEditor",
          enter: ({ descriptor }) => {
            const { from, to, hasToDate } =
              simple.DateRange.getOptions({
                container: this.getElement({ name: "ContributionDateRange" })
              });

            simple.DateRange.setOptions({
              container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
              stateContainer: this.getStateContainer(),
              descriptor,
              hasToDate,
              from,
              to
            });
          }
        },
        {
          name: "Contribute$ContributionDatesEditor",
          leave: () => simple.DateRange.deactivate({
            container: this.getElement({ name: "ContributionDateRange" })
          })
        },
        {
          name: "Contribute$ContributionNamesEditor",
          group: "ContributionEditors",
          enter: () => simple.Picker.setItems({
            container: this.getElement({ name: "ContributionNamesEditor" }),
            stateContainer: this.getAppContainer(),
            items: r8.services.metadata.names(),
            selectedIds: simple.List.getSelectedIds({
              container: this.getElement({ name: "ContributionNames" })
            })
          })
        },
        {
          name: "Contribute$ContributionTagsEditor",
          group: "ContributionEditors",
          enter: () => simple.Picker.setItems({
            container: this.getElement({ name: "ContributionTagsEditor" }),
            items: r8.services.metadata.tags(),
            selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionTags" }) })
          })
        }
      ]
    });
  }

  enter() {
    if (!this.initialized()) {
      super.init();

      const stateContainer = this.getStateContainer();

      const like = ( /*{ originator, id }*/) => { debugger; };

      const share = ( /*{ originator, id }*/) => { debugger; };

      simple.DateRange.init({
        container: this.getElement({ name: "DateRange" }),
        on: ({ name, descriptor }) => {
          if (name === "Activate") {
            const { from, to, hasToDate } =
              simple.DateRange.getOptions({ container: this.getElement({ name: "DateRange" }) });

            this.executeState({
              batch: {
                states: [{ descriptor: "Contribute$DatesEditor$Enter", value: { descriptor, from, to, hasToDate } }],
                backableDirections: "Enter"
              }
            });
          }
        }
      });

      simple.DateRange.init({
        container: this.getElement({ name: "DatesEditorDateRange" }),
        stateContainer,
        getSlider: () => this.getElement({ name: "DatesEditorSlider" })
      });

      simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }) });

      simple.CheckboxList.init({
        container: this.getElement({ name: "ContributionsFilter" }),
        items: r8.services.metadata.contributionsFilterCategories(),
        on: ({ value }) => simple.List.filter({
          container: this.getElement({ name: "Contributions" }),
          filter: ({ item }) =>
            value.length === 0 ||
            value.length === 2 ||
            value.includes("range") && item.type === "Range" ||
            value.includes("point") && item.type === "Point"
        })
      });

      simple.List.init({
        container: this.getElement({ name: "Contributions" }),
        stateContainer,
        template: ({ item, mode }) => {
          return simple.Utils.interpolate({
            name: {
              "Range.Render": "Contribute.ContributionRangeRender",
              "Range.Export": "Contribute.ContributionRangeExport",
              "Point.Render": "Contribute.ContributionPointRender",
              "Point.Export": "Contribute.ContributionPointExport"
            }[`${item.type}.${mode}`],
            context: { item }
          });
        },
        emptyText: "No Contributions.",
        commands:
        [
          { name: "Like", handle: like },
          {
            name: "Discuss",
            handle: ({ /*originator,*/ id }) => {
              debugger;

              this.getElement({ name: "DiscussionContext" }).innerHTML =
                simple.List.exportItem({ container: this.getElement({ name: "Contributions" }), id });

              const request =
                Object.assign(simple.Data.getRequest({ container: this.getElement({ name: "Contribute" }) }),
                  { externalId: id });
              
              simple.Data.request({
                container: this.getElement({ name: "Contribute" }),
                providerNames: [r8.PostsProvider].map(provider => provider.name),
                force: true,
                request
              }).then(({ data }) => {
                const posts = data[r8.PostsProvider.name];

                simple.Discussion.setExternalId({ container: this.getElement({ name: "Discussion" }), id });

                simple.Discussion.setItems({
                  container: this.getElement({ name: "Discussion" }),
                  stateContainer: this.getStateContainer(),
                  items: posts
                });

                this.executeState({
                  batch: { descriptors: ["Contribute$Discussion$Enter"], backableDirections: "Enter" }
                });
              });
            }
          },
          { name: "Share", handle: share }
        ]
      });

      ["ContributionNames", "ContributionTags"].forEach(name => {
        simple.List.init({ container: this.getElement({ name }), stateContainer });
      });

      simple.Picker.init({
        container: this.getElement({ name: "ContributionNamesEditor" }),
        stateContainer,
        filter: {
          categories: r8.services.metadata.nameCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ name, selectedIds }) => {
          switch (name) {
          case "Change":
            simple.List.setItems({
              container: this.getElement({ name: "ContributionNames" }),
              items: r8.services.metadata.names().filter(name => selectedIds.includes(name.id)),
              selectedIds
            });
            simple.Application.apply();
            break;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "ContributionTagsEditor" }),
        stateContainer,
        filter: {
          categories: r8.services.metadata.tagCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ name, selectedIds }) => {
          switch (name) {
          case "Change":
            simple.List.setItems({
              container: this.getElement({ name: "ContributionTags" }),
              items: r8.services.metadata.tags().filter(name => selectedIds.includes(name.id)),
              selectedIds: selectedIds
            });
            simple.Application.apply();
            break;
          }
        }
      });

      simple.DateRange.init({
        container: this.getElement({ name: "ContributionDateRange" }),
        stateContainer,
        on: ({ name, descriptor }) => {
          if (name === "Activate") {
            const { from, to, hasToDate } =
              simple.DateRange.getOptions({
                container: this.getElement({ name: "ContributionDateRange" })
              });

            this.executeState({
              batch: {
                states: [
                  { descriptor: "Contribute$ContributionDatesEditor$Enter", value: { descriptor, from, to, hasToDate } }
                ],
                backableDirections: "Enter"
              }
            });
          }
        }
      });

      simple.Slider.init({ container: this.getElement({ name: "ContributionDatesEditorSlider" }), stateContainer });

      simple.DateRange.init({
        container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
        stateContainer,
        getSlider: () => this.getElement({ name: "ContributionDatesEditorSlider" })
      });

      simple.RadioList.init({
        container: this.getElement({ name: "ContributionType" }),
        items: r8.services.metadata.contributionTypes(),
        selectedId: "Range",
        on: ({ name, id, manual }) => {
          const descriptor =
          {
            Range: "Contribute$ContributionRange$Enter",
            Point: "Contribute$ContributionPoint$Enter"
          }[id];

          switch (name) {
          case "Select":
            if (!descriptor) {
              throw `Invalid Contribution Type: '${id}'`;
            }
            this.executeState({ batch: { descriptors: [descriptor] } });
            break;
          default:
            throw `Invalid Command: '${name}'`;
          }
        }
      });

      simple.RadioList.init({
        container: this.getElement({ name: "ContributionPointDirection" }),
        stateContainer,
        items: r8.services.metadata.contributionPointDirections(),
        selectedId: "Buy"
      });

      simple.RadioList.init({
        container: this.getElement({ name: "ContributionPointCloseMode" }),
        stateContainer,
        items: r8.services.metadata.contributionPointCloseModes(),
        selectedId: "Manual"
      });

      ["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"]
        .forEach(
          name => simple.Spinner.init({
            container: this.getElement({ name }),
            items: r8.services.metadata.estimates()
          }));

      simple.Discussion.init({
        container: this.getElement({ name: "Discussion" }),
        stateContainer,
        template: ({ item, mode }) => {
          const name = {
            "Post.Render": "Contribute.DiscussionPostRender",
            "Post.Export": "Contribute.DiscussionPostExport"
          }[`Post.${mode}`];

          return simple.Utils.interpolate({ name, context: { item } });
        },
        commands: [{ name: "Like", handle: like }],
        indent: 30,
        on: ({ name, value }) => {
          switch (name) {
          case "PostAdd":
            this.authenticate({ allowGuestLogin: true }).then((result) => {
              if (result.action !== "Continue") {
                return; // TODO: only resolve when action === Continue
              }

              // TODO: re-query posts
              this.run({
                action: () => {
                  return new Promise((resolve) => {
                    r8.services.posts.add(value).then((/*result*/) => {
                      // TODO: check status
                      simple.Application.apply();
                      resolve();
                    });

                  });
                }
              });
            });

            break;
          }
        }
      });

      simple.Data.init({
        container: this.getElement({ name: "Contribute" }),
        providers: [r8.QuotesProvider, r8.ContributionsProvider, r8.PostsProvider]
      });

      const loadState = () => {
        console.info("Load state");

        const stateContainer = this.getStateContainer();

        const state = simple.Storage.getValue({
          path: "r8.contribute",
          defaultValue: r8.services.app.getDefaultState()
        });

        let { ids, selectedId } = simple.List.selectedIds.parse({ ids: state.names });

        simple.List.setItems({
          container: this.getElement({ name: "Names" }),
          stateContainer,
          items: r8.services.metadata.names().filter(name => ids.includes(name.id)),
          selectedIds: [selectedId]
        });

        ids = simple.List.selectedIds.parse({ ids: state.tags }).ids;

        simple.List.setItems({
          container: this.getElement({ name: "Tags" }),
          stateContainer,
          items: r8.services.metadata.tags().filter(tag => ids.includes(tag.id)),
          selectedIds: ids
        });

        simple.DateRange.setOptions({
          container: this.getElement({ name: "DateRange" }),
          stateContainer,
          from: state.from,
          to: state.to
        });

        this.run({
          action: () => {
            return new Promise((resolve) => {
              simple.Data.request({
                container: this.getElement({ name: "Contribute" }),
                providerNames: [r8.QuotesProvider, r8.ContributionsProvider].map(provider => provider.name),
                request: state
              }).then(
                ({ data, request, padding }) => {
                  this.getElement({ name: "DataPadding" }).innerHTML =
                    simple.Utils.interpolate({ name: "Contribute.DataPadding", context: padding });

                  const quotes = data[r8.QuotesProvider.name];
                  if (quotes) {
                    simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
                  }

                  const contributions = data[r8.ContributionsProvider.name];
                  if (contributions) {
                    simple.List.setItems({
                      container: this.getElement({ name: "Contributions" }),
                      stateContainer,
                      items: contributions
                    });
                  }

                  resolve();
                });
            });
          }
        });
      };

      simple.Chart.init({
        container: this.getElement({ name: "Chart" }),
        stateContainer,
        bands: [r8.bands.weekDays],
        on: ({ name, value }) => {
          const $contribute = this.getElement({ name: "Contribute" });
          const from = value ? value.from : null;
          const to = value ? value.to : null;

          switch (name) {
          case "Drag":
            simple.Data.request({
              container: $contribute,
              providerNames: [r8.QuotesProvider, r8.ContributionsProvider].map(provider => provider.name),
              request: Object.assign(simple.Data.getRequest({ container: $contribute }), { from, to })
            }).then(({ data, padding, request }) => {
              this.getElement({ name: "DataPadding" }).innerHTML =
                simple.Utils.interpolate({ name: "Contribute.DataPadding", context: padding });

              const quotes = data[r8.QuotesProvider.name];
              if (quotes) {
                simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
              }

              const contributions = data[r8.ContributionsProvider.name];
              if (contributions) {
                simple.List.setItems({
                  container: this.getElement({ name: "Contributions" }),
                  stateContainer,
                  items: contributions
                });
              }
            });

            break;
          case "DragStop":
            simple.Storage.setValue({
              path: "r8.contribute",
              mutator: (value) => {
                value.from = from;
                value.to = to;
                return value;
              }
            });

            loadState();

            break;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "TagsEditor" }),
        stateContainer,
        filter: {
          categories: r8.services.metadata.tagCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ selectedIds }) => {
          simple.Storage.setValue({
            path: "r8.contribute",
            mutator: (value) => {
              value.tags = selectedIds;
              return value;
            }
          });

          simple.Application.apply();
          loadState();
        }
      });

      simple.List.init({
        container: this.getElement({ name: "Tags" }),
        stateContainer,
        on: ({ ids, selectedIds, name }) => {
          switch (name) {
          case "Change":
            simple.Storage.setValue({
              path: "r8.contribute",
              mutator: (value) => {
                value.tags = ids;
                return value;
              }
            });

            loadState();

            break;
          default:
            throw `Invalid Event:${name}`;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "NamesEditor" }),
        stateContainer,
        filter: {
          categories: r8.services.metadata.nameCategories(),
          handle: r8.services.metadata.match
        },
        on: ({ selectedIds }) => {
          simple.Storage.setValue({
            path: "r8.contribute",
            mutator: (value) => {
              const names = selectedIds;
              let selectedName = simple.List.selectedIds.parse({ ids: names }).selectedId;
              selectedName = names.includes(selectedName) ? selectedName : names[0];

              value.names = simple.List.selectedIds.build({ ids: names, selectedId: selectedName });
              return value;
            }
          });

          simple.Application.apply();
          loadState();
        }
      });

      simple.List.init({
        container: this.getElement({ name: "Names" }),
        stateContainer,
        on: ({ ids, selectedIds, name }) => {
          switch (name) {
          case "Change":
          case "Select":
            simple.Storage.setValue({
              path: "r8.contribute",
              mutator: (value) => {
                value.names = simple.List.selectedIds.build({ ids, selectedId: selectedIds[0] });
                return value;
              }
            });

            loadState();

            break;
          default:
            throw `Invalid Event:${name}`;
          }
        }
      });

      this.addEventHandles({
        name: "ContributionDatesEditorDone",
        events: "click",
        handle: () => {
          const { from, to, hasToDate } = simple.DateRange.getOptions({
            container: this.getElement({ name: "ContributionDatesEditorDateRange" })
          });

          simple.DateRange.setOptions({
            container: this.getElement({ name: "ContributionDateRange" }),
            stateContainer,
            from,
            to,
            hasToDate
          });

          simple.Application.apply();
        }
      });

      this.addEventHandles({
        name: "DatesEditorDone",
        events: "click",
        handle: () => {
          const { from, to } =
            simple.DateRange.getOptions({ container: this.getElement({ name: "DatesEditorDateRange" }) });

          simple.Storage.setValue({
            path: "r8.contribute",
            mutator: (value) => {
              value.from = from;
              value.to = to;
              return value;
            }
          });

          simple.Application.apply();
          loadState();
        }
      });

      this.addEventHandles({
        name: "ContributionAdd",
        events: "click",
        handle: () => {
          this.authenticate({ allowGuestLogin: true }).then((result) => {
            if (result.action !== "Continue") {
              return; // TODO: only resolve when action === Continue
            }

            this.run({
              action: () => {
                return new Promise((resolve) => {
                  const contribution = simple.Input.get({
                    container: this.getElement({ name: "Contribution" }),
                    handle: ({ name, value, object }) => {
                      switch (name) {
                      case "dateRange":
                        object.from = value.from;
                        object.to = value.to;
                        break;
                      }
                    }
                  });

                  r8.services.contributions.add(contribution).then((/*result*/) => {
                    simple.Data.request({
                      container: this.getElement({ name: "Contribute" }),
                      providerNames: [r8.ContributionsProvider].map(provider => provider.name)
                    }).then(({ data, request, padding }) => {

                      const contributions = data[r8.ContributionsProvider.name];
                      if (contributions) {
                        simple.List.setItems({
                          container: this.getElement({ name: "Contributions" }),
                          stateContainer: this.getStateContainer(),
                          items: contributions
                        });
                      }

                      simple.Application.apply();
                      resolve();
                    });
                  });
                });
              }
            });
          });
        }
      });

      loadState();
    }
  }

  leave() {
    super.detach();
  }
};