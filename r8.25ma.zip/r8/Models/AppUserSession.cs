﻿using System;

namespace r8.Models
{

  public class AppUserSession
  {
    public int AppUserId
    {
      get;
      set;
    }

    public string Token
    {
      get;
      set;
    }

    public string Ip
    {
      get;
      set;
    }

    public DateTime CreatedDate
    {
      get;
      set;
    }

    public bool Active
    {
      get;
      set;
    }
  }
}