﻿"use strict";

const ResearchController = class extends simple.Controller {
  constructor({ context }) {
    super({
      elements: {
        ResearchDebug: { id: "research_debug" }
      },
      routes:
        [
          {
            hash: "#research",
            handle: () => this.debug()
          }
        ],
      name: "Research",
      context
    });
  }

  debug() {
    debugger;
    return Promise.resolve();
  }

  create({ app }) {
    const element = simple.Dom.getElement({ element: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ element, name: this.name });
    return { element: element.children[0] };
  }

  init() {
    super.init();
    this.getElement({ name: "ResearchDebug" }).innerHTML = "Research Debug";
  }
}