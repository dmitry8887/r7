$ = {
    Symbols: {
        id: Symbol("id"),
        expandos: Symbol("expandos"),
        path: Symbol("path"),
        getParent: Symbol("getParent")
    }
};

$.Element = {};

$.Element.init = ({ element }) => {
    const expandos = element[$.Symbols.expandos];

    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element[$.Symbols.expandos] = Object.entries(element.dataset).reduce((previous, current) => Object.assign(previous, JSON.parse(current[1])), { [$.Symbols.id]: element.id });

    $.Element.getElements({ element }).forEach(element => $.Element.init({ element }));
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.set = ({ element, data }) => {
    const bindings = [];

    $.Element.getElements({ element }).forEach(({ [$.Symbols.expandos]: expandos, [$.Symbols.id]: targetId }) => {
        const { type, binding } = expandos;
        const { get, set } = $.Components[type];
        const { path } = binding;

        let getPathBindings = () => bindings[path];

        if (!getPathBindings()) {
            bindings[path] = [];
            pathBindings = getPathBindings();
        }

        getPathBindings().push({
            targetId,
            get: () => get({ element }),
            set: ({ value }) => set({ element, value })
        });
    });

    const { proxy } = $.Proxy.wrap({
        target: data,
        isScope: ({ path }) => bindings[path] !== undefined,
        handler: ({ isInitial, path, originalPath, originalValue, value, type }) => {

            const binding = bindings[path];
            if (binding) {
                console.error({ isInitial, path, originalPath, originalValue, value, type });

                binding.forEach(({ set }) => set({ value }));
            }
        }
    });

    return proxy;
};

$.Proxy = {};

$.Proxy.unwrap = ({ proxy }) => {
    const target = {};

    if (!proxy) {
        debugger;
    }

    const unwrap = ({ proxy, target }) => {

        if (!proxy){
            debugger;
        }

        Object.entries(proxy).forEach(([key, value]) => {
            if ($.Object.isObject(value)) {
                target[key] = $.Object.isArray(value) ? [] : {};

                unwrap({ wrapped: value, target: target[key] });
            }
            else {
                target[key] = value;
            }
        });

    };

    unwrap({ proxy, target });

    return target;
};

$.Proxy.getTargetPath = ({ target, key }) => [target[$.Symbols.path], key].filter(path => path != undefined).join(".");

$.Proxy.wrap = ({ target, handler, isScope, allowDynamicProperties }) => {
    const getScopedHandler = ({ scope }) => ({
        get: (target, key) => {
            let value = target[key];
            const path = $.Proxy.getTargetPath({ target, key });

            if (!value) {
                throw "Not Implemented";
            }

            if ($.Object.isObject(value)) {
                if (isScope({ path })) {
                    scope = target[key];
                }

                return new Proxy(value, getScopedHandler({ scope }));
            } else {
                return value;
            }
        },
        set: (target, key, value) => {
            const originalPath = $.Proxy.getTargetPath({ target, key });
            const path = $.Proxy.getTargetPath({ target: scope });

            if ($.Object.isObject(value)) {
                value = $.Proxy.unwrap({ proxy: value });

                // adopting
                value = Object.assign(value, { [$.Symbols.path]: originalPath, [$.Symbols.getParent]: () => target });
            }

            target[key] = value;

            const isScopeArray = $.Object.isArray(scope);
            const isElevated = target !== scope;
            const originalValue = value;

            if (isScopeArray) {
                if (isElevated || (!isElevated && key === "length")) {
                    if (isElevated) {
                        const trace = $.Object.trace({ target, scope });
                        value = trace[trace.length - 1];
                    }
                    else {
                        value = scope;
                    }

                    handler({ isInitial: false, path, originalPath, value, originalValue });
                }
            }
            else {
                handler({ isInitial: false, path, originalPath, value, originalValue });
            }

            return true;
        }
    });

    $.Object.getPvps(target).forEach(({ path, value }) => handler({ isInitial: true, path, value }));

    return { proxy: new Proxy(target, getScopedHandler({ scope: target })), handler };
};

$.Object = {};

$.Object.isObject = target => typeof target === "object";

$.Object.isArray = target => Array.isArray(target);

$.Object.setPaths = target => {
    throw "Not Implemented";
}

$.Object.getPvps = target => {
    const pvps = [];

    const process = ({ target }) => {
        Object.entries(target).forEach(([key, value]) => {
            const isObjectValue = $.Object.isObject(value);
            const path = [target[$.Symbols.path], key].filter(path => path !== undefined).join(".");

            if (isObjectValue) {
                value = Object.assign(value, {
                    [$.Symbols.path]: path,
                    [$.Symbols.getParent]: () => target
                });
            }

            pvps.push({ path, value });

            if (isObjectValue) {
                process({ target: value });
            }
        });
    };

    process({ target });

    return pvps;
};

$.Object.adopt = ({ target, value }) => {
    throw "Adopt!";
}

$.Object.trace = ({ target, scope }) => {
    const trace = [];

    while (target !== scope) {
        trace.push(target);
        target = target[$.Symbols.getParent]();
    }

    return trace;
}


$.Components = {};

$.Components.List = class {
    static init({ element }) {
    }

    static get({ element }) {
    }

    static set({ element, value }) {
        console.warn("Binding List", { value });
    }
}

$.Interactable = {};