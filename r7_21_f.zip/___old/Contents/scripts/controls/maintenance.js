﻿// todo : remove as unused

var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};
fxrig.controls.maintenance = new function() {
    // put the visiting logic
    this.init = function(initArgs) {
        initArgs.container.state(initArgs);
    };

    var close = function (closeArgs) {
        closeArgs.container.empty().hide();
    };

    this.launch = function(launchArgs) {
        var $container = launchArgs.container;
        var state = $container.state();

        var html = fxrig.state.getCacheItem({ appName: "fxrig", name: state.name });
        $container.html(html).show();

        $("#apply_button, #cancel_button").on("click", function () {
            close({ container: $container });
        });
    };
};