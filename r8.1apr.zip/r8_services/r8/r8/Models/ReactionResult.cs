﻿using Newtonsoft.Json;

namespace r8.Models
{
  public class ReactionResult
  {
    [JsonProperty(PropertyName = "count")]
    public int Count
    {
      get;
      set;
    }

    [JsonProperty(PropertyName = "message")]
    public string Message
    {
      get;
      set;
    }
  }
}