﻿"use strict";

r8.controllers.App = class extends simple.Controller {
  get routing() {
    return { route: "App" };
  }

  constructor(resolver) {
    super({
      resolver,
      elements:
      {
        appOverlay: "app_overlay",
        appOverlayMessage: "app_overlay_message",
        appOverlayErrorMessage: "app_overlay_error_message",
        appMenu: "app_menu",
        appMenuOverlay: "app_menu_overlay",
        appAppsOverlay: "app_apps_overlay",
        userName: "user_name",
        appMenuUserName: "app_menu_user_name",
        appLoginOverlay: "app_login_overlay",
        appMenuLogin: "app_menu_login",
        appUser: "app_user",
        appMenuLauncher: "app_menu_launcher",
        appViewHeader: "app_view_header",
        appAppsBack: "app_apps_back",
        appAppsLauncher: "app_apps_launcher",
        appMenuBack: "app_menu_back"
      },
      states: []
    });
  }

  enter() {
    if (this.initialized !== true) {
      this.init();

      this.initialized = true;
    }
  }

  leave() {
  }

  static templates() {
    return [];
  }
}