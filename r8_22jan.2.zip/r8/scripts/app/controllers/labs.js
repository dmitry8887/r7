﻿"use strict";

r8.controllers.Labs = class extends simple.Stateful {
  get routing() {
    return { route: "App$Labs", hash: "labs" };
  }

  constructor(resolver) {
    super({ elements: [], states: [] });

    this._resolver = resolver;
  }

  get resolver() {
    return this._resolver;
  }

  get appContainer() {
    return this._appContainer();
  }

  enter() {
    document.querySelector("#view").innerText = "Labs";

    //console.warn(transition);
  }

  leave() {
    //console.warn(transition);
  }

  static templates() {
    return [
      { name: "r8.views.labs", url: "../html/app/views/labs.html" }
    ];
  }
}