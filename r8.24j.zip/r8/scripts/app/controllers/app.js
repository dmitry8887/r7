﻿"use strict";

r8.controllers.App = class extends simple.Stateful {
  get routing() {
    return { route: "App" };
  }

  constructor(resolver) {
    super({
      elements:
      {
        appOverlay: "app_overlay",
        appOverlayMessage: "app_overlay_message",
        appOverlayErrorMessage: "app_overlay_error_message",
        appMenu: "app_menu",
        appMenuOverlay: "app_menu_overlay",
        appAppsOverlay: "app_apps_overlay",
        userName: "user_name",
        appMenuUserName: "app_menu_user_name",
        appLoginOverlay: "app_login_overlay",
        appMenuLogin: "app_menu_login",
        appUser: "app_user",
        appMenuLauncher: "app_menu_launcher",
        appViewHeader: "app_view_header",
        appAppsBack: "app_apps_back",
        appAppsLauncher: "app_apps_launcher",
        appMenuBack: "app_menu_back"
      },
      states:
      [
        //{ descriptor: "App$Menu$Enter", handle: () => {} },
        //{ descriptor: "App$Menu$Leave", handle: () => {} },
        //{ descriptor: "App$Apps$Enter", handle: () => {} },
        //{ descriptor: "App$Apps$Leave", handle: () => {} },
        {
          descriptor: "App$Message$Enter",
          handle: ({ text }) => { elements.$appMessage().html(text || "Loading..."); }
        },
        { descriptor: "App$Message$Leave", handle: () => {} },
        {
          descriptor: "App$Error$Enter",
          handle: ({ text }) => { elements.$appErrorMessage().html(text || "Error."); }
        },
        { descriptor: "App$Error$Leave", handle: () => {} },
        {
          descriptor: "App$User$Enter",
          handle: () => {
            //const userName = r7.app.controllers.app.getUser().userName;

            //elements.$userName().text(userName);
            //elements.$appMenuUserName().text(userName);
          }
        },
        {
          descriptor: "App$User$Leave",
          handle: () => {
            //elements.$userName().text(guestUserName);
            //elements.$appMenuUserName().text(guestUserName);
            //r7.app.controllers.app.logout();
          }
        },
        //{ descriptor: "App$Authenticate$Enter", handle: () => {} },
        //{ descriptor: "App$Authenticate$Leave", handle: () => {} }
      ]
    });

    this._resolver = resolver;
  }

  get resolver() {
    return this._resolver;
  }

  // { transition }
  enter() {
    if (this.initialized !== true) {
      this.init(this.resolver);
      this.initialized = true;
    }

    //console.warn(transition);
  }

  // { transition }
  leave() {
    //console.warn(transition);
  }

  static templates() {
    return [];
  }
}