﻿"use strict";

$.fn.state = function(data) {
    if (data === undefined) {
        if (!this.data("state")) {
            this.data("state", {});
        }
        return this.data("state");
    } else {
        var state =this.data("state");
        if (state) {
            data = _.assign(state, data);
        }
        
        this.data("state", data);
        return data; // this.data("state");
    }
};

// todo: remove
$.fn.style = function(styleArgs) {
    var target;
    var as = styleArgs.as;
    var classNamePrefix;
    var className;

    switch (as) {
        case "sideSlider":
            classNamePrefix = styleArgs.side;
            break;
        case "horizontalSlider":
            classNamePrefix = "horizontal";
            break;
        case "verticalSlider":
            classNamePrefix = "vertical";
            break;
        default:
            throw { message: "Invalid As:" + as };
    }

    // slider
    target = this;
    className = classNamePrefix + "-slider";
    target.addClass(className);

    // slider handle
    target = $(".ui-slider-handle", target);
    className = classNamePrefix + "-slider-handle";
    target.addClass(className);

    return this;
};

$.fn.showEx = function () {
    var $container = $(this);
    var originalDisplay = $container.data("display");

    if (originalDisplay) {
        $container.css("display", originalDisplay);
    }
    else {
        $container.show();
    }
    
    return this;
};


// TODO: remove?
(function ($, sr) {
    var debounce = function(handle, threshold, force) {
        var timeout;

        return function debounced() {
            var obj = this, args = arguments;

            function delayed() {
                if (!force)
                    handle.apply(obj, args);
                timeout = null;
            };

            if (timeout)
                clearTimeout(timeout);
            else if (force)
                handle.apply(obj, args);

            timeout = setTimeout(delayed, threshold || 100);
        };
    };
    
    jQuery.fn[sr] = function (fn) { return fn ? this.bind("resize", debounce(fn)) : this.trigger(sr); };
})(jQuery, "resize2");