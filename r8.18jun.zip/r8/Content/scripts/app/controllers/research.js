﻿"use strict";

const ResearchController = class extends simple.Controller {
  constructor({ context }) {
    super({
      elements: {
        ResearchDebug: "research_debug"
      },
      states: [

      ],
      routes:
        [
          {
            hash: "#research",
            handle: () => this.debug()
          }
        ],
      name: "Research",
      context
    });
  }

  debug(){
    debugger;
    return Promise.resolve();
  }

  create({ app }) {
    const container = simple.Dom.getElement({ container: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ container, name: this.name });
    return { container: container.children[0] };
  }

  init() {
    super.init();

    this.getElement({ name: "ResearchDebug" }).innerHTML = "Research Debug";
  }
}