﻿const simpleApp = {};
simpleApp.controllers = {};

//simpleApp.controllers.app = new function () {
//    this.routing = { route: "app" };

//    this.enter = function () {
//        console.warn(`App Enter from: ${this.from} - to: ${this.to}`);
//    };

//    this.leave = function () {
//        console.warn(`App Leave from: ${this.from} - to: ${this.to}`);
//    };
//};

class SimpleApp extends Simple.Stateful {
    get routing()
    {
        return { route: "app" };
    }

    constructor(){
        super({ states: 1 });
    }

    enter() {
        console.warn(`App Enter from: ${this.from} - to: ${this.to}`);
    }

    leave() {
        console.warn(`App Leave from: ${this.from} - to: ${this.to}`);
    };
}

simpleApp.controllers.app_a = new function () {
    this.routing = { route: "app$app.a", "default": true, hash: "a" };

    this.enter = function () {
        console.warn(`A Enter from: ${this.from} - to: ${this.to}`);

        document.querySelector("#placeholder").innerText = "A";
    };

    this.leave = function () {
        console.warn(`A Leave from: ${this.from} - to: ${this.to}`);
    };
};

simpleApp.controllers.app_b = new function () {
    this.routing = { route: "app$app.b", hash: "b" };

    this.enter = function () {
        console.warn(`B Enter from: ${this.from} - to: ${this.to}`);

        document.querySelector("#placeholder").innerText = "B";
    };

    this.leave = function () {
        console.warn(`B Leave from: ${this.from} - to: ${this.to}`);
    };
};

simpleApp.controllers.app_c = new function () {
    this.routing = { route: "app$app.c", hash: "c" };

    this.enter = function () {
        console.warn(`C Enter from: ${this.from} - to: ${this.to}`);

        document.querySelector("#placeholder").innerText = "C";
    };

    this.leave = function () {
        console.warn(`C Leave from: ${this.from} - to: ${this.to}`);
    };
};

simpleApp.boostrap = () => {
    // simpleApp.controllers.app
    simple.router.init({
        container: document.querySelector("#app"),
        controllers: () =>[new SimpleApp(), simpleApp.controllers.app_a, simpleApp.controllers.app_b, simpleApp.controllers.app_c],
        hash: "a"
    });
};