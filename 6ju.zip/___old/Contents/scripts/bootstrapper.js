﻿var fxrig = fxrig || {};
fxrig.bootstrapper = fxrig.bootstrapper || {};

fxrig.bootstrapper.init = function (e) {
    var $container = e.container;
    
    fxrig.state.setCache({
        appName: $container.data().appName, //todo: possibly hardcode
        items:
        [
            { name: "security", url: "html/cache/security.html" }, // todo: should be app
            { name: "validation_output", url: "html/cache/validation_output.html" },
            { name: "contribution", url: "html/cache/contribution.html" },
            { name: "dates", url: "html/cache/dates.html" },
            { name: "chart", url: "html/cache/chart.html" },
            { name: "point", url: "html/cache/point.html" }, // todo: rename to point_item?
            { name: "range", url: "html/cache/range.html" }, // todo: rename to range_item?
            { name: "item", url: "html/cache/item.html" },
            { name: "discussion", url: "html/cache/discussion.html" },
            { name: "post", url: "html/cache/post.html" },
            { name: "reply", url: "html/cache/reply.html" },
            // apps
            { name: "app.contribute", url: "html/cache/apps/app.contribute.html" },
            { name: "app.shared", url: "html/cache/apps/app.shared.html" }
        ],
        force: true
    }).then(function () {

        var controllers = [
            fxrig.controllers.app,
            fxrig.controllers.app.contribute,
            fxrig.controllers.app.contribute.editor,
            fxrig.controllers.app.research,
            fxrig.controllers.app.labs
        ];

        //var $appContainer = $("#apps", $container);
        //fxrig.apps.init({
        //    container: $appContainer,
        //    interceptors: {
        //        send: function (message) {
        //            alert("send: " + JSON.stringify(message));
        //        },
        //        receive: function (message) {
        //            alert("receive: " + JSON.stringify(message));
        //        }
        //    }
        //});

        // todo: do messaging at the core level
        fxrig.router.init({
            container: $container,
            hash: "contribute",
            defaultHash: "contribute", // todo: merge hash with defaultHash
            controllers: controllers,
            predict: function (transition) {
                fxrig.apps.ensure({ container: $("#apps", $container), transition: transition });
            },
            success: function (successArgs) {
                // todo: set busy to false?
            },
            error: function (errorArgs) {
                console.error(errorArgs);
            }
        });
    });
};

if (!String.prototype.format) {
    String.prototype.format = function () {
        var args = arguments;
        return this.replace(/{(\d+)}/g, function (match, number) {
            return typeof args[number] != 'undefined'
              ? args[number]
              : match
            ;
        });
    };
};

Array.prototype.contains = function (v) {
    for (var i = 0; i < this.length; i++) {
        if (this[i] === v) return true;
    }
    return false;
};

Array.prototype.unique = function () {
    var arr = [];
    for (var i = 0; i < this.length; i++) {
        if (!arr.contains(this[i])) {
            arr.push(this[i]);
        }
    }
    return arr;
};

// todo: loop through recursively and crete nodes for each level
Storage.prototype.setObject = function (key, value) {
    this.setItem(key, JSON.stringify(value));
}

Storage.prototype.getObject = function (key) {
    return JSON.parse(this.getItem(key));
}
