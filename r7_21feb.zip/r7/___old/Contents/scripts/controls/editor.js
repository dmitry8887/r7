﻿"use strict";

var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};

// todo: delete
fxrig.controls.editor = new function () {
   
};