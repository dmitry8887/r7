

$ = {
    Symbols: {
        id: Symbol("id"),
        expandos: Symbol("expandos"),
        path: Symbol("path"),
        getParent: Symbol("getParent")
    },
    // TODO: move to $.Object
    isObject: (value) => typeof value === "object",
    isArray: (value) => Array.isArray(value),
};

$.Element = {};

$.Element.init = ({ element }) => {
    const expandos = element[$.Symbols.expandos];

    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element[$.Symbols.expandos] = Object.entries(element.dataset).reduce((previous, current) => Object.assign(previous, JSON.parse(current[1])), { [$.Symbols.id]: element.id });

    $.Element.getElements({ element }).forEach(element => $.Element.init({ element }));
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.set = ({ element, data }) => {
    const bindings = [];

    $.Element.getElements({ element }).forEach(({ [$.Symbols.expandos]: expandos, [$.Symbols.id]: targetId }) => {
        const { type, binding } = expandos;
        const { get, set } = $.Components[type];
        const { path } = binding;

        let getPathBindings = () => bindings[path];

        if (!getPathBindings()) {
            bindings[path] = [];
            pathBindings = getPathBindings();
        }

        getPathBindings().push({
            targetId,
            get: () => get({ element }),
            set: ({ value }) => set({ element, value })
        });
    });

    const { proxy } = $.Proxy.wrap({
        target: data,
        isScope: ({ path }) => bindings[path] !== undefined,
        handler: ({ isInitial, path, originalPath, originalValue, value, type }) => {
            if (!isInitial) {
                debugger;
            }

            const binding = bindings[path];
            if (binding) {
                binding.forEach(({ set }) => set({ value }));
            }
        }
    });

    return proxy;
};

$.Proxy = {};
$.Proxy.unwrap = ({ proxy }) => {
    const target = {};

    const unwrap = ({ proxy, target }) => Object.entries(proxy).forEach(([key, value]) => {
        if ($.isObject(value)) {
            target[key] = Array.isArray(value) ? [] : {};

            unwrap({ wrapped: value, target: target[key] });
        }
        else {
            target[key] = value;
        }
    });

    unwrap({ proxy, target });

    return target;
};

$.Proxy.wrap = ({ target, handler, isScope, allowDynamicProperties }) => {
    // TODO: make a custom object, so it can pass to both get & set paths for the target and values instead of caculating it every time!
    const getScopedHandler = ({ scope }) => ({
        get: (target, key) => {
            let value = target[key];

            if (!value) {
                if (allowDynamicProperties !== true) {
                    debugger;
                }

                value = {
                    [$.Symbols.path]: [target[$.Symbols.path], key].filter(path => path != undefined).join("."),
                    [$.Symbols.getParent]: () => target
                };

                target[key] = value; // TODO: watch
            }

            if ($.isObject(value)) {
                debugger;

                if (isScope({ path: [target[$.Symbols.path]] })) {

                    debugger;

                    scope = target;
                }

                return new Proxy(value, getScopedHandler({ scope }));
            } else {
                return value;
            }
        },
        // TODO: when assigning an object don't forget to change its' getParent return
        set: (target, key, value) => {
            target[key] = value;

            const originalPath = [target[$.Symbols.path], key].filter(path => path !== undefined).join(".");
            const path = scope[$.Symbols.path];

            const originalValue = value;

            const isScopeArray = $.isArray(scope);
            const isElevated = target !== scope;

            let type = "";

            if (isScopeArray) {
                if (isElevated) {
                    const trace = $.Object.trace({ target, scope });
                    value = trace[trace.length - 1];

                    type = "ArrayMember";
                }
            }

            debugger;
            handler({ isInitial: false, path, originalPath, value, originalValue, type });

            return true;
        }
    });

    $.Object.getPvps(target).forEach(({ path, value }) => handler({ isInitial: true, path, value }));

    return { proxy: new Proxy(target, getScopedHandler({ scope: target })), handler };
};

$.Proxy.unwrap = ({ proxy }) => {

};

$.Components = {};
$.Components.List = class {
    static init({ element }) {
    }

    static get({ element }) {
    }

    static set({ element, value }) {
        console.warn("Binding List", { value });
    }
}


$.Object = {};
$.Object.getPvps = target => {
    const pvps = [];

    const process = ({ target }) => {
        Object.entries(target).forEach(([key, value]) => {
            const isObjectValue = $.isObject(value);
            const path = [target[$.Symbols.path], key].filter(path => path !== undefined).join(".");

            if (isObjectValue) {
                value = Object.assign(value, { [$.Symbols.path]: path, [$.Symbols.getParent]: () => target });
            }

            pvps.push({ path, value });

            if (isObjectValue) {
                process({ target: value });
            }
        });
    };

    process({ target });

    return pvps;
};

$.Object.trace = ({ target, scope }) => {
    const trace = [];

    while (target !== scope) {
        trace.push(target);
        target = target[$.Symbols.getParent]();
    }

    return trace;
}

$.Interactable = {};


