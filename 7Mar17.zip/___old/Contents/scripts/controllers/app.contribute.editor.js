﻿"use strict";

var fxrig = fxrig || {};
fxrig.controllers = fxrig.controllers || {};
fxrig.controllers.app = fxrig.controllers.app || {}; // todo: review - we don't want to override it
fxrig.controllers.app.contribute = fxrig.controllers.app.contribute || {};

// remove it's not a screen
fxrig.controllers.app.contribute.editor = new function() {
    this.hash = "contribute/eidtor";
    this.url = "html/views/contribute/editor.html";
    this.route = "app$app.contribute$app.contribute.editor";
    this.overlay = true;

    var self = {
        invalidate: function(invalidateArgs) {
        }
    };

    this.enter = function (context) {
        console.info("Entering fxrig.controllers.app.contribute.editor.");

        // init
        return new window.Promise(function (resolve, reject) {
            try {
                // todo: use cache
                var load = fxrig.utils.load({ container: $("#chart_adorner_container"), url: fxrig.controllers.app.contribute.editor.url, context: context });

                load.then(function() {
                    $("#chart_adorner_container").show();

                    var state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });
                    
                    fxrig.controls.list.initCheckboxSet({
                        container: $("#chart_editor_names"),
                        data: fxrig.services.meta.getNames().map(function (name) { return { id: name.name, text: name.name } }),
                        selectedIds: state.display.names,
                        on: function (message) { }
                    });

                    fxrig.controls.dates.init({ container: $("#chart_editor_date_from"), minutes: state.display.from });
                    fxrig.controls.dates.init({ container: $("#chart_editor_date_to"), minutes: state.display.to });

                    $("#editor_apply, #editor_cancel").click(function () {
                        var action = $(this).data().action;

                        context = context || {}; // todo: do we ever expect context???
                        context.action = action;

                        if (action === "Apply") {
                            var state = fxrig.state.get({ controller: fxrig.controllers.app.contribute });
                            var display = state.display;

                            // coerce
                            display = _.assign(display, {
                                from: fxrig.controls.dates.getMinutes({ container: $("#chart_editor_date_from") }),
                                to: fxrig.controls.dates.getMinutes({ container: $("#chart_editor_date_to") }),
                                names: fxrig.utils.data.mergeNames(state.display.names, fxrig.controls.list.getSelectedIds({ container: $("#chart_editor_names") }))
                            });

                            display = fxrig.utils.data.coerceDisplay(display, 120);
                            state.display = display;

                            // set it at parent level?
                            fxrig.state.set({ controller: fxrig.controllers.app.contribute, value: state });
                        }

                        fxrig.router.navigate({ container: $("#app_container"), name: "app.contribute", context: context });
                    });

                    resolve(context);
                });
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function (context) {
        console.info("Leaving fxrig.controllers.app.contribute.editor.");

        return new window.Promise(function (resolve, reject) {
            try {
                $("#chart_adorner_container").hide();
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
};