﻿// todo: move to router (review)

var fxrig = fxrig || {};
fxrig.controllers = fxrig.controllers || {};
fxrig.controllers.controller = new function() {

    var getParts = function (self) {
        var parts = [self];

        var appendParts = function (part) {
            if (!part.parts) return;

            for (var i = 0; i < part.parts.length; i++) {
                var childPart = part.parts[i];

                parts.push(childPart);
                appendParts(childPart);
            }
        };

        appendParts(self);

        return parts;
    };

    this.getPart = function (self, name) {
        var parts = getParts(self);
        return parts.find(function (part) { return part.name === name; });
    };

    // todo: add debouncer
    this.send = function (self, message) {
        var parts = getParts(self);

        for (var i = 0; i < parts.length; i++) {
            var part = parts[i];

            if (message.sender !== part.name && part.on) {
                part.on(message);
            }
        }

        fxrig.apps.send($("#apps"), message);
    }

    // todo: review
    this.sendToController = function(controller, message) {
        controller.getSelf().on(message);
        fxrig.apps.send($("#apps"), message);
    };

    // contributor parts
    this.sendToControllerParts = function (parts, message) {

        fxrig.apps.send($("#apps"), message);
    };
};