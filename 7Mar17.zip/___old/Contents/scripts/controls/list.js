﻿"use strict";

var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};
fxrig.controls.list = new function () {

    this.init = function (initArgs) {
        var $container = initArgs.container;
        $container.state({ template: initArgs.template, on: initArgs.on });
        
        return window.Promise.resolve(initArgs);
    }

    this.invalidate = function (invalidateArgs) {
        return new window.Promise(function (resolve, reject) {
            try {
                var $container = invalidateArgs.container;
                var state = $container.state();
                var data = invalidateArgs.data;
                var selectedId = invalidateArgs.selectedId || data.length > 0 ? data[0].Id : null;

                var html = "<div id='data_container' class='metrical-full-size'>";
                var i;

                var handleClick = function (id) {
                    var $item;

                    var setSelection = function (item, selected) {
                        var $selector = item.find("#selector");
                        var $contents = item.find("#contents");

                        if (selected) {
                            $selector.addClass("gray");
                            $contents.addClass("gray-5");

                            state.on({ name: "SelectedId", value: id });
                        }
                        else {
                            $selector.removeClass("gray");
                            $contents.removeClass("gray-5");
                        }
                    };

                    if (state.selectedId) {
                        $item = $("#item_{0}".format(state.selectedId), $container);
                        setSelection($item, false);
                    }

                    $item = $("#item_{0}".format(id), $container);
                    setSelection($item, true);

                    state.selectedId = id;
                };

                var itemTemplate = fxrig.state.getCacheItem({ appName: "fxrig", name: "item" });
                for (i = 0; i < data.length; i++) {
                    var item = data[i];
                    var itemHtml = itemTemplate.format(item.Id, _.template(state.template(item))(item));
                    
                    html = html + itemHtml;
                }
                html = html + "</div>";

                $container.html(html);

                $container.find("#data_container").children().on("click", function () {
                    handleClick($(this).attr("id").split("_")[1]);
                });

                //var $dataConatiner = $container.find("#data_container");
                //for (i = 0; i < $dataConatiner.children().length; i++) {
                //    var $child = $($dataConatiner.children()[i]);
                //    var childId = $child.attr("id");

                //    debugger;
                //    $child.on("click", { id: childId }, function() {
                //        handleClick(event.data.id);
                //    });
                //}

                handleClick(selectedId); // todo: possibly use trigger

                resolve(invalidateArgs);
            } catch (error) {
                reject({ error: error });
            } 
        });
    };


    this.initRadioSet = function (initRadioSetArgs) {
        var $container = initRadioSetArgs.container;
        var state = $container.state({ data: initRadioSetArgs.data, selectedId: initRadioSetArgs.selectedId, on: initRadioSetArgs.on, name: initRadioSetArgs.name });

        var itemHtml = "<input type='radio' id='radio_{2}_{0}' name='{2}' {3}><label for='radio_{2}_{0}'>{1}</label>";
        var html = "";

        for (var i = 0; i < state.data.length; i++) {
            var dataItem = state.data[i];

            if (dataItem.id.split("_").length > 1) {
                console.error("Illegal Symbol: '_'");
            }

            html = html + itemHtml.format(dataItem.id, dataItem.text, state.name, dataItem.id === state.selectedId ? "checked='checked'" : "");
        }
        
        $container.html(html);
        $container.buttonset();

        $container.children().change(function (event) {
            var parts = $(this).attr("id").split("_");
            var id = parts[parts.length - 1];

            state.selectedId = id;

            if (state.on) {
                state.on({ name: "Selected", value: id, manual: event.originalEvent !== undefined });
            }
        });

        //if (state.selectedId) {
        //    $("#radio_{0}_{1}".format(state.name, state.selectedId), $container).trigger("change", { initial: true });
        //}

        if (state.on
            && state.selectedId !== undefined) {

            state.on({ name: "Selected", value: state.selectedId, manual: false });
        }
    };

    var getRuntimeSelectedIds = function (getRuntimeSelectedIdsArgs) {
        var $container = getRuntimeSelectedIdsArgs.container;
        var state = $container.state();
        var selectedIds = [];

        for (var i = 0; i < state.data.length; i++) {
            var dataItem = state.data[i];
            var selected = selectedIds.indexOf(dataItem.id) > -1;

            var $item = $("#checkbox_{0}".format(dataItem.id), $container);
            if ($item.is(":checked")) {
                selectedIds.push(dataItem.id);
            }
        }

        if (selectedIds.length > 0) {
            return selectedIds.join(",");
        }
    };

    this.initCheckboxSet = function (initCheckboxSetArgs) {
        var $container = initCheckboxSetArgs.container;
        var state = $container.state({ data: initCheckboxSetArgs.data, selectedIds: initCheckboxSetArgs.selectedIds, on: initCheckboxSetArgs.on });
        var selectedIds = state.selectedIds.split(",").map(function (selectedId) { return selectedId.split(":")[0] }); // cover up chart

        var itemHtml = "<input type='checkbox' id='checkbox_{0}' name='{2}' {3}><label for='checkbox_{0}'>{1}</label>";
        var html = "";

        for (var i = 0; i < state.data.length; i++) {
            var dataItem = state.data[i];

            if (dataItem.id.split("_").length > 1) {
                console.error("Illegal Symbol: '_'");
            }

            var selected = selectedIds.indexOf(dataItem.id) > -1;
            html = html + itemHtml.format(dataItem.id, dataItem.text, state.name, selected ? "checked='checked'" : "");
        }

        $container.html(html);
        $container.buttonset();

        $container.children().change(function (event) {
            var id = $(this).attr("id").split("_")[1];
            
            state.selectedIds = getRuntimeSelectedIds({ container: $container });
            
            if (state.on) {
                state.on({ name: "Selected", value: state.selectedIds, manual: event.originalEvent !== undefined });
            }
        });

        if (state.on) {
            state.on({ name: "Selected", value: state.selectedIds, manual: false });
        }
    };

    this.getSelectedIds = function (getSelectedIdsArgs) {
        return getSelectedIdsArgs.container.state().selectedIds;
    };

    this.getSelectedId = function (getSelectedIdsArgs) {
        return getSelectedIdsArgs.container.state().selectedId;
    };

    this.getIds = function(e) {
        return e.container.state().data.map(function(item) { return item.id }).join(",");
    };
};