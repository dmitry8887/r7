﻿"use strict";

r8.routes =
    [
        {
            name: "r0",
            hash: "contribute/chart",
            handle: ({ container }) => {
                r8.controllers.Contribute.init({container});
                
                debugger;
            }
        },
        {
            hash: "contribute/contributions",
            handle: ({ container }) => { }
        },
        {
            hash: "contribute/contributions/{id}", handle: ({ container }) => { }
        },
        {
            hash: "contribute/contribution", handle: ({ container }) => { }
        },
        {
            hash: "labs", handle: ({ container }) => { }
        },
        {
            hash: "research", handle: ({ container }) => { }
        }
    ];

const routes = r8.routes;
routes.defaultName = "r0";
routes.fallbackName = "r0";

const app = r8.controllers.App;
r8.init = app.init.bind(app);
r8.run = app.run.bind(app);