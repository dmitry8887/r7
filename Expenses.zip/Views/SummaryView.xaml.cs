﻿using System.Windows.Controls;

namespace BookKeeper.Views
{
    /// <summary>
    /// Interaction logic for ExpenseSummaryView.xaml
    /// </summary>
    public partial class ExpenseSummaryView : UserControl
    {
        public ExpenseSummaryView()
        {
            InitializeComponent();
        }
    }
}
