﻿fxrig.services = fxrig.services || {};
fxrig.services.cache = fxrig.services.cache || {};

fxrig.services.cache.apps =
[
    {
        // todo: rename to zummer
        id: "app_contribute", header: "Zoomer", description: "Description", publisher: "System", level: 1, rank: 100, names: "app.contribute",
        script: function () {
            return {
                init: function () {
                    var that = this;
                    var $container = this.container;

                    var $button = $("#app_contribute_button", this.container);
                    $button.on("click", function () {
                        that.send({ name: "test", value: 1 });
                    });

                    fxrig.controls.list.initRadioSet({
                        container: $("#zoomer_options_radio_set", this.container),
                        data: [{ id: "L", text: "L" }, { id: "C", text: "C" }, { id: "R", text: "R" }],
                        selectedId: "C",
                        name: "zummer_options",
                        on: function (onArgs) {
                        }
                    });
                },
                receive: function (message) {
                    var $textArea = $("#app_contribute_textarea", this.container);
                    $textArea.val($textArea.val() + "\n" + message.name);

                    switch (message.name) {
                        case "App.Contribute.Chart.Chart.Display":
                            //alert("got it!");
                            // debugger;

                            break;
                    }
                }
            };
        },
        cacheName: "app.contribute"
    }, {
        id: "app_contribute_editor",
        header: "Contribute Editor",
        description: "Contribute Editor Description",
        level: 1,
        rank: 99,
        publisher: "System",
        names: "app.contribute.editor",
        html: "<div class='t-tb mp5' id='container'><div>Chart Editor</div></div>"
    }, {
        id: "app_labs",
        header: "Labs",
        publisher: "System",
        description: "Labs Description",
        names: "app.labs*",
        level: 1,
        rank: 1,
        html: "<div class='t-tb mp5' id='container'><div>Labs222</div></div>"
    }, {
        id: "app_local_data",
        header: "Local Data",
        description: "Local Data Description",
        level: 1,
        rank: 99,
        publisher: "System",
        names: "_reserved",
        html: "<div class='t-tb mp5' id='container'><div>Local Data</div></div>"
    }, {
        id: "app_research",
        header: "Research",
        description: "Research Description",
        level: 1,
        rank: 100,
        publisher: "System",
        names: "app.research*",
        html: "<div class='t-tb mp5' id='container'><div>Research</div></div>"
    }, {
        id: "app_research_patterns",
        header: "Research Patterns",
        description: "Research Patterns Description",
        level: 1,
        rank: 99,
        publisher: "System",
        names: "app.research.patterns",
        html: "<div class='t-tb mp5' id='container'<div>Research Paterns</div></div>"
    }, {
        id: "app_research_result",
        header: "Research Result",
        description: "Research Result Description",
        level: 1,
        rank: 99,
        publisher: "System",
        names: "app.research*",
        html: "<div class='t-tb mp5 ' id='container'><div>Research Result</div></div>"
    }, {
        id: "app_shared",
        header: "Shared",
        description: "Shared Description",
        level: 3,
        rank: 100,
        publisher: "System",
        names: "app*",
        cacheName: "app.shared"
    }
];