﻿r8.providers = {};

r8.providers.quotes = {
  name: "Quotes",
  fetch: (request) => r8.services.quotes.get(request).then(data => ({ data, provider: r8.providers.quotes })),
  merge: ({ container, data }) => {
    container.expandos = container.expandos || {};
    container.expandos.data = container.expandos.data || {};

    if (container.expandos.data[r8.providers.quotes.name]){
      //throw "Not Implemented";
    }
    else{
      container.expandos.data[r8.providers.quotes.name] = data;
    }
  },
  filter: ({ container, request }) => {
    const data = container.expandos.data[r8.providers.quotes.name];
    const { from, to } = request;
    
    const filteredData = data.map(seria => seria.points.filter(point => {
      seria.minM = Math.min(seria.minM || Number.POSITIVE_INFINITY, point.m);
      seria.maxM = Math.max(seria.maxM || Number.NEGATIVE_INFINITY, point.m);
      return point.o >= from && point.o <= to;
    })); 

    filteredData.forEach((seria, index) => {
      seria.minM = data[index].minM;
      seria.maxM = data[index].maxM;
    });

    filteredData.minO = request.from;
    filteredData.maxO = request.to;

    return filteredData;
  }
};
