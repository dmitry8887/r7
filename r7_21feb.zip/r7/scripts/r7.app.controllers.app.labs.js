﻿r7.app.controllers.app.labs = new function () {
    this.route = "app$app.labs";
    this.hash = "labs";

    this.enter = function (context) {
        return new window.Promise(function (resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function (context) {
        return new window.Promise(function (resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
};