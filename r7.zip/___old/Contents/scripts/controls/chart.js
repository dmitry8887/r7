﻿"use strict";

var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};

// exclude all business data manipulations
// display and selection should be different 
fxrig.controls.chart = new function() {
    
    // settings
    var minXTickWidth = 200;
    var minYTickHeight = 100;

    var getRenderReason = function (getRenderReasonArgs) {
        if (getRenderReasonArgs.selectionMode) {
            return "SelectionMode";
        }
        else if (getRenderReasonArgs.selectedName) {
            return "SelectedName"; // todo: should be derived from comparing current dipkay and requested display
        }
        else if (getRenderReasonArgs.data) {
            return "Data";
        }
        else {
            return "Resize";
        }
    };

    // todo: use switch(reason)
    // TODO: move all projectiosn to prepare?
    var render = function (renderArgs) { // todo: cache ticks
        //console.error("Chart Rendering....");

        var $container = renderArgs.container;
        var reason = getRenderReason(renderArgs);
        var state = $container.state();
        
        switch (reason) {
            case "Data":
                state.data = renderArgs.data;

                break;
            case "SelectionMode":
                state.selectionMode = renderArgs.selectionMode;
                
                break;
            case "SelectedName":
            case "Resize":
        }

        if (state.data) {
            var data = state.data;
            var display = fxrig.utils.clone(data.display);

            if (renderArgs.selectedName) {
                display.names = display.names.split(":")[0] + ":" + renderArgs.selectedName;
            }

            if (reason === "Data") {
                fxrig.utils.ui.draggable({
                    container: $("#plot", $container),
                    range: { min: display.from, max: display.to },
                    step: display.timeframe,
                    on: function(message) {
                        var name = message.name, value = message.value;

                        switch (name) {
                        case "Change":

                            state.on({ name: "RequestData", value: _.assign(fxrig.utils.clone(display), { from: value.min, to: value.max }) });
                            state.on({ name: "Busy", value: true }); // todo: states

                            break;
                        case "Dragging":
                            if (value === false) {
                                state.on({ name: "Busy", value: false }); 
                            }
                        }
                    }
                });
            }
            
            state.cache = state.cache || {};

            if (!state.cache.display
                || !fxrig.data.compare(state.cache.display, display)) {

                state.on({ name: "Display", value: display });
            }

            state.cache.display = display;

            var i;
            var tickCount;
            var tickHtml, tickHtmlLast;
            var values;

            var $axises = $("#x_axis_top, #x_axis_bottom", $container);
            tickCount = Math.floor($axises.width() / minXTickWidth);

            values = fxrig.utils.math.splitRange({ min: display.from, max: display.to }, tickCount, 0);

            var html = "<div class='layout-display-table metrical-full-size'><div class='layout-display-table-row'>";

            tickHtml = "<div class='metrical-width-100 metrical-full-height metrical-margin-left-m50 appearance-thin-border layout-centered-parent'><p class='layout-centered'>{{0}}</p></div>";
            tickHtmlLast = "<div class='metrical-width-100 metrical-full-height appearance-thin-border layout-position-absolute metrical-right-m50 layout-centered-parent'><p class='layout-centered'>{{0}}</p></div>"; // todo: change to relative parent and negative right

            for (i = 0; i < tickCount; i++) {
                if (i !== tickCount - 1) {
                    html = html + "<div class='layout-display-table-cell'>" + tickHtml.format(i) + "</div>";
                } else {
                    html = html + "<div class='layout-display-table-cell layout-position-relative'>" + tickHtmlLast.format(i + 1) + tickHtml.format(i) + "</div>";
                }
            }

            html = html + "</div></div>";
            $axises.html(html.format.apply(html, values));

            $axises = $("#y_axis_left, #y_axis_right", $container);
            tickCount = Math.floor($axises.height() / minYTickHeight);

            var selectedName = display.names.split(":")[1];
            var selectedSet = _.find(data.Core.Sets, function (set) { return set.Name === selectedName; });

            var $plotParent = $("#plot_parent", $container);
            var $plot = $("#plot", $container);

            $("#plot_no_data", $plotParent).remove(); // very bad rewrite
            $plot.empty(); // todo: consder moving atop as it should react fast

            if (fxrig.utils.math.isSet(selectedSet.Range)) {
                values = fxrig.utils.math.splitRange(selectedSet.Range, tickCount, 4); // don't use [0]

                values.reverse();

                tickHtml = "<div class='metrical-full-width metrical-height-30 metrical-margin-top-m15 appearance-thin-border layout-centered-parent'><p class='layout-centered'>{{0}}</p></div>";
                tickHtmlLast = "<div class='metrical-full-width metrical-height-30 appearance-thin-border layout-position-absolute metrical-bottom-m15 layout-centered-parent'><p class='layout-centered'>{{0}}</p></div>";

                html = "<div class='layout-display-table metrical-full-size'>";

                for (i = 0; i < tickCount; i++) {
                    if (i !== tickCount - 1) {
                        html = html + "<div class='layout-display-table-row'><div class='layout-display-table-cell'>" + tickHtml.format(i) + "</div></div>";
                    } else {
                        html = html + "<div class='layout-display-table-row'><div class='layout-display-table-cell layout-position-relative'>" + tickHtml.format(i) + tickHtmlLast.format(i + 1) + "</div></div>";
                    }
                }

                html = html + "</div>";
                $axises.html(html.format.apply(html, values));

                // plot
                var colors = ["green", "blue"];// ["#ccc", "#ccc"]; // todo: make a service call

                // todo: avoid reredner by leveraging scaling!
                var plotData = fxrig.utils.data.getPlotData(data.Core, display, { width: $plotParent.width() - 2, height: $plotParent.height() - 2 }, { x: 10, y: 10 }, colors);
                $plot.html(plotData);

                // volatility
                var level = fxrig.services.meta.getVolatilityLevel(selectedSet.Name, selectedSet.Range);

                var getLevelClassName = function(level) {
                    switch (level) {
                        case 1:
                            return "metrical-padding-vertical-40pct";
                        case 2:
                            return "metrical-padding-vertical-30pct";
                        case 3:
                            return "metrical-padding-vertical-20pct";
                        case 4:
                            return "metrical-padding-vertical-10pct";
                        default:
                            throw { error: "Invalid Level:" + level };
                    }
                };

                var $level = $("#plot_volatility_level", $plotParent);
                if (level === 5) {
                    $level.hide();
                } else {
                    $level.addClass(getLevelClassName(level));
                    $level.show();
                }

            } else {
                $plotParent.append("<p id='plot_no_data' class='layout-centered'>No Data.</p>");
            }

            // todo: refactor using switch
            if (reason !== "Resize") {
                var min = display.from, max = display.to;

                var setSlider = function ($slider, min, max, value) {
                    $slider.slider("option", "min", min).slider("option", "max", max).slider("value", value);
                };

                if (state.selectionMode === "R") {
                    setSlider($("#x_slider_top"), min, max, min);
                    setSlider($("#x_slider_bottom"), min, max, max);
                }
                else {
                    setSlider($("#x_slider_top"), min, max, min);
                    setSlider($("#x_slider_bottom"), min, max, min);
                }

                $("#selection", $container).hide();
            }
        }
    };

    //var invalidate = function (invalidateArgs) {
    //    invalidateArgs.container.state().on({ name: "RequestData", value: invalidateArgs.display });
    //};

    this.init = function(initArgs) {
        var $container = initArgs.container;
        var state = $container.state({ dataSource: initArgs.dataSource, bands: initArgs.bands, resolution: initArgs.resolution, on: initArgs.on });

        state.initialized = true;

        state.states = {}; // todo: review

        var html = fxrig.state.getCacheItem({ appName: "fxrig", name: "chart" });
        $container.html(html);

        // todo: use separate branches for slidechange and slide
        $("#x_slider_top, #x_slider_bottom", $container).slider().on("slidechange slide", function (event, args) {

            if (!$container.state().data) {
                debugger;
                return;
            };

            var manual = event.originalEvent !== undefined;

            var activeSliderRole = $(this).data("role");
            var topValue = (activeSliderRole === "x-slider-top") ? args.value : $("#x_slider_top", $container).slider("value");
            var bottomValue = (activeSliderRole === "x-slider-bottom") ? args.value : $("#x_slider_bottom", $container).slider("value");

            var display = $container.state().data.display;

            if (event.type === "slidechange") {
                if (event.originalEvent !== undefined) {
                    state.on({ name: "Busy", value: false });
                }
            }
            else {
                if (state.selectionMode === "P") {
                    var $passiveSlider = (activeSliderRole === "x-slider-top") ? $("#x_slider_bottom", $container) : $("#x_slider_top", $container);
                    $passiveSlider.slider("value", args.value);
                }

                var $selection = $("#selection", $container);
                var selectionWidth = Math.abs(topValue - bottomValue);

                if (selectionWidth === (display.to - display.from) || (selectionWidth === 0)) {
                    $selection.hide();
                } else {
                    var plotWidth = $("#plot_parent", $container).width();
                    var minutePrice = plotWidth / (display.to - display.from);
                    var left;
                    var width;

                    if (state.selectionMode === "R") {

                        left = Math.min(topValue, bottomValue) - display.from;
                        left = 100 * (left * minutePrice) / plotWidth + "%";

                        width = Math.abs(topValue - bottomValue);
                        width = 100 * (width * minutePrice) / plotWidth + "%";
                    }
                    else {

                        left = args.value - display.from;
                        left = 100 * (left * minutePrice) / plotWidth + "%";

                        width = "1px";
                    }

                    $selection.css("marginLeft", left).css("width", width).show();
                }

                state.on({ name: "Busy", value: true });
            }

            if (topValue > 0 && bottomValue > 0) {
                var from = Math.min(topValue, bottomValue);
                var to = Math.max(topValue, bottomValue);

                state.cache = state.cache || {};

                // todo: gets fired too many times...
                if (!state.cache.selection
                    || state.cache.selection.from !== from
                    || state.cache.selection.to !== to) {

                    state.cache.selection = { from: from, to: to };
                    state.on({ name: "Selection", value: { from: from, to: to, manual: manual } });
                }
            }
        });

        var delay;
        $(window).on("resize", function() {
            clearTimeout(delay);
            delay = setTimeout(render(initArgs), 250);
        });

        // todo: move to data, keep display get rid of min/max
        // var range = fxrig.utils.math.coerceRange({ min: initArgs.display.from, max: initArgs.display.to }, thresholds[initArgs.resolution.toLocaleLowerCase()]);

        //return invalidate({
        //    container: $container,
        //    display: _.assign(fxrig.utils.clone(initArgs.display), { from: range.min, to: range.max, timeframe: range.timeframe })
        //});
    };

    this.invalidate = function (invalidateArgs) {
        // todo: remove selected name - use display and derive the reason from it
        render({ container: invalidateArgs.container, data: invalidateArgs.data, selectionMode: invalidateArgs.selectionMode, selectedName: invalidateArgs.selectedName });
    };

    this.getSelection = function (e) {
        var selection = null;

        var cache = e.container.state().cache;
        if (cache) {
            selection = cache.selection;
        }

        return selection;
    };
};