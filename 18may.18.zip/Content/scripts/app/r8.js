﻿const r8 = {};
r8.controllers = {};
r8.bands = {};
r8.providers = {};

r8.routes =
    [
        {
            name: "r0",
            hash: "contribute/chart",
            handle: ({ container, stateContainer }) => {
                return r8.controllers.App.init({ container, stateContainer }).then(r8.controllers.Contribute.init).then(() => {
                    debugger;
                });
            }
        },
        {
            hash: "contribute/contributions",
            handle: ({ container }) => { }
        },
        {
            hash: "contribute/contributions/{id}", handle: ({ container }) => { }
        },
        {
            hash: "contribute/contribution", handle: ({ container }) => { }
        },
        {
            hash: "labs", handle: ({ container }) => { }
        },
        {
            hash: "research", handle: ({ container }) => { }
        }
    ];

r8.routes.defaultName = "r0";
r8.routes.fallbackName = "r0";
