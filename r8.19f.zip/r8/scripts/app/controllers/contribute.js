﻿"use strict";

r8.controllers.Contribute = class extends simple.Controller {
  get properties() {
    return { route: "App$Contribute", "default": true, hash: "contribute", name: "Contribute", view:() => simple.Storage.getText({ name: "r8.views.contribute" }) };
  }

  constructor(resolver) {
    super({
      resolver,
      elements: {
        DateRange: "date_range",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor",
        Contribute: "contribute",
        Chart: "chart",
        ContributionsFilter: "contributions_filter",
        ContributionsLauncher: "contributions_launcher",
        ContributionsSummary: "contributions_summary",
        ContributionsPanel: "contributions_panel",
        DatesEditor: "dates_editor",
        DatesEditorSlider: "dates_editor_slider",
        DatesEditorDateRange: "dates_editor_date_range",
        DatesEditorDone: "dates_editor_done",
        DataSummary: "data_summary",
        ChartZoom: "chart_zoom",
        Add: "add",
        ContributionNames: "contribution_names",
        ContributionTags: "contribution_tags",
        ContributionNamesEditor: "contribution_names_editor",
        ContributionTagsEditor: "contribution_tags_editor",
        ContributionNamesEditorLauncher: "contribution_names_editor_launcher",
        ContributionTagsEditorLauncher: "contribution_tags_editor_launcher",
        ContributionOverlay: "contribution_overlay",
        ContributionDateRange: "contribution_date_range",
        ContributionDatesEditorDateRange: "contribution_dates_editor_date_range",
        ContributionDatesEditor: "contribution_dates_editor",
        ContributionDatesEditorSlider: "contribution_dates_editor_slider",
        ContributionType: "contribution_type",
        ContributionPointDirection: "contribution_point_direction",
        ContributionPoint: "contribution_point",
        ContributionPointCloseMode: "contribution_point_close_mode",
        ContributionPointRiskEstimate: "contribution_point_risk_estimate",
        ContributionPointVolumeEstimate: "contribution_point_volume_estimate",
        ContributionPointLeverageEstimate: "contribution_point_leverage_estimate",
        ContributionPointAddCloseButton: "contribution_point_add_close_button",
        ContributionPointRemoveCloseButton: "contribution_point_remove_close_button",
        ContributionPointCloseRow: "contribution_point_close_row",
        ContributionPointMoreButton: "contribution_point_more_button",
        ContributionPointLessButton: "contribution_point_less_button",
        ContributionPointVolumeRow: "contribution_point_volume_row",
        ContributionPointLeverageRow: "contribution_point_leverage_row",
        ContributionDatesEditorDone: "contribution_dates_editor_done"
      },
      states: 
      [
        { 
          descriptor: "App.Contribute$NamesEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "NamesEditor" }), items: r8.services.metadata.names(), selectedIds: stored.names });
          }
        },
        {
          descriptor: "App.Contribute$TagsEditor$Enter",
          group: "Editors",
          handle: () => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.Picker.setItems({ container: this.getElement({ name: "TagsEditor" }), items: r8.services.metadata.tags(), selectedIds: stored.tags });
          }
        },
        {
          descriptor: "App.Contribute$DatesEditor$Enter",
          handle: ({ descriptor }) => {
            const stored = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.DateRange.setOptions({ container: this.getElement({ name: "DatesEditorDateRange"}), 
              stateContainer: this.getStateContainer(),
              descriptor, from: stored.from, to: stored.to });
          }
        },
        {
          descriptor: "App.Contribute$DatesEditor$Leave",
          handle: () => {
            simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) });
          }
        },
        {
          descriptor: "App.Contribute$Contribution$Enter",
          childDescriptors:["App.Contribute$ContributionRange$Enter"],
          handle: ()=> {
            const state = simple.Storage.getValue({ name:"r8.storage.contribute" });

            simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDateRange"}), 
              stateContainer: this.getStateContainer(),
              from: state.from, to: state.to });

            simple.List.setItems({
              container: this.getElement({ name: "ContributionNames" }),
              items: r8.services.metadata.names().filter(name => state.names.indexOf(name.id) > -1),
              selectedIds: state.names
            });

            simple.List.setItems({
              container: this.getElement({ name: "ContributionTags" }),
              items: r8.services.metadata.tags().filter(tag => state.tags.indexOf(tag.id) > -1),
              selectedIds: state.tags
            });
          }
        },
        {
          descriptor: "App.Contribute$ContributionRange$Enter",
          group: "Contribution",
          childDescriptors:["App.Contribute$ContributionHasToDate$Enter"],
          handle: () => simple.RadioList.setSelectedId({ container: this.getElement({ name: "ContributionType" }), id: "range" })
        },
        {
          descriptor: "App.Contribute$ContributionPoint$Enter",
          group: "Contribution",
          childDescriptors:["App.Contribute$ContributionPointMore$Leave", "App.Contribute$ContributionPointHasClose$Leave"]
        },
        {
          descriptor: "App.Contribute$ContributionPointHasClose$Enter",
          childDescriptors: ["App.Contribute$ContributionHasToDate$Enter"]
        },
        {
          descriptor: "App.Contribute$ContributionPointHasClose$Leave",
          childDescriptors: ["App.Contribute$ContributionHasToDate$Leave"]
        },
        {
          descriptor: "App.Contribute$ContributionDatesEditor$Enter",
          handle: ({ descriptor })=>{
            const state = simple.Storage.getValue({ name:"r8.storage.contribute" });
            simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDatesEditorDateRange"}),
              stateContainer: this.getStateContainer(),
              descriptor, 
              hasToDate: false,
              from: state.from, 
              to: state.to });
          }
        },
        {
          descriptor: "App.Contribute$ContributionNamesEditor$Enter",
          group: "ContributionEditors",
          handle: ()=>{
            const selectedIds = simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionNames"}) });
            simple.Picker.setItems({ container: this.getElement({ name: "ContributionNamesEditor" }), items: r8.services.metadata.names(), selectedIds });
          }
        },
        {
          descriptor: "App.Contribute$ContributionTagsEditor$Enter",
          group: "ContributionEditors",
          handle: ()=> {
            const selectedIds = simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionTags"}) });
            simple.Picker.setItems({ container: this.getElement({ name: "ContributionTagsEditor" }), items: r8.services.metadata.tags(), selectedIds });
          }
        },
        {
          descriptor: "App.Contribute$ContributionHasToDate$Enter",
          handle: ()=> {
            simple.DateRange.setHasToDate({ container: this.getElement({ name: "ContributionDateRange" }), stateContainer: this.getStateContainer(), hasToDate: true });
          }
        },
         {
           descriptor: "App.Contribute$ContributionHasToDate$Leave",
           handle: () => {
             simple.DateRange.setHasToDate({
               container: this.getElement({ name: "ContributionDateRange" }),
               stateContainer: this.getStateContainer(),
               hasToDate: false
             });
           }
         },
         {
           descriptor: "App.Contribute$ContributionPoint$Leave", childDescriptors: ["App.Contribute$ContributionHasToDate$Leave"]
         }
      ],
      commands:
      [
        { 
          name:"App.Contribute$ContributionDatesEditorDone", 
          handle: ()=> {
            alert("First Command");
          }
        },
        { 
          name:"App.Contribute$Names$EventProxy",
          handle: function({ ids, selectedIds, name })=> {
            debugger;
           
            
            const state = simple.Storage.setValue({
              name: "r8.storage.contribute", mutator: (value) => {
                value.names = ids;
                value.activeName = selectedIds[0];

                return value;
              }
            });

            applyState({ state });
          }
        }
      ]
    });
  }

  enter() {
    if (this.initialized !== true) {
      const stateContainer = this.getStateContainer();
      //const container = this.getContainer();

      this.init();

      const $dateRange = this.getElement({ name: "DateRange" });
      const $datesEditorDateRange = this.getElement({ name: "DatesEditorDateRange" });
      const $names = this.getElement({ name: "Names" });
      const $tags = this.getElement({ name: "Tags" });
      const $namesEditor = this.getElement({ name: "NamesEditor" });
      const $tagsEditor = this.getElement({ name: "TagsEditor" });
      const $contribute = this.getElement({ name: "Contribute" });
      const $contributionDateRange = this.getElement({ name: "ContributionDateRange" });
      const $contributionDatesEditorDateRange = this.getElement({ name: "ContributionDatesEditorDateRange" });

      const applyState = ({ state }) => {
        simple.List.setItems({
          container: $names,
          items: r8.services.metadata.names().filter(name => state.names.indexOf(name.id) > -1),
          selectedIds: [state.activeName]
        });

        simple.List.setItems({
          container: $tags,
          items: r8.services.metadata.tags().filter(tag => state.tags.indexOf(tag.id) > -1),
          selectedIds: state.tags
        });

        simple.DateRange.setOptions({ container: $dateRange, stateContainer, from: state.from, to: state.to }); // TODO: do it from chart.enter?

        simple.Data.request({ container: $contribute, request: state });
      };

      simple.DateRange.init({ container: $dateRange, stateContainer, on:({ name, descriptor }) => {
        if (name === "Activate"){
          this.executeState({ batch: { states: [{descriptor:"App.Contribute$DatesEditor$Enter", value: { descriptor }}], backHandleMode: "All"}});
        }
      }});

      simple.DateRange.init({ container: $datesEditorDateRange, stateContainer, getSlider: ()=> this.getElement({ name: "DatesEditorSlider" }), on: ()=> { }});
      
      //
      let on = this.getCommand({ name: "App.Contribute$Names$EventProxy" }).handle;
      on = on.bind(this);

      debugger;

      on({ ids: [1,2,3], selectedIds:[4,5,6], name:"Test" });

      simple.List.init({ container: $names, stateContainer, on });
      
      simple.List.init({
        container: $tags,
        stateContainer,
        on: ({ ids }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute",
            mutator: (value) => {
              value.tags = ids;
              return value;
            }
          });
          applyState({ state } );
        }
      });
      
      simple.Picker.init({
        container: $namesEditor,
        stateContainer,
        on: ({ selectedIds }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute",
            mutator: (value) => {
              const names = selectedIds;
              let activeName = value.activeName;

              if (names.indexOf(activeName) < 0) {
                activeName = names[0];
              }

              value.names = names;
              value.activeName = activeName;

              return value;
            }
          });

          applyState({ state });
          simple.Navigator.apply();
        }
      });
      
      simple.Picker.init({
        container: $tagsEditor,
        stateContainer,
        on: ({ selectedIds }) => {
          const state = simple.Storage.setValue({
            name: "r8.storage.contribute",
            mutator: (value) => {
              value.tags = selectedIds;
              return value;
            }
          });

          applyState({ state });
          simple.Navigator.apply(); // Swap?
        }
      });

      simple.Chart.init({ container: this.getElement({ name: "Chart"} ), stateContainer,
        bands:
        [
          r8.bands.weekDays //, r8.bands.random
        ],
        on: ({ name, value }) => {
          switch(name){
            case "Drag":
              var request = simple.Data.getRequest({ container: $contribute });
              request = Object.assign(request, { from: value.from, to: value.to });
              
              simple.Data.request({ container: $contribute, request });
              break;
            case "DragStop":
              
              var from = value.from;
              var to = value.to;

              applyState({ state: simple.Storage.setValue({
                name: "r8.storage.contribute",
                mutator: (value) => Object.assign(value, { from, to })
              })});

              break;
          }
        }});

      simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }), stateContainer });

      simple.Data.init({
        container: $contribute,
        providers: [r8.providers.quotes, r8.providers.contributions],
        on: ({ data }) => {
          simple.Data.renderSummary({ container: this.getElement({ name: "DataSummary" }), left: data.left, right: data.right });

          const quotes = data[r8.providers.quotes.name];
          if (quotes){
            simple.Chart.setData({ container: this.getElement({ name: "Chart"}), data: quotes });
          }
        }
      });

      simple.List.init({ container: this.getElement({ name: "ContributionNames" }), stateContainer, on: () => { } });
      
      simple.List.init({ container: this.getElement({ name: "ContributionTags" }), stateContainer, on: () => { } });

      simple.Picker.init({
        container: this.getElement({ name: "ContributionNamesEditor" }),
        stateContainer,
        on: ({ name, selectedIds }) => {
          switch(name){
            case "Change":
              simple.List.setItems({
                container: this.getElement({ name: "ContributionNames" }),
                items: r8.services.metadata.names().filter(name => selectedIds.indexOf(name.id) > -1),
                selectedIds: selectedIds
              });
              simple.Navigator.apply();
              break;
          }
        }
      });

      simple.Picker.init({
        container: this.getElement({ name: "ContributionTagsEditor" }),
        stateContainer,
        on: ({ name, selectedIds }) => {
          switch(name){
            case "Change":
              simple.List.setItems({
                container: this.getElement({ name: "ContributionTags" }),
                items: r8.services.metadata.tags().filter(name => selectedIds.indexOf(name.id) > -1),
                selectedIds: selectedIds
              });
              simple.Navigator.apply();
              break;
          }
        }
      });

      simple.DateRange.init({ container: $contributionDateRange, stateContainer, on:({ name, descriptor }) => {
        if (name === "Activate"){
          this.executeState({ batch: { states: [{ descriptor:"App.Contribute$ContributionDatesEditor$Enter", value: { descriptor }}], 
            backHandleMode: "All"}});
        }
      }});

      simple.Slider.init({ container: this.getElement({ name: "ContributionDatesEditorSlider" }), stateContainer });

      simple.DateRange.init({ container: $contributionDatesEditorDateRange,
        stateContainer,
        getSlider: ()=> this.getElement({ name: "ContributionDatesEditorSlider" }),
        on: ()=> { 
        }});
      
      simple.RadioList.init({ container: this.getElement({ name: "ContributionType" }), items:r8.services.metadata.contributionTypes(), 
        selectedId: "range", on:({ name, id, manual }) => {
          switch(name){
            case "Select":
              if (!manual) return;

              var descriptor = {
                range: "App.Contribute$ContributionRange$Enter",
                point: "App.Contribute$ContributionPoint$Enter"
              }[id];

              if (!descriptor){
                throw `Invalid Contribution Type: '${id}'`;
              }

              this.executeState({ batch:{ descriptors: [descriptor]}});
              break;
          }
        }});

      simple.RadioList.init({ container: this.getElement({ name: "ContributionPointDirection" }), items:r8.services.metadata.contributionPointDirections(), 
        selectedId: "b", on:() => { }});

      simple.RadioList.init({ container: this.getElement({ name: "ContributionPointCloseMode" }), items:r8.services.metadata.contributionPointCloseModes(), 
        selectedId: "manual", on:() => { }});

      ["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(name=> {
        simple.Spinner.init({ container: this.getElement({ name }), items: r8.services.metadata.estimates(), selectedId: "None" });
      });
      
      this.executeState({ batch:{ descriptors: ["App.Contribute$Chart$Enter"]}});

      const state = simple.Storage.getValue({ name: "r8.storage.contribute", defaultValue: r8.services.contribute.getDefaultData() });
      applyState({ state });
      
      this.initialized = true;
    }
  }

  leave() {
  }

  static templates() {
    return [
      { name: "r8.views.contribute", url: "../html/app/views/contribute.html" }
    ];
  }
}