﻿using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using Dapper;
using r8.Models;

namespace r8.Controllers
{
  public class QuotesController : ApiController
  {
    private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    public QuotesResult Get(string names, int from, int to, int frame)
    {
      QuotesResult coreResult = new QuotesResult();

      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        foreach (var name in names.Split(",".ToCharArray()))
        {
          string currentName = name.Replace("*", string.Empty);

          string tableName = $"DATA_{currentName}_M{frame}";
          var points = connection.Query<Point>($@"SELECT O, M 
              FROM [dbo].{tableName} WITH(NOLOCK) 
              WHERE O BETWEEN {from} AND {to} ORDER BY O ASC").ToList();

          coreResult.Add(new PointSet(points, currentName));
        }

        connection.Close();
        return coreResult;
      }
    }
  }
}
