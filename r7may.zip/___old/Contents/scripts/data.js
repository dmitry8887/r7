﻿var fxrig = fxrig || {};

// todo: ensure gets called even for filtering
fxrig.data = new function () {
    // move to data utils
    var extend = function (display, screens) {
        var displayLength = display.to - display.from;

        return { names: display.names, timeframe: display.timeframe, from: display.from - displayLength * screens, to: display.to + displayLength * screens };
    }; // display to fetch essentially

    // move to data utils
    var compare = function(display1, display2) {
        return display1.names === display2.names
            && display1.from === display2.from
            && display1.to === display2.to
            && display1.timeframe === display2.timeframe;
    };

    // todo: move to data utils
    this.compare = function (display1, display2) {
        return compare(display1, display2);
    };



    var fetchData = function (fetchDataArgs) {
        return new window.Promise(function(resolve, reject) {
            try {
                var $container = fetchDataArgs.container;
                var state = $container.state();
                var fetch = fetchDataArgs.fetch;
                var providers = fetchDataArgs.providers || state.providers;

                return window.Promise.all(providers.map(function (provider) {
                    return fxrig.providers.get(provider).fetch(fetch);
                })).then(function (data) {
                    resolve({ data: data });
                });

            } catch (error) {
                reject({ error: error });
            } 
        });
    };

    // todo: called twice!!!
    var ensure = function(ensureArgs) {
        return new window.Promise(function(resolve, reject) {
            try {
                var $container = ensureArgs.container;
                var state = $container.state();
                var display = ensureArgs.display || state.cache.display; // no display means filer may need to create s spearate call
                var providers = ensureArgs.providers;
                var mode = ensureArgs.mode; // null/Force/Reset

                var cache = state.cache;
                var fetch;

                if (!cache || mode === "Reset") {
                    fetch = extend(display, state.settings.fetchScreens);

                    fetchData({ container: $container, fetch: fetch, providers: providers }).then(function(results) {
                        cache = { fetch: fetch, display: display, data: {} };

                        for (var i = 0; i < results.data.length; i++) {
                            var providerResult = results.data[i];
                            cache.data[providerResult.name] = providerResult.data;
                        }

                        // todo: filter individual prpviders
                        state.cache = cache; // todo: side effect
                        resolve(cache);
                    });
                } else {
                    fetch = fxrig.utils.clone(cache.fetch);

                    var displayLength = cache.display.to - cache.display.from;
                    var action = "Prepare";

                    if ((display.from - fetch.from) / displayLength <= state.settings.bufferScreens) {

                        fetch.to = fetch.from;
                        fetch.from = fetch.to - (state.settings.fetchScreens * displayLength);

                        action = "FetchPrepend";
                    } else if (fetch.to - display.to / displayLength <= state.settings.bufferScreens) {

                        fetch.from = fetch.to;
                        fetch.to = fetch.from + (state.settings.fetchScreens * displayLength);

                        action = "FetchAppend";
                    }

                    if (action === "Prepare"
                        && !mode) {

                        cache.display = display;
                        resolve(cache);
                    } else {
                        if (!$container.state().fetching) {
                            $container.state().fetching = true;

                            fetchData({ container: $container, fetch: fetch, providers: providers }).then(function(results) {
                                for (var i = 0; i < results.data.length; i++) {
                                    var providerResult = results.data[i];

                                    var left, right;

                                    if (action === "Prepare") {
                                        left = cache.data[providerResult.name];
                                        right = providerResult.data;
                                    } else if (action === "FetchPrepend") {
                                        left = providerResult.data;
                                        right = cache.data[providerResult.name];
                                    } else if (action === "FetchPrepend") {
                                        left = cache.data[providerResult.name];
                                        right = providerResult.data;
                                    } else {
                                        throw { message: "Invalid Action: " + action };
                                    }

                                    cache.data[providerResult.name] = fxrig.providers.get(providerResult.name).merge(left, right, mode);
                                }

                                cache.fetch.from = Math.min(cache.fetch.from, results.data[0].fetch.from);
                                cache.fetch.to = Math.max(cache.fetch.to, results.data[0].fetch.to);

                                //if (results.data[0].data) {
                                //    console.error("Additional Fetch", { from: cache.fetch.from, to: cache.fetch.to, count: results.data[0].data.Sets[0].Points.length });
                                //}

                                $container.state().fetching = false;
                                resolve(cache);
                            });
                        }
                    }
                }
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    var prepare = function (cache, providers, filters) {
        return new window.Promise(function (resolve, reject) {
            try {
                var data = {};

                providers.forEach(function (provider) {
                    var filter = filters.find(function (filter) { return filter.provider === provider; });
                    if (filter) {
                        filter = filter.value;
                    }

                    data[provider] = fxrig.providers.get(provider).prepare({ data: cache.data[provider], display: cache.display, filter: filter});
                });
                
                _.assign(data, { display: cache.display });

                resolve({ data: data });
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.init = function (initArgs) {
        initArgs.container.state(initArgs);
    };

    this.request = function(requestArgs) {
        var filters = requestArgs.filters;
        var providers = requestArgs.providers || requestArgs.container.state().providers;
        
        return ensure(requestArgs)
            .then(function(cache) { return prepare(cache, providers, filters); })
            .then(function(result) {
                return window.Promise.resolve({ data: result.data, context: requestArgs.context });
            });
    };


    this.getStats = function() {
        throw { error: "Not Implemented." };
    };
};