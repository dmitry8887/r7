﻿"use strict";

const ContributeController = class extends simple.Controller {
  constructor({ context }) {
    super({
      elements: {
        Contribute: "contribute",
        DateRange: "date_range",
        Names: "names",
        Tags: "tags",
        NamesEditorLauncher: "names_editor_launcher",
        NamesEditor: "names_editor",
        TagsEditorLauncher: "tags_editor_launcher",
        TagsEditor: "tags_editor",
        Chart: "chart",
        Contributions: "contributions",
        ContributionsFilter: "contributions_filter",
        ContributionsLauncher: "contributions_launcher",
        ContributionsSummary: "contributions_summary",
        ContributionsPanel: "contributions_panel",
        DatesEditor: "dates_editor",
        DatesEditorSlider: "dates_editor_slider",
        DatesEditorDateRange: "dates_editor_date_range",
        DatesEditorDone: "dates_editor_done",
        DataPadding: "data_padding",
        DataZoom: "data_zoom",
        ContributionCreate: "contribution_create",
        ContributionAdd: "contribution_add",
        Contribution: "contribution",
        ContributionValidationSummary: "contribution_validation_summary",
        ContributionNames: "contribution_names",
        ContributionTags: "contribution_tags",
        ContributionNamesEditor: "contribution_names_editor",
        ContributionTagsEditor: "contribution_tags_editor",
        ContributionNamesEditorLauncher: "contribution_names_editor_launcher",
        ContributionTagsEditorLauncher: "contribution_tags_editor_launcher",
        ContributionOverlay: "contribution_overlay",
        ContributionDateRange: "contribution_date_range",
        ContributionDatesEditorDateRange: "contribution_dates_editor_date_range",
        ContributionDatesEditor: "contribution_dates_editor",
        ContributionDatesEditorSlider: "contribution_dates_editor_slider",
        ContributionType: "contribution_type",
        ContributionPointDirection: "contribution_point_direction",
        ContributionPoint: "contribution_point",
        ContributionPointCloseMode: "contribution_point_close_mode",
        ContributionPointRiskEstimate: "contribution_point_risk_estimate",
        ContributionPointVolumeEstimate: "contribution_point_volume_estimate",
        ContributionPointLeverageEstimate: "contribution_point_leverage_estimate",
        ContributionPointAddCloseButton: "contribution_point_add_close_button",
        ContributionPointRemoveCloseButton: "contribution_point_remove_close_button",
        ContributionPointCloseRow: "contribution_point_close_row",
        ContributionPointMoreButton: "contribution_point_more_button",
        ContributionPointLessButton: "contribution_point_less_button",
        ContributionPointVolumeRow: "contribution_point_volume_row",
        ContributionPointLeverageRow: "contribution_point_leverage_row",
        ContributionPointOpenLower: "contribution_point_open_lower",
        ContributionPointOpenHigher: "contribution_point_open_higher",
        ContributionDatesEditorDone: "contribution_dates_editor_done",
        DiscussionOverlay: "discussion_overlay",
        DiscussionContext: "discussion_context",
        Discussion: "discussion"
      },
      states:
        [
          {
            name: "Contribute$NamesEditor",
            group: "Editors",
            enter: () => simple.Picker.setItems({
              container: this.getElement({ name: "NamesEditor" }),
              items: r8.metadata.names(),
              selectedIds: simple.List.selectedIds.parse({ ids: simple.Storage.getValue({ path: "r8.contribute" }).names }).ids
            })
          },
          {
            name: "Contribute$TagsEditor",
            group: "Editors",
            enter: () => simple.Picker.setItems({
              container: this.getElement({ name: "TagsEditor" }),
              items: r8.metadata.tags(),
              selectedIds: simple.Storage.getValue({ path: "r8.contribute" }).tags
            })
          },
          {
            name: "Contribute$DatesEditor",
            enter: ({ value }) => {
              const { descriptor, from, to, hasToDate } = value;
              simple.DateRange.setOptions({ container: this.getElement({ name: "DatesEditorDateRange" }), descriptor, from, to, hasToDate });
            },
            leave: () => simple.DateRange.deactivate({ container: this.getElement({ name: "DateRange" }) })
          },
          {
            name: "Contribute$Contribution",
            enter: ({ value }) => {
              const { from, to, names, tags } = simple.Storage.getValue({ path: "r8.contribute" });
              const { contribution = { names: simple.List.selectedIds.parse({ ids: names }).ids, tags, from, to, type: "Point", direction: "Buy" }, mode } = value;

              simple.Input.set({
                container: this.getElement({ name: "Contribution" }), object: contribution,
                handle: ({ property, element, value }) => {
                  switch (property) {
                    case "names":
                      simple.List.setItems({ container: element, items: r8.metadata.names().filter(name => value.includes(name.id)), selectedIds: value });
                      break;
                    case "tags":
                      simple.List.setItems({ container: element, items: r8.metadata.tags().filter(tag => value.includes(tag.id)), selectedIds: value });
                      break;
                    case "dateRange":
                      simple.DateRange.setOptions({ container: element, from, to });
                      break;
                  }
                },
                mode
              });
            }
          },
          {
            name: "Contribute$ContributionRange",
            group: "ContributionType",
            backable: false,
            enter: function () {
              this.execute({ batch: { descriptors: ["Contribute$ContributionHasToDate$Enter"], transient: true } });
              simple.RadioList.setSelectedId({ container: this.getElement({ name: "ContributionType" }), id: "Range" });
            },
            reEntryAction: "Ignore"
          },
          {
            name: "Contribute$ContributionPoint",
            group: "ContributionType",
            backable: false,
            enter: () => {
              this.execute({ batch: { descriptors: ["Contribute$ContributionPointMore$Leave", "Contribute$ContributionPointHasClose$Leave"], transient: true } });

              // TODO: don't do it here. do it once upon contribution launch
              ["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(name =>
                simple.Spinner.setSelectedId({
                  container: this.getElement({ name }),
                  id: "None"
                }));
            }
            // leave: () => simple.DateRange.setHasToDate({ container: this.getElement({ name: "ContributionDateRange" }), appContainer: this.getAppContainer(), hasToDate: true })
          },
          {
            name: "Contribute$ContributionPointHasClose",
            enter: () => simple.DateRange.setHasToDate({ container: this.getElement({ name: "ContributionDateRange" }), hasToDate: true }),
            leave: () => simple.DateRange.setHasToDate({
              container: this.getElement({ name: "ContributionDateRange" }),
              hasToDate: false
            })
          },
          {
            name: "Contribute$ContributionDatesEditor",
            enter: ({ value }) => {
              const { descriptor } = value;
              const { from, to, hasToDate } = simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDateRange" }) });
              simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDatesEditorDateRange" }), descriptor, hasToDate, from, to });
            }
          },
          {
            name: "Contribute$ContributionDatesEditor",
            leave: () => simple.DateRange.deactivate({ container: this.getElement({ name: "ContributionDateRange" }) })
          },
          {
            name: "Contribute$ContributionNamesEditor",
            group: "ContributionEditors",
            enter: ({ container }) => simple.Picker.setItems({
              container: this.getElement({ name: "ContributionNamesEditor" }),
              items: r8.metadata.names(), selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionNames" }) })
            })
          },
          {
            name: "Contribute$ContributionTagsEditor",
            group: "ContributionEditors",
            enter: ({ container }) => simple.Picker.setItems({
              container: this.getElement({ name: "ContributionTagsEditor" }),
              items: r8.metadata.tags(), selectedIds: simple.List.getSelectedIds({ container: this.getElement({ name: "ContributionTags" }) })
            })
          }
        ],
      routes: [
        {
          hash: "#contribute",
          handle: () => this.default(),
          default: true,
          fallBack: true
        },
        {
          hash: "#contribute/contributions",
          handle: () => this.contributions()
        },
        {
          hash: "#contribute/contributions/discuss",
          handle: ({ values }) => this.contributionDiscuss({ contributionId: values[0] })
        },
        {
          hash: "#contribute/contributions/create",
          handle: () => this.contributionCreate()
        },
        {
          hash: "#contribute/contributions/edit",
          handle: ({ values }) => this.contributionEdit({ contributionId: values[0] })
        },
        {
          hash: "#contribute/contributions/delete",
          handle: ({ values }) => this.contributionDelete({ contributionId: values[0] })
        }
      ],
      name: "Contribute",
      context
    });
  }

  create({ app }) {
    const container = simple.Dom.getElement({ container: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ container, name: this.name });
    return { container: container.children[0] };
  }

  init() {
    super.init();

    const like = ({ originator, id }) => {
      let elementId;
      let containers;
      let targetType;

      switch (originator) {
        case "Contribution":
          containers = ["Contributions"].map(name => this.getElement({ name }));
          elementId = `contribution_like_count_${id}`;
          targetType = "Contribution";
          break;
        case "ContributionExport":
          containers = ["DiscussionContext", "Contributions"].map(name => this.getElement({ name }));
          elementId = `contribution_like_count_${id}`;
          targetType = "Contribution";
          break;
        case "Post":
          containers = [simple.Discussion.getPostList({ container: this.getElement({ name: "Discussion" }) })];
          elementId = `post_like_count_${id}`;
          targetType = "Post";
          break;
        case "PostExport":
          containers = [
            simple.Discussion.getPostList({ container: this.getElement({ name: "Discussion" }) }),
            simple.Discussion.getParentPost({ container: this.getElement({ name: "Discussion" }) })
          ];

          elementId = `post_like_count_${id}`;
          targetType = "Post";
          break;
      }

      const update = ({ count }) => {
        containers.forEach(container => {
          const items = container.expandos.items;
          if (items) {
            const item = items.find(item => item.id === id);
            if (item) {
              item.likeCount = count;
            }
          }

          simple.Dom.getById({ container, id: elementId }).innerHTML = count;
        });
      };

      const { authenticate } = this.context.getController({ name: "App" }).export();
      authenticate({ allowGuestLogin: false }).then(r8.services.reactions.add({ targetId: id, targetType, reactionType: "Like" }).then(update));
    };

    const share = ( /*{ originator, id }*/) => { debugger; };

    simple.DateRange.init({
      container: this.getElement({ name: "DateRange" }),
      on: ({ name, descriptor }) => {
        if (name === "Activate") {
          const { from, to, hasToDate } = simple.DateRange.getOptions({ container: this.getElement({ name: "DateRange" }) });
          this.execute({ batch: { states: [{ descriptor: "Contribute$DatesEditor$Enter", value: { descriptor, from, to, hasToDate } }] } });
        }
      }
    });

    simple.DateRange.init({
      container: this.getElement({ name: "DatesEditorDateRange" }),
      getSlider: () => this.getElement({ name: "DatesEditorSlider" })
    });

    simple.Slider.init({ container: this.getElement({ name: "DatesEditorSlider" }) });

    simple.CheckboxList.init({
      container: this.getElement({ name: "ContributionsFilter" }),
      items: r8.metadata.contributionsFilterCategories(),
      on: ({ value }) => simple.List.filter({
        container: this.getElement({ name: "Contributions" }),
        filter: ({ item }) => value.length === 0
          || value.length === 2
          || value.includes("Range") && item.type === "Range"
          || value.includes("Point") && item.type === "Point"
      })
    });

    simple.List.init({
      container: this.getElement({ name: "Contributions" }),
      template: ({ item, mode }) => {
        return simple.Dom.evalTemplate({
          name: {
            "Range.Render": "Contribute.ContributionRangeRender",
            "Range.Export": "Contribute.ContributionRangeExport",
            "Point.Render": "Contribute.ContributionPointRender",
            "Point.Export": "Contribute.ContributionPointExport"
          }[`${item.type}.${mode}`],
          context: { item }
        });
      },
      emptyText: "No Contributions.",
      commands:
        [
          { name: "Like", handle: like },
          {
            name: "Discuss",
            handle: ({ id }) => simple.Application.navigate({ hash: `contribute/contributions/discuss/${id}` })
          },
          { name: "Share", handle: share }
        ]
    });

    ["ContributionNames", "ContributionTags"].forEach(name =>
      simple.List.init({
        container: this.getElement({ name })
      }));

    simple.Picker.init({
      container: this.getElement({ name: "ContributionNamesEditor" }),
      filter: {
        categories: r8.metadata.nameCategories(),
        handle: r8.metadata.match
      },
      on: ({ name, selectedIds }) => {
        const items = r8.metadata.names().filter(name => selectedIds.includes(name.id));
        switch (name) {
          case "Change":
            simple.List.setItems({
              container: this.getElement({ name: "ContributionNames" }),
              items,
              selectedIds
            });
            simple.Application.apply();
            break;
        }
      }
    });

    simple.Picker.init({
      container: this.getElement({ name: "ContributionTagsEditor" }),
      filter: { categories: r8.metadata.tagCategories(), handle: r8.metadata.match },
      on: ({ name, selectedIds }) => {
        const items = r8.metadata.tags().filter(name => selectedIds.includes(name.id));
        switch (name) {
          case "Change":
            simple.List.setItems({ container: this.getElement({ name: "ContributionTags" }), items, selectedIds });
            simple.Application.apply();
            break;
        }
      }
    });

    simple.DateRange.init({
      container: this.getElement({ name: "ContributionDateRange" }),
      on: ({ name, descriptor }) => {
        if (name === "Activate") {
          const { from, to, hasToDate } = simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDateRange" }) });

          this.execute({ batch: { states: [{ descriptor: "Contribute$ContributionDatesEditor$Enter", value: { descriptor, from, to, hasToDate } }] } });
        }
      }
    });

    // TODO: should be init'ed as part of data range init
    simple.Slider.init({ container: this.getElement({ name: "ContributionDatesEditorSlider" }) });

    simple.DateRange.init({
      container: this.getElement({ name: "ContributionDatesEditorDateRange" }),
      getSlider: () => this.getElement({ name: "ContributionDatesEditorSlider" })
    });

    simple.RadioList.init({
      container: this.getElement({ name: "ContributionType" }),
      items: r8.metadata.contributionTypes(),
      selectedId: "Range",
      on: ({ name, id, manual }) => {
        switch (name) {
          case "Select":
            const descriptor = { Range: "Contribute$ContributionRange$Enter", Point: "Contribute$ContributionPoint$Enter" }[id];
            if (!descriptor) {
              throw `Invalid Contribution Type: '${id}'`;
            }
            this.execute({ batch: { descriptors: [descriptor], transient: true } });
            break;
          default:
            throw `Invalid Command: '${name}'`;
        }
      }
    });

    this.addEventHandles({
      name: "ContributionsLauncher", events: "click", handle: () => {
        simple.Application.navigate({ hash: "contribute/contributions" });
      }
    });

    this.addEventHandles({
      name: "ContributionCreate", events: "click", handle: () => {
        simple.Application.navigate({ hash: "contribute/contributions/create" });
      }
    });

    simple.RadioList.init({
      container: this.getElement({ name: "ContributionPointDirection" }),
      items: r8.metadata.contributionPointDirections(),
      selectedId: "Buy"
    });

    simple.RadioList.init({
      container: this.getElement({ name: "ContributionPointCloseMode" }),
      items: r8.metadata.contributionPointCloseModes(),
      selectedId: "Manual"
    });

    ["ContributionPointRiskEstimate", "ContributionPointVolumeEstimate", "ContributionPointLeverageEstimate"].forEach(name =>
      simple.Spinner.init({
        container: this.getElement({ name }),
        items: r8.metadata.estimates()
      }));

    simple.Dom.addEventHandles({
      element: this.getElement({ name: "DiscussionContext" }),
      events: "click",
      handleCommands: true,
      handle: ({ commandArguments }) => {
        const { id, name, originator } = commandArguments;
        switch (name) {
          case "Like":
            like({ id, originator });
            break;
        }
      }
    })

    simple.Discussion.init({
      container: this.getElement({ name: "Discussion" }),
      template: ({ item, mode }) => {
        const name = {
          "Post.Render": "Contribute.DiscussionPostRender",
          "Post.Export": "Contribute.DiscussionPostExport"
        }[`Post.${mode}`];

        return simple.Dom.evalTemplate({ name, context: { item } });
      },
      commands: [{ name: "Like", handle: like }],
      indent: 30,
      on: ({ name, value }) => {
        switch (name) {
          case "PostAdd":
            let { authenticate, run } = this.context.getController({ name: "App" }).export();

            run = run({
              handle: () => {
                return new Promise((resolve) => {
                  r8.services.posts.add(value).then(() => {
                    const externalId = value.externalId;

                    // TODO: use higher level request for it
                    // Remove post, navigate to self instead
                    simple.Data.request({
                      container: this.getElement({ name: "Contribute" }),
                      providerNames: [r8.PostsProvider].map(provider => provider.name),
                      force: true,
                      request: { externalId }
                    }).then(({ data }) => {

                      simple.Discussion.setItems({ container: this.getElement({ name: "Discussion" }), items: data[r8.PostsProvider.name] });

                      simple.Application.apply();

                      resolve();
                    });
                  });
                });
              },
              options: { text: "Getting Posts..." }
            });

            authenticate({ allowGuestLogin: true }).then(run);

            break;
        }
      }
    });

    simple.Data.init({
      container: this.getElement({ name: "Contribute" }),
      providers: [r8.QuotesProvider, r8.ContributionsProvider, r8.PostsProvider]
    });

    // todo: don't use root element
    const requestContainer = this.getElement({ name: "Contribute" });

    simple.Chart.init({
      container: this.getElement({ name: "Chart" }),
      bands: [r8.bands.weekDays],
      on: ({ name, value }) => {
        if (name === "DragStart") {
          return;
        }

        const { from, to } = value;
        const request = Object.assign(simple.Data.getRequest({ container: requestContainer }), { from, to });

        switch (name) {
          case "Drag":
            this.request({ request });
            break;
          case "DragStop":
            simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { from, to }) });
            this.load();
            break;
        }
      }
    });

    simple.Picker.init({
      container: this.getElement({ name: "TagsEditor" }),
      filter: { categories: r8.metadata.tagCategories(), handle: r8.metadata.match },
      on: ({ selectedIds }) => {
        simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { tags: selectedIds }) });
        simple.Application.apply();
        loadState();
      }
    });

    simple.List.init({
      container: this.getElement({ name: "Tags" }),
      on: ({ ids, selectedIds, name }) => {
        switch (name) {
          case "Change":
            simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { tags: ids }) });
            loadState();
            break;
          default:
            throw `Invalid Event:${name}`;
        }
      }
    });

    simple.Picker.init({
      container: this.getElement({ name: "NamesEditor" }),
      filter: { categories: r8.metadata.nameCategories(), handle: r8.metadata.match },
      on: ({ selectedIds }) => {
        simple.Storage.setValue({ path: "r8.contribute", mutator: (value) => Object.assign(value, { names: imple.List.selectedIds.update({ ids: value.names, newIds: selectedIds }) }) });
        simple.Application.apply();
        loadState();
      }
    });

    simple.List.init({
      container: this.getElement({ name: "Names" }),
      on: ({ ids, selectedIds, name }) => {
        switch (name) {
          case "Change":
          case "Select":
            simple.Storage.setValue({ path: "r8.contribute", mutator: (value) => Object.assign(value, { names: simple.List.selectedIds.build({ ids, selectedId: selectedIds[0] }) }) });
            this.load();
            break;
          default:
            throw `Invalid Event:${name}`;
        }
      }
    });

    this.addEventHandles({
      name: "ContributionDatesEditorDone",
      events: "click",
      handle: () => {
        const { from, to, hasToDate } = simple.DateRange.getOptions({ container: this.getElement({ name: "ContributionDatesEditorDateRange" }) });

        simple.DateRange.setOptions({ container: this.getElement({ name: "ContributionDateRange" }), from, to, hasToDate });

        simple.Application.apply();
      }
    });

    this.addEventHandles({
      name: "DatesEditorDone",
      events: "click",
      handle: () => {
        const { from, to } = simple.DateRange.getOptions({ container: this.getElement({ name: "DatesEditorDateRange" }) });
        simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { from, to }) });
        simple.Application.apply();

        debugger;

        this.load();
      }
    });

    this.addEventHandles({
      name: "ContributionAdd",
      events: "click",
      handle: () => {
        const { object: contribution, valid } = simple.Input.validatingGet({
          container: this.getElement({ name: "Contribution" }),
          handle: ({ property, value, object }) => {
            switch (property) {
              case "dateRange":
                object = Object.assign(object, { from: value.from, to: value.to });
                break;
            }
          }
        });

        const mode = simple.Input.getMode({ container: this.getElement({ name: "Contribution" }) });
        let allowGuestLogin;

        switch (mode) {
          case "Create":
            allowGuestLogin = true;
            break;
          case "Edit":
            allowGuestLogin = false;
            break;
          case "Delete":
            allowGuestLogin = false;
            break;
        }

        return;

        if (valid) {
          const { authenticate, run } = this.context.getController({ name: "App" }).export();
          const action = r8.services.contributions[mode.toLowerCase()];
          const requery = simple.Data.request({
            container: this.getElement({ name: "Contribute" }),
            providerNames: [r8.ContributionsProvider].map(provider => provider.name)
          }).then(({ data, request, padding }) => {
            const contributions = data[r8.ContributionsProvider.name];
            if (contributions) {
              simple.List.setItems({ container: this.getElement({ name: "Contributions" }), items: contributions });
            }

            // TODO: fix padding
            simple.Application.apply();
            resolve();
          });

          authenticate({ allowGuestLogin }).then(() => {
            run({
              handle: () => {
                return new Promise((resolve) => {
                  action(contribution).then(() => requery);
                });
              },
              options: { text: "***'ing Contribution..." }
            });
          });
        }
      }
    });
  }


  load() {
    // rename getDefaultState to createState
    const state = simple.Storage.getValue({ path: "r8.contribute", defaultValue: r8.services.app.getDefaultState() });

    let { ids, selectedId } = simple.List.selectedIds.parse({ ids: state.names });
    simple.List.setItems({ container: this.getElement({ name: "Names" }), items: r8.metadata.names().filter(name => ids.includes(name.id)), selectedIds: [selectedId] });

    ids = simple.List.selectedIds.parse({ ids: state.tags }).ids;
    simple.List.setItems({ container: this.getElement({ name: "Tags" }), items: r8.metadata.tags().filter(tag => ids.includes(tag.id)), selectedIds: ids });

    simple.DateRange.setOptions({ container: this.getElement({ name: "DateRange" }), from: state.from, to: state.to });
  }

  request({ request }) {
    return new Promise((resolve) => {
      simple.Data.request({
        container: this.getElement({ name: "Contribute" }),
        providerNames: [r8.QuotesProvider, r8.ContributionsProvider].map(provider => provider.name),
        request
      }).then(({ data, request, padding }) => {

        this.getElement({ name: "DataPadding" }).innerHTML = simple.Dom.evalTemplate({ name: "Contribute.DataPadding", context: padding });

        const quotes = data[r8.QuotesProvider.name];
        if (quotes) {
          simple.Chart.setData({ container: this.getElement({ name: "Chart" }), data: quotes });
        }

        const contributions = data[r8.ContributionsProvider.name];
        if (contributions) {
          simple.List.setItems({ container: this.getElement({ name: "Contributions" }), items: contributions });
        }

        resolve({ request });
      });
    });
  }

  default() {
    this.load(); // TODO: remove from get data, brakes single reposobiity principle
    const request = simple.Storage.getValue({ path: "r8.contribute", defaultValue: r8.services.app.getDefaultState() });

    return this.request({ request }).then((/*{ request }*/) => {
      return Promise.resolve();
    })
  }

  contributions() {
    this.execute({ batch: { descriptors: ["Contribute$Contributions$Enter"] } });
    return Promise.resolve();
  }

  contributionDiscuss({ contributionId }) {
    return r8.services.contributions.get({ id: contributionId }).then(result => {
      const contribution = result[0];
      const { discussion: posts } = contribution;

      const getContributionContextHtml = ({ contribution }) => simple.Dom.evalTemplate({
        name: {
          "Range": "Contribute.ContributionRangeExport",
          "Point": "Contribute.ContributionPointExport"
        }[`${contribution.type}`],
        context: { item: contribution } // TODO: change templates to make them idependant form the name of the context data
      });

      simple.Discussion.setExternalId({ container: this.getElement({ name: "Discussion" }), id: contributionId });

      this.getElement({ name: "DiscussionContext" }).innerHTML = getContributionContextHtml({ contribution });

      simple.Discussion.setItems({ container: this.getElement({ name: "Discussion" }), items: posts });

      this.execute({ batch: { descriptors: ["Contribute$Discussion$Enter"] } });

      return Promise.resolve();
    });
  }

  contributionCreate() {
    this.execute({ batch: { states: [{ descriptor: "Contribute$Contribution$Enter", value: { mode: "Create" } }] } });
    return Promise.resolve();
  }

  contributionEdit({ contributionId }) {
    return r8.services.contributions.get({ id: contributionId }).then(result => {
      const contribution = result[0];
      this.execute({ batch: { states: [{ descriptor: "Contribute$Contribution$Enter", value: { contribution, mode: "Edit" } }] } });
      return Promise.resolve();
    });
  }

  contributionDelete({ contributionId }) {
    return r8.services.contributions.get({ id: contributionId }).then(result => {
      const contribution = result[0];
      this.execute({ batch: { states: [{ descriptor: "Contribute$Contribution$Enter", value: { contribution, mode: "Delete" } }] } });
      return Promise.resolve();
    });
  }
};