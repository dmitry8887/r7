﻿r7.app.controllers.app.research = new function() {
    this.route = "app$app.research";
    this.hash = "research";

    this.enter = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
};