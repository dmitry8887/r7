﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web.Http;
using Dapper;
using r8.Models;

namespace r8.Controllers
{
  //[EnableCors(origins: "*", headers: "*", methods: "*")]
  public class ReactionsController : ApiController
  {
    private static readonly string ConnectionString =
      ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    // POST api/<controller>
    [HttpPost]
    public ReactionResult Post(Reaction reaction) //[FromBody]
    {
      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        if (!string.IsNullOrEmpty(reaction.UserToken))
        {
          int appUserId;
          if (AuthenticationController.TryGetAppUserId(reaction.UserToken, out appUserId))
          {
            reaction.AppUserId = appUserId;
          }
          else
          {
            // TODO: throw & log
            throw new Exception("Invalid Token.");
          }
        }

        reaction.CreatedDate = DateTime.UtcNow;
        reaction.Ip = Utils.GetCallerIp();

        reaction.Id = connection.Query<int>(Utils.GenerateInsertSql("dbo.[Reaction]",
              new[]
              {
                "TargetId", "TargetType", "ReactionType", "AppUserId", "CreatedDate", "Ip"
              }),
            reaction.Sanitize())
          .Single();

        var count = connection.Query<int>($@"SELECT Count(*) 
            FROM dbo.[Reaction] WITH(NOLOCK) 
            WHERE TargetId = {reaction.TargetId} AND ReactionType = '{reaction.ReactionType}'").First();

        connection.Close();

        return new ReactionResult()
        {
          Count = count,
          Message = "Success"
        };
      }
    }
  }
}