﻿"use strict";

r8.controllers.Labs = new class extends simple.Stateful {
    get routing() {
        return { route: "App$Labs", hash: "labs" };
    }

    constructor() {
        super({ states: 1 });
    }

    enter() {
        document.querySelector("#view").innerText = "Labs";

        console.warn(`App Enter from: ${this.from} - to: ${this.to}`);
    }

    leave() {
        console.warn(`App Leave from: ${this.from} - to: ${this.to}`);
    };
}