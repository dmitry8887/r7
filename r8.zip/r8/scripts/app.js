﻿const r8 = {};
r8.controllers = {};

r8.boostrap = () => {
    simple.Router.init({
        container: document.querySelector("#app"),
        controllers: () => [r8.controllers.App, r8.controllers.Contribute, r8.controllers.Research, r8.controllers.Labs],
        hash: "contribute"
    });
};