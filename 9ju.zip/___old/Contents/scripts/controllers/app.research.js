﻿"use strict";

var fxrig = fxrig || {};
fxrig.controllers = fxrig.controllers || {};
fxrig.controllers.app = fxrig.controllers.app || {};

fxrig.controllers.app.research = new function() {
    this.hash = "research";
    this.url = "html/views/research.html";
    this.route = "app$app.research";

    var self = {
        
    };

    this.enter = function (context) {
        console.info("entering fxrig.controllers.app.research");

        return new window.Promise(function (resolve, reject) {
            resolve(context);
        });
    };

    this.leave = function (context) {
        console.info("leaving fxrig.controllers.app.research");

        return new window.Promise(function (resolve, reject) {
            resolve(context);
        });
    };
};