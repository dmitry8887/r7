﻿const r8 = {};
r8.controllers = {};
r8.bands = {};
r8.providers = {};

// interesno nado sdelat' odnorazovie inicializacii a potom targetirovannie akcii naprimer gruzanut' kontirbucoo i perejti k nim 
// ili gruzanut' diskussi i perejti k nim
r8.routes =
    [
        {
            name: "contribute", path: "contribute", handle: ({ container }) => {
                r8.controllers.App.create({ container });
            }
        },
        {
            path: "contribute/contributions", handle: {
                name: "contribute"
            }
        },
        {
            path: "contribute/contribution", handle: {
                name: "contribute"
            }
        }
    ];