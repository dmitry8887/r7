﻿var fxrig = fxrig || {};
fxrig.utils = new function() {

    this.load = function(e) {
        return new window.Promise(function(resolve, reject) {
            e.container.load(e.url + "?a=1", function(response, status /*, xhr*/) {
                if (status === "success") {

                    resolve({ html: response }); // todo: should it not be be just (e.context)?
                } else {
                    reject({ error: "Can't load Contents." });
                }
            });
        });
    };

    this.get = function(e) {
        return new window.Promise(function(resolve, reject) {
            $.ajax({
                context: e,
                type: "get",
                url: e.url,
                complete: function(xhr, status) {
                    if (status === "success") {
                        this.text = xhr.responseText;
                        resolve(this);
                    } else {
                        reject(this);
                    }
                }
            });
        });
    };

    this.delay = function (time) {
        var d1 = new Date();
        var d2 = new Date();
        while (d2.valueOf() < d1.valueOf() + time) {
            d2 = new Date();
        }
    };

    this.clone = function (o) {
        //function Clone() { }
        //Clone.prototype = o;
        //return new Clone();
        return JSON.parse(JSON.stringify(o));
    }
};

fxrig.utils.ui = fxrig.utils.ui || {};
fxrig.utils.ui.renderValidationOutput = function (container, errors) {
    var templateHtml = fxrig.state.getCacheItem({ appName: "fxrig", name: "validation_output" });
    var compiled = _.template(templateHtml);

    container.html(compiled({ errors: errors }));
};


fxrig.utils.ui = fxrig.utils.ui || {};
fxrig.utils.ui.draggable = function (args) {

    var $container = args.container;
    if ($container.state().dragging === true) {
        return;
    }

    var range = args.range, step = args.step, on = args.on; //todo: don't use state rely on closures?
    var state = $container.state({ range: range });

    range.length = range.max - range.min; // cash as it shouldn't change

    if (step * Math.floor(range.min / step) !== range.min
        || step * Math.floor(range.max / step) !== range.max) {

        debugger;
        throw { error: "Invalid range for the step." };
    }

    $container.draggable({
        helper: function () {
            return $("<div></div>");
        },
        start: function () {
            state.width = $(this).width();
            state.containerOffset = $container.offset().left;

            if (!state.dragging) {
                range = state.range;
            }

            state.dragging = true;
            on({ name: "Dragging", value: true });
        },
        drag: function (event, ui) {
            
            var offset = (state.containerOffset- ui.offset.left) / state.width; // ui
            offset = state.range.length * offset; // minutes

            var round = Math.round;//  xOffsetPct > 0 ? Math.ceil : Math.floor;

            var currentMin = round(range.min + offset);

            if (currentMin !== range.currentMin) {

                // round
                currentMin = step * round(currentMin / step);

                if (currentMin !== range.currentMin) {

                    var diff = currentMin - range.min;

                    range.currentMin = currentMin;
                    range.currentMax = range.max + (range.currentMin - range.min);

                    // console.error("Diff:" + diff + " currentMin: " + currentMin + " range.min: " + range.min);

                    on({ name: "Change", value: { min: range.currentMin, max: range.currentMax, step: step, diff: diff } });
                } else {

                }
            } else {
                // console.error("Cache!");
            }
        },
        stop: function () {
            state.range = { min: state.range.currentMin, max: state.range.currentMax, step: step, length: state.range.length };
            state.dragging = false;

            on({ name: "Dragging", value: false });
        }
    });
};


fxrig.utils.math = fxrig.utils.math || {};
fxrig.utils.math.splitRange = function (range, count, decimals) {
    var min = range.min, max = range.max;
    var step = (max - min) / (count);

    var current = min;
    var values = [current.toFixed(decimals)];

    for (var i = 0; i < count; i++) {
        if (i === count - 1) {
            current = max;
        } else {
            current = current + step;
        }

        values.push(current.toFixed(decimals));
    }

    return values;
};

fxrig.utils.math.isSet = function(range) {
    return range.min !== Number.MAX_VALUE && range.min && Number.MIN_VALUE;
};


fxrig.utils.math.coerceRange = function (range, threshold) {
    var timeframes = [1, 5, 15, 30, 60, 120, 240, 480, 1440, 10080, 43200];
    var min = range.min, max = range.max;

    for (var i = 0; i < timeframes.length; i++) {
        var timeframe = timeframes[i];
        var count = (max - min) / timeframe;

        if (count < threshold) {
            return { min: Math.floor(min / timeframe), max: Math.ceil(max / timeframe), timeframe: timeframe };
        }
    }

    throw { error: "Cannot Coerce: " + JSON.stringify(_.assign(range, { threshold: threshold })) };
}


fxrig.utils.data = fxrig.utils.data || {};
fxrig.utils.data.normilizeNames = function(names) {
    return names.split(":")[0].split(",").sort().join(",");
};

fxrig.utils.data.getHitRate = function(selection, item) {
    if (item.from <= selection.to && selection.from <= item.to) {
        // jaccard index
        //max ( min(a2, b2) - max(a1, b1) / max(a2, b2) - min(a1, b1), 
        return Math.ceil(100 * Math.max((Math.min(selection.to, item.to) - Math.max(selection.from, item.from)) / (Math.max(selection.to, item.to) - Math.min(selection.from, item.from)), 0));
    } else {
        return 0;
    }
};

fxrig.utils.data.coerceDisplay = function (display, threshold) {
    var timeframes = [1, 5, 15, 30, 60, 120, 240, 480, 1440, 10080, 43200];
    var from = display.from, to = display.to;
    
    for (var i = 0; i < timeframes.length; i++) {
        var timeframe = timeframes[i];
        var count = (to - from) / timeframe;

        if (count < threshold) {
            return _.assign(fxrig.utils.clone(display), { from: timeframe * Math.floor(from / timeframe), to: timeframe * Math.ceil(to / timeframe), timeframe: timeframe });
        }
    }

    throw { error: "Cannot Coerce: " + JSON.stringify(_.assign(range, { threshold: threshold })) };
}

fxrig.utils.data.mergeNames = function(oldNames, newNames) {
    if (oldNames === newNames) {
        return newNames;
    } else {
        var oldSelectedName = oldNames.split(":")[1];
        newNames = newNames.split(":")[0].split(",");
        var newSelectedName = newNames.indexOf(oldSelectedName) > -1 ? oldSelectedName : newNames[0];

        return newNames.join(",") + ":" + newSelectedName;
    }
};

fxrig.utils.data.getPointCount = function (display) {
    return (display.to - display.from) / display.timeframe;
};

fxrig.utils.data.isEmpty = function(data, selectedName) {
    var selectedSet = _.find(data.Sets, function (set) { return set.Name === selectedName; });
    return selectedSet.Points.length === 0;
};

fxrig.utils.data.getSet = function (data, name) {
    return _.find(data.Sets, function(set) { return set.Name === name; });
};


// todo: should be ui?
fxrig.utils.data.getPlotData = function(data, display, plotSize, margin, colors) {
    var plotData = [];

    var xRatio = plotSize.width / (display.to - display.from);
    
    var xMargin = margin.x;
    var yMargin = margin.y;

    var selectedName = display.names.split(":")[1];

    for (var i = 0; i < data.Sets.length; i++) {
        var set = data.Sets[i];
        var level = fxrig.services.meta.getVolatilityLevel(set.Name, set.Range);
        var selected = set.Name === selectedName;
        var color = colors[i];

        //var seria = { name: set.Name, points: [] };

        var rangeMin = set.Range.min;
        
        var height = level * plotSize.height / 5;
        var top = (plotSize.height - height) / 2;

        var yRatio = height / (set.Range.max - set.Range.min);

        // slow, improve by implmenting dictionary or better array with offset
        var x, y;
        var svgData = "";

        for (var j = display.from; j <= display.to; j = j + display.timeframe) {
            var point = _.find(set.Points, function (p) { return p.O === j; });

            if (point) {
                x = xMargin + xRatio * (j - display.from);
                y = yMargin + top + (yRatio * (point.M - rangeMin));
                
                //seria.points.push({ x: x, y: y });
                x = Math.round(x * 100) / 100;
                y = Math.round(y * 100) / 100;

                //x = Math.round(x);
                //y = Math.round(y);

                svgData = svgData + x + "," + y + " ";
            } else {
                throw { error: "Invalid Operation." };
            }
        }

        var svg = "<polyline fill='none' stroke='{2}' stroke-width='{1}' points='{0}' stroke-linecap='square' />".format(svgData, selected ? 2.5 : 5, color);
        plotData.push(svg);
    }

    return plotData.join();
};