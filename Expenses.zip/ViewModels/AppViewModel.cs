﻿using BookKeeper.Commands;
using BookKeeper.Models;
using BookKeeper.Services;
using System.Collections.Generic;
using System.Windows.Input;

namespace BookKeeper.ViewModels
{
    public class AppViewModel
    {
        public static readonly string MonthFormat = "MMM";

        private readonly List<object> _parts;

        private readonly ExpenseSummaryViewModel _summary;
        private readonly ExpenseViewModel _editor;

        public AppViewModel()
        {
            _summary = new ExpenseSummaryViewModel(this);
            _editor = new ExpenseViewModel(this) { IsVisible = false };

            _parts = new List<object>()
            {
                _summary, _editor
            };

            NewCommand = new RelayCommand(() =>
            {
                Editor.Reset();
                Editor.IsVisible = true;
            });

            CancelCommand = new RelayCommand(() =>
            {
                Editor.Reset();
                Editor.IsVisible = false;
            });

            AddCommand = new RelayCommand(() =>
            {
                if (!Editor.TryAdd()) return;

                Summary.Refine();
                Editor.IsVisible = false;
            });

            Categories = new DbService().GetExpenseCategories();
        }

        // ReSharper disable once ConvertToAutoProperty
        public List<object> Parts => _parts;

        public List<ExpenseCategory> Categories
        {
            get;
            private set;
        }

        private ExpenseSummaryViewModel Summary => _summary;

        private ExpenseViewModel Editor => _editor;

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public ICommand NewCommand { get; private set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public ICommand CancelCommand { get; private set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public ICommand AddCommand { get; private set; }
    }
}
