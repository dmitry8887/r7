﻿"use strict";

var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};
fxrig.controls.discussion = new function () {

    this.init = function (initArgs) {
        var $container = initArgs.container;
        $container.state({ on: initArgs.on });
        
        return window.Promise.resolve(initArgs); // todo: remove
    };

    var build = function (html, post) {
        var id = post.Id, pid = post.ParentId || 0;

        var postPlaceholderHmtl;
        var isLeaf = parseInt(pid) === 0;

        if (isLeaf) {
            postPlaceholderHmtl = "<div id='post_{0}'></div>".format(id);
        } else {
            postPlaceholderHmtl = "<div class='metrical-padding-left-35' id='post_{0}'><div id='content'></div></div>".format(id);
        }

        if (html.length === 0) {
            html = postPlaceholderHmtl;
        } else {
            if (isLeaf) {
                html = html + postPlaceholderHmtl;
            } else {
                var delimiter = "post_{0}".format(pid);
                var htmlParts = html.split(delimiter);

                html = htmlParts[0] + delimiter;

                delimiter = ">";
                htmlParts = htmlParts[1].split(delimiter);

                var part = htmlParts[0];

                htmlParts.splice(0, 1);

                html = html + part + delimiter + postPlaceholderHmtl + htmlParts.join(delimiter);
            }
        }

        return html;
    };

    var renderReply = function (e) {
        var $container = e.container;
        var $posts = $container.find("#posts");
        var state = $container.state();

        var postId = parseInt(e.postId || 0);
        var isRoot = postId === 0;

        var $reply = $("#reply", $posts);
        var currentReplyToPostId = state.replyToPostId; // review

        if ($reply.length !== 0) {
            if (currentReplyToPostId === postId) {
                return;
            } else {
                $reply.remove();
            }
        }
        
        var replyHtml = fxrig.state.getCacheItem({ appName: "fxrig", name: "reply" }).format(isRoot ? "" : "metrical-padding-left-35");
        
        var $replyContainer = $("#reply_container_" + postId, $container);
        $replyContainer.append(replyHtml);

        state.replyToPostId = postId; // todo: remove

        $("#save", $replyContainer).on("click", function () {
            var getPost = function(){
                return { parentId: postId, text: $("#reply_text", $replyContainer).val(), discussionId: state.discussionId };
            };

            state.on({ name: "AddPost", value: getPost() });
        });
    };

    var renderPost = function (renderPostArgs) {
        var $container = renderPostArgs.container;
        var post = renderPostArgs.post;

        var postId = post.Id;
        var $post = $("#post_" + postId, $container);

        var isLeaf = $post.children().length === 0;
        if (isLeaf) {
            $post.empty();
        }

        var postHtml = fxrig.state.getCacheItem({ appName: "fxrig", name: "post" });

        postHtml = postHtml.format(postId, post.User, post.Created, post.Text); // todo: underscore template

        $post.prepend(postHtml); //$post.append(html); // TODO brakes the tru order sometimes

        $("#reply_" + postId, $post).on("click", { postId: postId },
            function (event) {
                renderReply({ container: $container, postId: event.data.postId });
            });

        //$("#remove_" + postId, $post).on("click", { postId: postId }, function (clickArgs) {
        //    removePost({ container: $container, postId: clickArgs.data.postId });
        //});
    };

    this.invalidate = function (initArgs) {
        return new window.Promise(function (resolve, reject) {
            var $container = initArgs.container;
            var disucssionHtml = fxrig.state.getCacheItem({ appName: "fxrig", name: "discussion" });

            $container.html(disucssionHtml);

            var state = $container.state({ data: initArgs.data.Discussions });
            state.discussionId = state.data.filter.discussionId;
            
            var html = "";
            var i;

            for (i = 0; i < state.data.length; i++) {
                html = build(html, state.data[i]);
            }

            $container.find("#posts").html(html);

            for (i = 0; i < state.data.length; i++) {
                renderPost({ container: $container, post: state.data[i] });
            }

            renderReply({ container: $container });
            
            resolve(initArgs);
        });
    };
};