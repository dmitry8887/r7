﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace r8.Models
{
    public class UserActivitiesResult
    {
        [JsonProperty(PropertyName = "contributions")]
        public List<Contribution> Contributions
        {
            get; set;
        }

        [JsonProperty(PropertyName = "likesGiven")]
        public int LikesGiven { get; internal set; }

        [JsonProperty(PropertyName = "likesReceived")]
        public int LikesReceived { get; internal set; }

        [JsonProperty(PropertyName = "createdDate")]
        public DateTime CreatedDate { get; internal set; }
    }
}