$ = {};
$.Element = {};

$.Element.init = ({ element }) => {
    let expandos = element["expandos"];
    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element.expandos = Object.entries(element.dataset).reduce((previous, current) => {
        const [, value, parsedValue = JSON.parse(value)] = current;
        return Object.assign(previous, parsedValue);
    }, {});

    $.Element.getElements({ element }).forEach(element => {
        $.Element.init({ element });
    });
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.set = ({ element, data }) => {
    const bindings = [];

    const [path, parent] = ["path", "parent"].map(name => Symbol(name));

    const buildPath = (first, second) => first ? [first, second].join(".") : second;

    const isObject = (value) => typeof value === "object";

    $.Element.getElements({ element }).forEach(element => {
        const { type, binding } = element.expandos;
        const component = $.Element.registry[type]();
        const { path } = binding;

        let pathBindings = binding[path];

        if (!pathBindings) {
            bindings[path] = [];
            pathBindings = bindings[path];
        }

        const id = element.id;
        const { get, set } = component.export({ mode: "Binding" });

        bindings[path].push({
            targetId: id,
            get: () => get({ element }),
            set: ({ value }) => set({ element, value })
        });
    });

    const handler = () => {
        const state = { boundTarget: [] };

        return Object.entries({
            get: (target, key) => {
                if (target[path] === undefined) {
                    this.boundTargets.length = 0;
                }

                const value = target[key] || { [path]: buildPath(target[path], key) };

                return isObject(value) ? new Proxy(value, handler()) : value;
            },
            set: (target, key, value) => {
                target[key] = value;

                const path = isObject(target) ? buildPath(target[path], key) : key;

                let binding = bindings[path];

                if (binding) {
                    
                    
                }


                // TODO: merge into one

                if (binding) {
                    binding.forEach(({ set, targetId }) => {
                        this.boundTargets.push({ path, targetId });

                        console.error("+++Binding", { path, targetId, value });

                        set({ value });

                        return true;
                    });
                }
                else {
                    const binding = Object.entries(bindings).find(([key]) => key.startsWith(path));

                    if (binding) {
                        const [key, value] = binding;

                        value.forEach(({ set, targetId }) => {

                            if (!this.boundTargets.some(boundTarget =>
                                boundTarget.key === key
                                && boundTarget.targetId === targetId)) {

                                const target2 = target[parent]();
                                //debugger;

                                console.error("+++ Binding (nested)", { key, targetId, value });
                                set({ value });
                            }
                            else {
                                // console.error("Ignored Binding", { key, targetId, value });
                            }
                        });
                    }
                }
            }
        }).reduce((previus, current) => previus[current[0]] = current[1].bind(state), {});
    };

    const scopeHandler = ({ scope }) => {
        const state = { boundTargets: [] };

        const get = function (target, key) {

        };

        const set = function (target, key, value/*, receiver*/) {
            target[key] = value;

            if (isObject(target)) {
                key = buildPath(target[path], key);
            }

            let binding = bindings[key];

            if (binding) {
                binding.forEach(({ set, targetId }) => {
                    this.boundTargets.push({ key, targetId });

                    console.error("+++Binding", { key, targetId, value });

                    set({ value });

                    return true;
                });
            }
            else {
                // TODO: find the most derived one 
                const { key: parentBidningKey, value: parentBidning } = (Object.entries(bindings)
                    .map(([key, value]) => ({ key, value }))
                    .find(({ key: parentBindingKey }) => key.startsWith(parentBindingKey)) || {});

                if (parentBidning !== undefined) {
                    parentBidning.forEach(({ set, targetId }) => {

                        if (!this.boundTargets.some(boundTarget =>
                            boundTarget.key === parentBidningKey
                            && boundTarget.targetId === targetId)) {

                            const target2 = target[parent]();
                            //debugger;

                            console.error("+++ Binding (nested)", { key, targetId, value });
                            set({ value });
                        }
                        else {
                            // console.error("Ignored Binding", { key, targetId, value });
                        }
                    });
                }
            }

            return true;
        };

        return {
            get: get.bind(state),
            set: set.bind(state)
        }
    };



    const proxy = new Proxy({}, handler({ test: "Scope" }));

    const getKvps = ({ object }) => {
        const kvps = [];

        const process = ({ object }) => {
            Object.entries(object).forEach(entry => {
                let [key, value] = entry;

                const isObjectValue = isObject(value);

                if (isObjectValue) {
                    value[path] = buildPath(object[path], key);

                    //debugger;
                    value[parent] = () => object;

                    key = value[path];
                }
                else {
                    key = buildPath(object[path], key);
                }

                kvps.push({ key, value });

                if (isObjectValue) {
                    process({ object: value });
                }
            });
        };

        process({ object });

        return kvps;
    }

    getKvps({ object: data }).forEach(({ key, value }) => proxy[key] = value);

    return new Proxy(data, handler({ dummy: "Object" }));
};


// very good
$.Interactable = {};















































$.Element.registry = { "List": () => $.List };

