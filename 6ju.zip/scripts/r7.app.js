﻿var r7 = r7 || {};
r7.app = r7.app || {};

r7.app.controllers = r7.app.controllers || {};
r7.app.bootstrap = function () {
    var init = function () {

        // TODO: try moving that state to the root *app* controller
        var states = {
            busy: function () {
                var $overlay = $("#app_overlay");

                $overlay.find("#error_message").hide();
                $overlay.find("#message").show();
                $("#app_overlay").show();
            },
            free: function() {
                $("#app_overlay").hide();
            },
            error: function(e) {
                var $overlay = $("#app_overlay");

                var $errorMessage = $overlay.find("#error_message");

                $errorMessage.html(e.message);

                $overlay.find("#message").hide();
                $errorMessage.show();

                $("#app_overlay").show();
            }
        };

        r7.lib.state.ensureCache({
            items: [
                { name: "lib.menu", url: "html/lib/menu.html" },
                { name: "lib.menu.item.template", url: "html/lib/menu.item.template.html" },
                { name: "lib.chart.expanded", url: "html/lib/chart.expanded.html" },
                { name: "lib.chart.collapsed", url: "html/lib/chart.collapsed.html" },
                { name: "lib.list.expanded", url: "html/lib/list.expanded.html" },
                { name: "lib.list.collapsed", url: "html/lib/list.collapsed.html" },
                //
                { name: "app.views.contribute", url: "html/app/views/contribute.html" },
                { name: "app.views.research", url: "html/app/views/research.html" },
                { name: "app.views.labs", url: "html/app/views/labs.html" }
            ]
        }).then(function() {

            r7.lib.router.init({
                container: $("#app"),
                hash: "contribute",
                defaultHash: "contribute", // TODO: merge hash with defaultHash
                controllers:
                [
                    r7.app.controllers.app,
                    r7.app.controllers.app.contribute,
                    r7.app.controllers.app.research,
                    r7.app.controllers.app.labs
                ],
                predict: function(transition) {
                    //fxrig.apps.ensure({ container: $("#apps", $container), transition: transition });
                },
                navigating: function(e) {
                    states.busy();
                },
                navigated: function (e) {
                    $("#app_view_header").html(e.controller.header);

                    states.free();
                },
                error: function (e) {
                    states.error({ message: e.message });
                }
            });
        });
    };

    init();
};