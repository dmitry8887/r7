﻿//"use strict";

//var r7 = r7 || {};
//r7.core = r7.core || {};

//r7.core.menu = new function() {
//    this.init = function(e) {
//        var $launcher = e.launcher;
//        $launcher.on("click", () => {
//            alert("1");
//        });
//    };
//};