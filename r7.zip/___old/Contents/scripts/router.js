﻿"use strict";

// todo: use Map()
var fxrig = fxrig || {};
fxrig.router = new function() {

    var utils = {
        getController: function(e) {
            var hash = e.hash;
            var route = e.route;
            var name = e.name;

            var state = e.container.state();

            var controller = null;

            if (hash) {
                hash = hash.replace("#", "");

                controller = _.find(state.controllers, function (c) { return c.hash === hash; }) ||
                    _.find(state.controllers, function (c) { return c.hash === state.defaultHash; }); // todo: replace with native methods

            } else if (route) {
                controller = _.find(state.controllers, function(c) { return c.route === route; });
            } else if (name) {
                controller = _.find(state.controllers, function(c) { return utils.getName({ route: c.route }) === name; });
            }

            if (!controller) {
                throw { message: "Can't find controller." };
            }

            return controller;
        },
        setRoute: function(e) {
            e.container.state().route = e.route;
        },
        getName: function(e) {
            var parts = e.route.split("$");
            return parts[parts.length - 1];
        }
    };

    this.getControllerName = function (e) {
        return utils.getName(e);
    };

    // make it memeory only by supplying fromRoute and toRoute
    var getTransitions = function(getTransitionsArgs) {
        var fromRoute = getTransitionsArgs.fromRoute;
        var toRoute = getTransitionsArgs.toRoute;

        if (fromRoute === toRoute) {
            return [];
        }

        var fromNames = fromRoute ? fromRoute.split("$") : [];
        var toNames = toRoute.split("$");

        var transitions = [];

        var i, j = -1;
        var fromName, toName;
        
        // back
        for (i = fromNames.length - 1; i > 0; i--) {

            if (fromNames[i] === toNames[i]) {
                j = i;
                break;
            }

            fromName = fromNames[i];
            toName = fromNames[i - 1];

            transitions.push({ from: fromName, to: toName, direction: "Leave" });
            transitions.push({ from: fromName, to: toName, direction: "Enter" });   
        }

        // and forth
        for (i = i; i < toNames.length - 1; i++) {
            fromName = toNames[i];
            toName = toNames[i + 1];

            if (fromName) {
                transitions.push({ from: fromName, to: toName, direction: "Leave" });
            }

            transitions.push({ from: fromName, to: toName, direction: "Enter" });
        }

        return transitions;
    };

    this.getController = function (e) {
        return utils.getController(e);
    };

    this.navigate = function (navigateArgs) {
        var $container = navigateArgs.container;
        var state = $container.state();
        var toRouteController = utils.getController(navigateArgs);
        var fromRoute = state.route;
        var toRoute = toRouteController.route;
        var context = navigateArgs.context;

        var transitions = getTransitions({ fromRoute: fromRoute, toRoute: toRoute });

        state.predict({ from: utils.getName({ route: fromRoute || "" }), to: utils.getName({ route: toRoute }) });

        var chain = window.Promise.resolve(context);
        
        for (var i = 0; i < transitions.length; i++) {
            var transition = transitions[i];
            var promise;

            if (transition.direction === "Leave") {
                promise = utils.getController({ name: transition.from, container: $container }).leave;
            } else {
                promise = utils.getController({ name: transition.to, container: $container }).enter;
            }

            promise = promise.bind(transition);

            chain = chain.then(promise);
        }

        chain.then(function () {
            location.hash = toRouteController.hash;
            state.route = toRoute;
            
            var success = state.success;
            if (success) {
                success({ from: utils.getName({ route: fromRoute || "" }), to: utils.getName({ route: toRoute }) });
            }
        }).catch(function (e) {
            var error = state.error;
            if (error) {
                error(e);
            }
        });
    };

    this.init = function(initArgs) {
        var $container = initArgs.container;
        var state = $container.state(initArgs);

        var appName = $container.data().appName;
        
        for (var i = 0; i < state.controllers.length; i++) {
            state.controllers[i].appName = appName;
        }

        $(window).on("hashchange", function () {
            var $appContainer = $("#app_container");
            var fromRoute = $appContainer.state().route;
            var toRoute = utils.getController({ container: $appContainer, hash: location.hash }).route;

            if (fromRoute !== toRoute) {
                fxrig.router.navigate({ container: $container, hash: location.hash });
            }
        });

        var hash = state.hash || state.hash;
        fxrig.router.navigate({ container: $container, hash: hash });
    };

    //this.send = function (container, message) {
    //    debugger;

    //    utils.getController({ route: container.state().route, container: container }).on({ name: message.name, value: message.value });
    //};
};