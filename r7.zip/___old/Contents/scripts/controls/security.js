﻿// todo: move non-ui stuff to fxrig.security
var fxrig = fxrig || {};
fxrig.controls = fxrig.controls || {};
fxrig.controls.security = new function() {
    this.authenticate = function(appName) {
        return new window.Promise(function(resolve, reject) {
            try {
                var contributor = fxrig.controls.security.getContributor("fxrig");

                if (!contributor) {
                    var $appOverlay = $("#app_overlay");
                    $appOverlay.empty();

                    var securityHtml = fxrig.state.getCacheItem({ appName: "fxrig", name: "security" });
                    $appOverlay.empty();
                    $appOverlay.html(securityHtml);

                    var $login = $("#login", $appOverlay).hide();
                    var $register = $("#register", $appOverlay).hide();


                    var $loginRegister = $("#login_register", $login);
                    $loginRegister.on("click", function() {
                        $login.add($register).hide();
                        $register.show();
                    });

                    var $registerLogin = $("#register_login", $register);
                    $registerLogin.on("click", function() {
                        $login.add($register).hide();
                        $login.show();
                    });

                    var $loginLogin = $("#login_login", $login);
                    $loginLogin.on("click", function() {
                        var nameOrEmail = $("#login_email").val();
                        var password = $("#login_password").val();

                        var offlineValidation = function() {
                            return new window.Promise(function (resolve, reject) {
                                var errors = [];

                                if (nameOrEmail.length < 1) {
                                    errors.push("Name or Email is manadatory.");
                                }

                                if (password.length < 1) {
                                    errors.push("Password is manadatory.");
                                }

                                if (errors.length === 0) {
                                    resolve();
                                } else {
                                    reject(errors);
                                }
                            });
                        };

                        var onlineValidation = function () {
                            return new window.Promise(function(resolve, reject) {
                                fxrig.services.contributors.get(nameOrEmail, password).then(function (result) {
                                    var contributor = result.data;
                                    if (contributor.Error === 0) {
                                        resolve(contributor);
                                    } else {
                                        reject(["Invalid Credentials."]);
                                    }
                                });
                            });
                        };

                        offlineValidation().then(onlineValidation).then(function (contributor) {
                            fxrig.controls.security.setContibutor(contributor, appName);
                            $appOverlay.hide();

                            resolve(contributor);
                        }).catch(function(errors) {
                            fxrig.utils.ui.renderValidationOutput($("#login_validation_output"), errors);
                        });

                    });

                    var $registerRegister = $("#register_register", $register);
                    $registerRegister.on("click", function() {
                        var contributor = {
                            name: $("#register_name", $register).val(),
                            email: $("#register_email", $register).val(),
                            password: $("#register_password", $register).val()
                        };


                        var offlineValidation = function () {
                            return new window.Promise(function (resolve, reject) {
                                var errors = [];

                                if (contributor.name.length < 1) {
                                    errors.push("Name or Email is manadatory.");
                                }

                                if (contributor.email.length < 1) {
                                    errors.push("Email is manadatory.");
                                }

                                if (contributor.password.length < 1) {
                                    errors.push("Password is manadatory.");
                                }
                                
                                if (errors.length === 0) {
                                    resolve();
                                } else {
                                    reject(errors);
                                }
                            });
                        };

                        var onlineValidation = function () {
                            return new window.Promise(function(resolve, reject) {
                                fxrig.services.contributors.add(contributor).then(function (result) {
                                    var contributor = result.data;
                                    if (contributor.Error === 0) {
                                        resolve(contributor);
                                    } else {
                                        reject(["Name or Email is already in use."]);
                                    }
                                });
                            });
                        };

                        offlineValidation().then(onlineValidation).then(function (contributor) {
                            fxrig.controls.security.setContibutor(contributor, appName);
                            $appOverlay.hide();

                            resolve(contributor);
                        }).catch(function (errors) {
                            fxrig.utils.ui.renderValidationOutput($("#registration_validation_output"), errors);
                        });
                    });

                    var $close = $("#register_close, #login_close", $appOverlay);
                    $close.on("click", function() {
                        $appOverlay.empty();
                        $appOverlay.hide();
                    });

                    $login.show();
                    $appOverlay.show();
                } else {
                    resolve({ contributor: contributor });
                }
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.getContributor = function(appName) {
        return fxrig.state.getAppState(appName).contributor;
    };

    this.setContibutor = function(contributor, appName) {
        var appState = fxrig.state.getAppState(appName);
        appState.contributor = contributor;

        fxrig.state.setAppState(appState, appName);
    };

    // todo: marke session as inactive
    this.logout = function(appName) {
        fxrig.controls.security.setContibutor(null, appName);
    };
};

