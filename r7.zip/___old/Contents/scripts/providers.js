﻿var fxrig = fxrig || {};
fxrig.providers = fxrig.providers || {};

fxrig.providers.get = function (provider) {
    return fxrig.providers[provider.toLocaleLowerCase()];
};

// todo: rename services to providers
fxrig.providers.core = new function () {

    this.fetch = function (fetchArgs) {
        return fxrig.services.core.get(fetchArgs).then(function (data) {
            return window.Promise.resolve({ name: "Core", data: data.data, fetch: fetchArgs });
        });
    }

    this.merge = function (left, right, mode) {
        if (mode === "Force") {
            throw { error: "Not Forcible." };
        }

        var duplicates = 0;
        var added = 0;

        for (var i = 0; i < left.Sets.length; i++) {
            var leftSet = left.Sets[i],rightSet = right.Sets[i];

            for (var j = 0; j < rightSet.Points.length; j++) {
                var leftPoint = leftSet.Points[leftSet.Points.length - 1];
                var rightPoint = rightSet.Points[j];

                if (rightPoint.O > leftPoint.O) {
                    leftSet.Points.push(rightPoint);
                    added++;
                } else {
                    duplicates++;
                }
            }
        }

        return left;
    };

    this.prepare = function (prepareArgs) {
        var data = prepareArgs.data;
        var display = prepareArgs.display;
        var preparedData = { Sets: [] };

        for (var i = 0; i < data.Sets.length; i++) {
            var set = data.Sets[i];
            var range = { min: Number.MAX_VALUE, max: Number.MIN_VALUE };

            var preparedSet = { Name: set.Name, Points: [] };

            for (var j = 0; j < set.Points.length; j++) {
                var point = set.Points[j];

                if (point.O >= display.from && point.O <= display.to) {
                    
                    range.min = Math.min(range.min, point.M);
                    range.max = Math.max(range.max, point.M);

                    preparedSet.Points.push(point);
                }
            }

            preparedSet.Range = range;
            preparedData.Sets.push(preparedSet);
        }

        return preparedData;
    };
};

fxrig.providers.o = new function () {
    this.fetch = function(fetchArgs) {
        return new window.Promise(function (resolve, reject) {
            var data = {};
            resolve({ name: "O", data: data, fetch: fetchArgs });
        });
    }

    this.merge = function (left, right, mode) {
        if (mode === "Force") {
            throw { error: "Not Forcible." };
        }

        return left;
    };

    this.prepare = function (prepareArgs) {
        return prepareArgs.data;
    };
};

fxrig.providers.discussions = new function () {
    this.fetch = function(fetch) {
        return fxrig.services.discussions.get(fetch).then(function (data) {
            return window.Promise.resolve({ name: "Discussions", data: data.data, fetch: fetch });
        });
    };

    // todo: check if we need extra logic
    this.merge = function (existing, newest, mode) {
        return newest;
    };

    this.prepare = function (prepareArgs) {
        var data = prepareArgs.data, display = prepareArgs.display, filter = prepareArgs.filter;
        
        if (!filter) {
            return data; // initial population (just pust stuff into cache)
        } 
        else {
            var filteredData = data.filter(function (dataItem) { return dataItem.DiscussionId === parseInt(filter.discussionId); });
            filteredData.filter = filter;

            return filteredData;
        }
    };
};

fxrig.providers.events = new function () {
    this.fetch = function (fetchArgs) {
        return new window.Promise(function (resolve, reject) {
            var data = {};
            resolve({ name: "Events", data: data, fetch: fetchArgs });
        });
    };

    this.merge = function (left, right, mode) {
        return left;
    };

    this.prepare = function (prepareArgs) {
        return prepareArgs.data;
    };
};

fxrig.providers.contributions = new function () {
    this.fetch = function (fetchArgs) {
        return fxrig.services.contributions.get(fetchArgs).then(function (data) {
            return window.Promise.resolve({ name: "Contributions", data: data.data, fetch: fetchArgs });
        });
    }

    this.merge = function (existing, newest, mode) {
        if (!mode) {
            debugger;
        }

        return newest;
    };

    this.prepare = function (prepareArgs) {
        var data = prepareArgs.data, display = prepareArgs.display, filter = prepareArgs.filter;
        var selection = filter.Selection || display;

        var filteredData = [];
        filteredData.filter = filter;

        for (var i = 0; i < data.length; i++) {
            var item = data[i];

            //  { Range: true, Point: false, FullMatch: false, JustMine: true };
            var filterMatch = (filter.Range && filter.Point) || (!filter.Range && !filter.Point)
                || (filter.Range && item.Type === "R")
                || (filter.Point && item.Type === "P"); // todo: make filter to retunr type thus allowing for the simple match

            if (filterMatch) {
                var hitRate = fxrig.utils.data.getHitRate(selection, { from: item.From, to: item.To });

                if (hitRate > 0) {
                    item.HitRate = hitRate;
                    filteredData.push(item);
                }
            }
        }

        return _.sortBy(filteredData, function(item) { return 100 - item.HitRate; });
    };
};