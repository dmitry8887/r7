﻿r8.providers = {};

r8.providers.quotes = {
  fetch: (request) => {
    window.Promise.resolve(request);
  },
  merge: (data)=> {
  },
  filter: (data) => {
  }
};

r8.providers.bands = {
  fetch: (request) => {
    window.Promise.resolve(request);
  },
  merge: (data) => {
  },
  filter: (data) => {
  }
};