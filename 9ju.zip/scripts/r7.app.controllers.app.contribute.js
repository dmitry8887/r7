﻿r7.app.controllers.app.contribute = new function(dependencies) {
    this.route = "app$app.contribute";
    this.hash = "contribute";
    this.header = "Contribute";

    var cache = dependencies.cache;

    // cool
    var states = {
        chart: {
            enter: function(e) {
                var $view = e.view;

                var $chart = $view.find("#chart");
                var $list = $view.find("#list");

                r7.lib.chart.expand({ container: $chart });
                r7.lib.list.collapse({ container: $list });

                r7.lib.utils.ui.expandAccordion({ container: $view.find("#accordion"), index: 1 });
            }
        },
        list: {
            enter: function(e) {
                var $view = e.view;

                var $chart = $view.find("#chart");
                var $list = $view.find("#list");

                r7.lib.chart.collapse({ container: $chart });
                r7.lib.list.expand({ container: $list });

                r7.lib.utils.ui.expandAccordion({ container: $view.find("#accordion"), index: 2 });
            }
        },
        listItem: {
            enter: function() {

            }
        }
    };

    var init = function(context) {
        return new window.Promise(function (resolve, reject) {

            var $view = $("#view").html(cache.view);

            // $view.find("#names_and_dates").on("click", function() { alert("OK"); });

            var $chart = $view.find("#chart");
            var $list = $view.find("#list");

            // throw "Custom Error";

            resolve(context);
        });
    };

    this.enter = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                console.log("entering contributions...");

                init(context).then(resolve).catch(reject);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                console.log("leaving contributions...");

                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
}({
    cache: {
        view: r7.lib.state.getCasheItem({ name: "app.views.contribute" })
    },
    services: {
        getContributions: function() {
            return [{ text: "A" }, { text: "B" }, { text: "C" }, { text: "D" }, { text: "E" }];
        }
    }
});