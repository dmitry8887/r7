﻿var r7 = r7 || {};
r7.app = r7.app || {};

r7.app.controllers = r7.app.controllers || {};

r7.app.boostrap = function () {

    var ensureState = function() {

    };

    var init= function() {
        r7.lib.router.init({
            container: $("#app"),
            appName: "r7",
            hash: "contribute",
            controllers:
            [
                r7.app.controllers.app,
                r7.app.controllers.app.contribute,
                r7.app.controllers.app.research,
                r7.app.controllers.app.labs
            ]
        });
    }
    
};