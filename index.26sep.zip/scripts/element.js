$ = {
    Symbols: {
        id: Symbol("id"),
        expandos: Symbol("expandos"),
        path: Symbol("path"),
        getParent: Symbol("getParent")
    }
};

$.Element = {};

$.Element.init = ({ element }) => {
    const expandos = element[$.Symbols.expandos];

    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element[$.Symbols.expandos] = Object.entries(element.dataset).reduce((previous, current) => Object.assign(previous, JSON.parse(current[1])), { [$.Symbols.id]: element.id });

    $.Element.getElements({ element }).forEach(element => $.Element.init({ element }));
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.set = ({ element, data }) => {
    const bindings = [];

    $.Element.getElements({ element }).forEach(({ [$.Symbols.expandos]: expandos, [$.Symbols.id]: targetId }) => {
        const { type, binding } = expandos;
        const { get, set } = $.Components[type];
        const { path } = binding;

        let getPathBindings = () => bindings[path];

        if (!getPathBindings()) {
            bindings[path] = [];
            pathBindings = getPathBindings();
        }

        getPathBindings().push({
            targetId,
            get: () => get({ element }),
            set: ({ value }) => set({ element, value })
        });
    });

    const { proxy } = $.Proxy.wrap({
        target: data,
        isScope: ({ path }) => bindings[path] !== undefined,
        handler: ({ isInitial, path, originalPath, originalValue, value, type }) => {

            const binding = bindings[path];
            if (binding) {
                console.error({ isInitial, path, originalPath, originalValue, value, type });

                binding.forEach(({ set }) => set({ value }));
            }
        }
    });

    return proxy;
};

$.Proxy = {};

$.Proxy.unwrap = ({ proxy }) => {
    const target = {};

    if (!proxy) {
        debugger;
    }

    const unwrap = ({ proxy, target }) => {
        if (!proxy) {
            debugger;
        }

        Object.entries(proxy).forEach(([key, value]) => {
            const { isObject, isArray } = $.Object.is(value);
            if (isObject) {
                target[key] = isArray ? [] : {};

                unwrap({ proxy: value, target: target[key] });
            }
            else {
                const ignoreKeys = [self.Symbols.path, self.Symbols.getParent];
                if (!ignoreKeys.includes(key)) {
                    target[key] = value;
                }
            }
        });

    };

    unwrap({ proxy, target });

    return target;
};

$.Proxy.getTargetPath = ({ target, key }) => [target[$.Symbols.path], key].filter(path => path != undefined).join(".");

$.Proxy.wrap = ({ target, handler, isScope, allowDynamicProperties }) => {
    const getScopedHandler = ({ scope }) => ({
        get: (target, key) => {
            let value = target[key];
            const path = $.Proxy.getTargetPath({ target, key });

            if (!value) {
                throw "Not Implemented";
            }

            if ($.Object.is(value).isObject === true) {
                if (isScope({ path })) {
                    scope = target[key];
                }

                return new Proxy(value, getScopedHandler({ scope }));
            } else {
                return value;
            }
        },
        set: (target, key, value) => {
            const originalPath = $.Proxy.getTargetPath({ target, key });
            const path = $.Proxy.getTargetPath({ target: scope });

            if ($.Object.is(value).isObject === true) {
                value = $.Proxy.unwrap({ proxy: value });

                // adopt
                value = Object.assign(value, { [$.Symbols.path]: originalPath, [$.Symbols.getParent]: () => target });
            }

            target[key] = value;

            const { isArray: isScopeArray } = $.Object.is(scope);
            const isElevated = target !== scope;
            const originalValue = value;

            if (isScopeArray) {
                if (isElevated || (!isElevated && key === "length")) {
                    if (isElevated) {
                        const trace = $.Object.trace({ target, scope });
                        value = trace[trace.length - 1];
                    }
                    else {
                        value = scope;
                    }

                    handler({ isInitial: false, path, originalPath, value, originalValue });
                }
            }
            else {
                handler({ isInitial: false, path, originalPath, value, originalValue });
            }

            return true;
        }
    });

    $.Object.getPathValuePairs(target).forEach(({ path, value }) => handler({ isInitial: true, path, value }));

    return { proxy: new Proxy(target, getScopedHandler({ scope: { target, value: target } })), handler };
};

$.Object = {};

$.Object.is = target => {
    const type = typeof target;
    const [isObject, isSymbol, isFunction, isString, isNumber, isArray = isObject && Array.isArray(target)] = ["object", "symbol", "function", "string", "number"].map(typeName => typeName === type);
    const isPrimitive = isString || isNumber;

    return { isObject, isSymbol, isFunction, isString, isNumber, isArray, isPrimitive };
};

$.Object.getPathValuePairs = target => {
    const pathValuePairs = [];

    const process = ({ target }) => {
        Object.entries(target).forEach(([key, value]) => {
            const { isObject } = $.Object.is(value);
            const path = $.Object.getPath({ target, key });

            if (isObject) {
                value = $.Object.import({ target, path, value });
            }

            pathValuePairs.push({ path, value });

            if (isObject) {
                process({ target: value });
            }
        });
    };

    process({ target });

    return pathValuePairs;
};


$.Object.getPath = ({ target, key }) => [target[$.Symbols.path], key].filter(path => path !== undefined).join(".");

$.Object.import = ({ target, key, path = $.Object.getPath({ target, key }), value }) =>
    Object.assign(value, {
        [$.Symbols.path]: path,
        [$.Symbols.getParent]: () => target
    });

$.Object.trace = ({ target, scope }) => {
    const trace = [];

    while (target !== scope) {
        trace.push(target);
        target = target[$.Symbols.getParent]();
    }

    return trace;
}


$.Components = {};

$.Components.List = class {
    static init({ element }) {
    }

    static get({ element }) {
    }

    static set({ element, value }) {
        console.warn("Binding List", { value });
    }
}

$.Interactable = {};