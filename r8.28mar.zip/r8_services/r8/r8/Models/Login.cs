﻿namespace r8.Models
{
  public class Login
  {
    public string UserNameOrEmail { get; set; }
    public string Token { get; set; }
  }
}