﻿fxrig.services = fxrig.services || {};
//fxrig.services.location = "http://localhost:2016/api/";
fxrig.services.location = "http://fxrig.azurewebsites.net/api/";


fxrig.services.core = fxrig.services.core || {};

fxrig.services.core.get = function(request) {
    return new window.Promise(function (resolve, reject) {
        var url = fxrig.services.location + "core/get?names={0}&from={1}&to={2}&timeframe={3}".format(request.names, request.from, request.to, request.timeframe);

        // todo: utils.getJson()?
        $.ajax({
            context: request,
            type: "GET",
            dataType:"JSON",
            url: url,
            complete: function (xhr, status) {
                if (status === "success") {
                    this.data = xhr.responseJSON;
                    //console.error("JSON", xhr.responseJSON);
                    resolve(this);
                } else {
                    reject(this);
                }
            }
        });

    });
};


fxrig.services.discussions = fxrig.services.discussions || {};
fxrig.services.discussions.add = function (post) {
    return new window.Promise(function (resolve, reject) {
        try {
            var url = fxrig.services.location + "posts/add/";
            $.ajax({
                context: {},
                headers: { "Accept": "application/json", "Content-Type": "application/json" },
                type: "POST",
                dataType: "JSON",
                data: JSON.stringify(post),
                url: url,
                complete: function (xhr, status) {

                    console.error("+++Post added.");

                    if (xhr.status === 200
                        || xhr.status === 204) {

                        this.data = xhr.responseJSON;
                        resolve(this);
                    } else {
                        reject(this);
                    }
                }
            });
        }
        catch (error) {
            reject({ error: error });
        }
    });
};

fxrig.services.discussions.get = function (request) {
    return new window.Promise(function (resolve, reject) {
        var url = fxrig.services.location + "posts/get?names={0}&from={1}&to={2}".format(request.names, request.from, request.to);
        
        // todo: utils.getJson()?
        $.ajax({
            context: request,
            type: "GET",
            dataType: "JSON",
            url: url,
            complete: function (xhr, status) {
                if (status === "success") {
                    
                    this.data = xhr.responseJSON;
                    //console.error("JSON", xhr.responseJSON);
                    resolve(this);
                } else {
                    reject(this);
                }
            }
        });

    });
};

fxrig.services.contributions = fxrig.services.contributions || {};
fxrig.services.contributions.add = function (contribution) {
    return new window.Promise(function (resolve, reject) {
        try {
            var url = fxrig.services.location + "contributions/add/";
            $.ajax({
                context: {},
                headers: { "Accept": "application/json", "Content-Type": "application/json" },
                type: "POST",
                dataType: "JSON",
                data: JSON.stringify(contribution),
                url: url,
                complete: function (xhr, status) {
                    
                    if (xhr.status === 200
                        || xhr.status === 204) {

                        this.data = xhr.responseJSON;
                        //console.error("JSON", xhr.responseJSON);
                        resolve(this);
                    } else {
                        reject(this);
                    }
                }
            });
        }
        catch (error) {
            reject({ error: error });
        }
    });
};

fxrig.services.contributions.get = function (fetch) {
    return new window.Promise(function (resolve, reject) {
        try {
            var url = fxrig.services.location + "contributions/get?names={0}&from={1}&to={2}".format(fxrig.utils.data.normilizeNames(fetch.names), fetch.from, fetch.to);
            
            $.ajax({
                context: {},
                type: "GET",
                dataType: "JSON",
                url: url,
                complete: function(xhr, status) {
                    if (status === "success") {
                        this.data = xhr.responseJSON;
                        //console.error("JSON", xhr.responseJSON);
                        resolve(this);
                    } else {
                        reject(this);
                    }
                }
            });
        }
        catch (error) {
            reject({ error: error });
        }
    });
};


fxrig.services.meta = fxrig.services.meta || {};
fxrig.services.meta = new function () {
    this.getNames = function() {
        return [
            { name: "INS1", multiplier: 10000, levels: [25, 50, 100, 250] },
            { name: "INS2", multiplier: 10000, levels: [25, 50, 100, 250] },
            { name: "INS3", multiplier: 10000, levels: [25, 50, 100, 250] },
            { name: "INS4", multiplier: 10000, levels: [25, 50, 100, 250] },
            { name: "INS5", multiplier: 10000, levels: [25, 50, 100, 250] },
            { name: "INS6", multiplier: 10000, levels: [25, 50, 100, 250] },
            { name: "INS7", multiplier: 10000, levels: [25, 50, 100, 250] }
        ];
    };

    this.getVolatilityLevel = function(name, range) {
        var nameSettings = fxrig.services.meta.getNames().find(function (n) { return n.name === name; }); // todo: use map
        var level;

        for (level = 0; level < nameSettings.levels.length; level++) {
            if ((range * nameSettings.multiplier) <= nameSettings.levels[level]) {
                break;
            }
        }

        return level;
    };
};

fxrig.services.apps = fxrig.services.apps || {};
fxrig.services.apps.get = function() {
    return fxrig.utils.load();
};

fxrig.services.contributors = fxrig.services.contributors || {};
fxrig.services.contributors.add = function (contributor) {
    return new window.Promise(function (resolve, reject) {
        try {
            var url = fxrig.services.location + "contributors/add/";
            $.ajax({
                context: {},
                headers: { "Accept": "application/json", "Content-Type": "application/json" },
                type: "POST",
                dataType: "JSON",
                data: JSON.stringify(contributor),
                url: url,
                complete: function (xhr, status) {
                    if (xhr.status === 200
                        || xhr.status === 204) {

                        this.data = xhr.responseJSON;
                        resolve(this);
                    } else {
                        reject(this);
                    }
                }
            });
        }
        catch (error) {
            reject({ error: error });
        }
    });
};

fxrig.services.contributors = fxrig.services.contributors || {};
fxrig.services.contributors.get = function (nameOrEmail, password) {
    return new window.Promise(function (resolve, reject) {
        try {
            var url = fxrig.services.location + "contributors/get?nameOrEmail={0}&Password={1}".format(nameOrEmail, password);

            $.ajax({
                context: {},
                type: "GET",
                dataType: "JSON",
                url: url,
                complete: function (xhr, status) {
                    if (status === "success") {
                        this.data = xhr.responseJSON;
                        resolve(this);
                    } else {
                        reject(this);
                    }
                }
            });
        }
        catch (error) {
            reject({ error: error });
        }
    });
};



