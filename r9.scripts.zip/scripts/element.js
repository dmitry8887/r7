$ = {};
$.Element = {};

$.Element.init = ({ element }) => {
    let expandos = element["expandos"];
    if (expandos) {
        throw `Element with id: '${element.id}' already initialized.`;
    }

    element.expandos = Object.entries(element.dataset).reduce((previous, current) => {
        const [, value, parsedValue = JSON.parse(value)] = current;
        return Object.assign(previous, parsedValue);
    }, {});

    $.Element.getElements({ element }).forEach(element => {
        $.Element.init({ element });
    });
};

$.Element.getById = ({ element = document, id }) => element.querySelector(`#${id}`);

$.Element.getElements = ({ element }) => element.querySelectorAll("[data-element]");

$.Element.setData = ({ data, element }) => {
    const { expandos } = element;
    const bindings = [];
    
    $.Element.getElements({ element }).forEach(element => {
        const { type, binding } = element.expandos;
        const component = $.Element.registry[type]();
        const { path } = binding;

        let pathBindings = binding[path];
        if (!pathBindings) {
            bindings[path] = [];
            pathBindings = bindings[path];
        }

        const id = element.id;
        const { get, set } = component.export({ mode: "Binding" });

        // TODO: de-bounce
        bindings[path].push({
            targetId: id,
            get: () => get({ element }),
            set: ({ value }) => set({ element, value })
        });
    });

    expandos.bindings = bindings;

    names = [];

    const handle = {
        get: (target, key) => {
            names.push(key);

            if (typeof target[key] === "object" && target[key] !== null) {
                return new Proxy(target[key], handle);
            } else {
                return target[key];
            }
        },
        set: (target, key, value, receiver) => {
            names.push(key);
            key = names.join(".");

            target[key] = value;

            const pathBindings = bindings[key];

            (pathBindings || []).forEach(({ set }) => set({ value }));

            console.error(`setting '${key}' to '${JSON.stringify(value)}'`); //trap
            return true;
        }
    };

    const proxy = new Proxy({}, handle);

    const getKvps = ({ object }) => {
        const kvps = [];

        const process = ({ object }) => {
            Object.entries(object).forEach(entry => {
                const [key, value] = entry;
                kvps.push({ key, value });

                if (typeof value === "object") {
                    process({ object: value });
                }
            });
        };

        process({ object });

        return kvps;
    }

    getKvps({ object: data }).forEach(({ key, value }) => proxy[key] = value);
};














































$.Element.registry = { "List": () => $.List };

