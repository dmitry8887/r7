﻿"use strict";

var fxrig = fxrig || {};
fxrig.controllers = fxrig.controllers || {};

fxrig.controllers.app = new function() {
    //this.hash = "";
    this.route = "$app";
    this.root = true; // todo: check if we need it

    var apply = function() {
        var contributor = fxrig.controls.security.getContributor("fxrig");

        var $appLogin = $("#app_login");
        var $appLogout = $("#app_logout");
        var $appContributorName = $("#app_contributor_name");

        $appLogin.add($appLogout).add($appContributorName).hide();

        if (contributor) {
            $appContributorName.show().text(contributor.Name);
            $appLogout.show();
        } else {
            $appLogin.show();
        }
    };

    var self = {
        parts: {
        
        },
        init: function() {
            apply();

            var $menus = $("#contribute_menu_item, #research_menu_item, #labs_menu_item");
            $menus.on("click", function() {
                fxrig.router.navigate({
                    container: $("#app_container"),
                    name: $(this).data().name,
                    context: {}
                }); // todo: $(this).data().name is already available from container
            });

            var $login = $("#app_login");
            $login.on("click", function() {
                fxrig.controls.security.authenticate("fxrig").then(function (contributor) {
                    fxrig.controllers.controller.sendToController(fxrig.controllers.app, { name: "App.Contributor", value: contributor });
                });
            });

            var $logout = $("#app_logout");
            $logout.on("click", function() {
                fxrig.controls.security.logout("fxrig");
                fxrig.controllers.controller.sendToController(fxrig.controllers.app, { name: "App.Contributor" });
            });
        },
        on: function(message) {
            var name = message.name;
            var value = message.value;

            switch (name) {
            case "App.Contributor":
                apply();

                break;
            }
        }
    };

    this.enter = function (context) {
        console.info("entering fxrig.controllers.app");
        
        var that = this;
        return new window.Promise(function (resolve, reject) {
            try {
                if (!that.from) {
                    self.init(context); // todo: use promise?
                }

                resolve(context);
            } catch (e) {
                reject(e);
            } 
        });
    };

    this.leave = function (context) {
        console.info("leaving fxrig.controllers.app");
        
        return fxrig.utils.load({
            container: $("#view_container"),
            url: fxrig.router.getController({ container: $("#app_container"), name: this.to }).url, // is it not back and forth
            context: context
        });
    };

    this.getSelf = function () {
        return self;
    };
};
