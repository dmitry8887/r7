const AppController = ({ application }) => {
    const { Symbols } = Utils;

    const getData = () => alert("getData!");

    return (new class extends Controller {
        constructor() {
            super({
                elements: {
                },
                states: {
                },
                application,
                routes:
                    [
                        {
                            hash: "#me", handle: () => {
                                alert("me!");
                            }
                        }
                    ],
                create: container => {
                    throw "Not Implmeneted";
                },
                root: true
            });
        }

        [Symbols.run]({ handle, options }) {
            const busy = options => this.execute({ batch: { states: [{ descriptor: "Overlay$Enter", value: options }], transient: true } });
            const free = () => this.execute({ batch: { descriptors: ["Overlay$Leave"], transient: true } });

            return new Promise(resolve => {
                busy(options);
                handle().then(result => {
                    free();
                    resolve(result);
                });
            });
        }
    });
}
