﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;
using Dapper;
using r8.Models;
using r8.Services;

namespace r8.Controllers
{
  public class ContributionsController : ApiController
  {
    private static readonly string ConnectionString = ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

    public ContributionsResult Get(string names, int from, int to)
    {
      string token;
      Utils.TryGetAuthorizationToken(Request, out token);

      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        string sql = $@"SELECT contribution.*, 
                        appUser.UserName AS UserName, 
                        DATEDIFF(MINUTE,{{d '1970-01-01'}}, contribution.CreatedDate) AS CreatedDateMinutes,
                        (SELECT COUNT(1) FROM dbo.[Post] WHERE ExternalId = contribution.[Id]) AS PostCount, 
                        (SELECT COUNT(1) FROM dbo.[Reaction] WHERE TargetId = contribution.[Id] AND ReactionType = 'L' AND TargetType = 'C') AS LikeCount,
                        (CASE WHEN contribution.[TypeId] = 1 THEN 'Range' ELSE 'Point' END) AS [Type],
                        (CASE WHEN appUserSession.[Token] = '{token}' THEN 1 ELSE 0 END) AS Mine
                        FROM dbo.[Contribution] contribution WITH(NOLOCK) 
                          LEFT JOIN dbo.[AppUser] appUser WITH(NOLOCK) ON contribution.[UserId] = appUser.[Id]
                          LEFT JOIN dbo.[AppUserSession] appUserSession WITH(NOLOCK) ON appUserSession.[AppUserId] = appUser.[Id]
                        WHERE (SELECT MAX(FromValues) FROM (values (contribution.[From]), ({from})) AS value(FromValues)) <= 
                          (SELECT min(ToValues) FROM (values (contribution.[To]), ({to})) AS value(ToValues))";

        var contributions = connection.Query<Contribution>(sql).ToList();
        var result = new ContributionsResult();

        result.AddRange(contributions);

        connection.Close();

        return result;
      }
    }

    public Contribution Post(Contribution contribution)
    {
      string token;
      Utils.TryGetAuthorizationToken(Request, out token);

      using (SqlConnection connection = new SqlConnection(ConnectionString))
      {
        connection.Open();

        if (!string.IsNullOrEmpty(token))
        {
          int appUserId;
          if (UserServices.TryGetAppUserId(token, connection, out appUserId))
          {
            contribution.UserId = appUserId;
          }
          else
          {
            throw new HttpException("Invalid Token.");
          }
        }

        contribution.TypeId = contribution.Type == "Range" ? 1 : 2;
        contribution.Direction = contribution.Direction == "Buy" ? "B" : "S";
        contribution.CreatedDate = DateTime.UtcNow;
        contribution.Ip = Utils.GetCallerIp();

        contribution.CloseMode = contribution.CloseMode.Substring(0, 1);

        contribution.Id = connection.Query<int>(
          Utils.GenerateInsertSql("dbo.[Contribution]",
            new[]
            {
              "TypeId", "Names", "From", "To", "UserId", "Tags", "Comment", "Direction", "RiskEstimate", "Open", "StopLoss", "TakeProfit",
              "Volume", "VolumeEstimate", "Close", "CloseMode", "Leverage", "LeverageEstimate", "CreatedDate", "Ip"
            }), contribution.Sanitize()).Single();

        connection.Close();
      }

      return contribution;
    }
  }
}