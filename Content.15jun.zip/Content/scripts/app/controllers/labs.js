﻿"use strict";

const LabsController = class extends simple.Controller {
  constructor({ context }) {
    super({
      name: "Labs",
      routes:
        [
          {
            hash: "#labs",
            handle: function () {
              debugger;
              return Promise.resolve();
            }
          }
        ],
      context
    });
  }

  create({ app }) {
    const container = simple.Dom.getElement({ container: app, dataAttributeName: "data-app-view-placeholder" });
    simple.Dom.setInnerHtml({ container, name: this.name });

    debugger;
    return { container: container.children[0] };
  }

  init() {

  }
};