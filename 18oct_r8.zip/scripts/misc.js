self.Element = {};

    self.Element.expandEvents = events => events.split(" ").map(event => ({ dragStart: "mousedown touchstart", drag: "mousemove touchmove", dragStop: "mouseup touchend" })[event] || event).join(" ");

    self.Element.addEventsHandler = ({ element, events, handleCommands = false, handler, alias }) => {
        const expandos = element[self.Symbols.expandos];
        const internalHandler = event => {

            if (handleCommands === true) {
                const path = event.composedPath();
                for (let i = 0; i < path.length; i++) {

                    const dataset = path[i].dataset;
                    if (dataset && dataset.commandRoot === "true") {
                        console.warn(`Command root, element id: '${element.id}', events: ${events}, path_length: ${path.length} - travelled: ${i}`);
                        break;
                    }
                    else {

                    }
                }
                /*
                
                const getCommandArguments = event => {
                    
                    for (let i = 0; i < path.length; i++) {
                        const dataset = path[i].dataset;
                        if (dataset && dataset.elementCommandRoot === "true") {
                                console.warn(
                                    `Hit command root, element id: '${element.id}', events: ${events}, path_length: ${path.length
                                    } - travelled: ${i}`);
                                return null;
                            }
        
                            const command = dataset.command;
                            if (command) {
                                return JSON.parse(command);
                            }
                        }
                    }
        
                    console.warn(`Gone all way up found nothing, element id: '${element.id}', events: ${events}, path_length: ${path.length}`);
                    return null;
                }
                
                */

                handle({ event, parameters: getCommandArguments({ event }) });
            } else {
                handle({ event });
            }
        };

        events.split(" ").forEach(event => {
            const eventKey = alias ? `${event}.${alias}` : event;

            if (expandos.eventHandlers[eventKey]) {
                throw `Duplicate event handle for element id: '${element.id}', event: ${eventKey}`;
            }

            expandos.eventHandlers[eventKey] = internalHandler;
            element.addEventListener(event, internalHandler, false);

            return () => {
                expandos.eventHandles[eventKey] = null;
                element.removeEventListener(event, internalHandle, false);
            };
        });
    };

    self.Element.removeEventsHandler = ({ element, events }) => {
        events = simple.Element.translateEvents({ events });
		const expandos = element.expandos;
		
		events.split(" ").forEach(event => {
			event = alias ? `${event}.${alias}` : event;

			const handled = expandos.eventHandles[event] === true;
			if (!handled) {
				throw `Event '${event}' cannot be removed for element id: '${element.id}'`;
			}

			element.removeEventListener(event, handle);
			expandos.eventHandles[eventKey] = null; // TODO: use WeakMap
		});
    };

    self.Element.init = ({ element, elements = {}, states = {}, commands = {} }) => {
        element[self.Symbols.expandos] = Object.values(element.dataset).reduce((previuosValue, currentValue) => {
            previuosValue = Object.assign(previuosValue, JSON.parse(currentValue));
            return previuosValue;
        }, {});

        element[self.Symbols.elements] = Object.values(elements).forEach(element => {
            const { init } = element;
            if (init) {
                element.init = init.bind(this);
            }
        });

        element[self.Symbols.states] = Object.values(states).forEach(state => {
            const { enter, leave } = state;
            if (enter) {
                state.enter = enter.bind(this);
            }
            if (leave) {
                state.leave = leave.bind(this);
            }
        });

        element[self.Symbols.commands] = Object.values(commands).forEach(command => {
            const { execute } = command;
            if (!execute) {
                debugger;
            }

            command.execute = execute.bind(this);
            this[key] = command.execute; // TODO: review
        });
    };
