﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using BookKeeper.Annotations;
using BookKeeper.Commands;
using BookKeeper.Services;

namespace BookKeeper.ViewModels
{
    public sealed class ExpenseSummaryViewModel : INotifyPropertyChanged
    {
        public ExpenseSummaryViewModel(AppViewModel expenseApp)
        {
            App = expenseApp;

            Months = Enumerable.Range(1, 12)
                .ToDictionary(key => key,
                    value => new DateTime(1, value, 1)
                        .ToString(AppViewModel.MonthFormat, CultureInfo.InvariantCulture));

            Years = Enumerable.Range(DateTime.Today.Year - 10, 21)
                .ToDictionary(key => key,
                    value => value.ToString());

            FromMonth = DateTime.Today.Month;
            FromYear = DateTime.Today.Year;

            DateTime nextMonth = DateTime.Today.AddMonths(1);

            ToMonth = nextMonth.Month;
            ToYear = nextMonth.Year;
            
            RefineCommand = new RelayCommand(Refine);
        }

        // ReSharper disable once MemberCanBePrivate.Global
        public AppViewModel App
        {
            get;
        }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public Dictionary<int, string> Months { get; set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public Dictionary<int, string> Years { get; set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Global
        public int FromMonth { get; set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Global
        public int FromYear { get; set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Global
        public int ToMonth { get; set; }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once AutoPropertyCanBeMadeGetOnly.Global
        public int ToYear { get; set; }
        
        private List<ExpenseViewModel> _expense;
        // ReSharper disable once MemberCanBePrivate.Global
        public List<ExpenseViewModel> Expenses
        {
            // ReSharper disable once UnusedMember.Global
            get { return _expense; }
            set
            {
                _expense = value;
                // ReSharper disable once ExplicitCallerInfoArgument
                OnPropertyChanged(nameof(Expenses));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        
        internal void Refine()
        {
            DateTime fromDate = new DateTime(FromYear, FromMonth, 1);
            DateTime toDate = new DateTime(ToYear, ToMonth, 1).AddMonths(1).AddDays(-1);

            var expenses = new DbService().GetExpenses(fromDate, toDate).Select(t => new ExpenseViewModel(App, t)).ToList();

            Dictionary<string, decimal> totals = new Dictionary<string, decimal>();

            foreach (var expense in expenses)
            {
                if (expense.Date != null)
                    expense.GroupDescription = $"{expense.CategoryName}${expense.Date.Value:MMM yyyy}";

                if (!totals.ContainsKey(expense.GroupDescription))
                {
                    totals.Add(expense.GroupDescription, 0);
                }

                totals[expense.GroupDescription] = totals[expense.GroupDescription] + expense.Amount;
            }

            foreach (var expense in expenses)
            {
                expense.GroupDescription = expense.GroupDescription + "$" + totals[expense.GroupDescription];
            }

            Expenses = expenses;
        }

        // ReSharper disable once MemberCanBePrivate.Global
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        public ICommand RefineCommand { get; set; }
    }
}
