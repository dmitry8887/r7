﻿"use strict";

var r7 = r7 || {};
r7.core = r7.core || {};
