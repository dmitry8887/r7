﻿using System;
using System.Collections.Generic;
using BookKeeper.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BookKeeper.Services
{
    // TODO: extract the interface so it can be mocked
    public class DbService
    {
        private string GetConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["Db"].ConnectionString.Replace("{bin}", AppDomain.CurrentDomain.BaseDirectory);
        }

        private void ApplyParameters(SqlCommand command,
             List<Tuple<string, DbType, object>> parameters)
        {
            foreach (var parameter in parameters)
            {
                command.Parameters.AddWithValue(parameter.Item1, parameter.Item3).DbType = parameter.Item2;
            }
        }

        private List<T> GetData<T>(string storedProcedureName,
            Func<IDataReader, T> dataReaderCreator,
            List<Tuple<string, DbType, object>> parameters = null)
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection.Open();

                    if (parameters != null)
                    {
                        ApplyParameters(command, parameters);
                    }

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        List<T> data = new List<T>();

                        while (reader.Read())
                        {
                            data.Add(dataReaderCreator(reader));
                        }

                        return data;
                    }
                }
            }
        }

        private void AddDataItem(string storedProcedureName,
             List<Tuple<string, DbType, object>> parameters)
        {
            using (SqlConnection connection = new SqlConnection(GetConnectionString()))
            {
                using (SqlCommand command = new SqlCommand(storedProcedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Connection.Open();

                    ApplyParameters(command, parameters);

                    command.ExecuteNonQuery();
                }
            }
        }

        public List<Expense> GetExpenses(DateTime dateFrom, DateTime dateTo)
        {
            return GetData("Expense_GetList", Expense.DataReaderCreator, new List<Tuple<string, DbType, object>>()
            {
                new Tuple<string, DbType, object>("@DateFrom", DbType.DateTime, dateFrom),
                new Tuple<string, DbType, object>("DateTo", DbType.DateTime, dateTo)
            });
        }

        public List<ExpenseCategory> GetExpenseCategories()
        {
            return GetData("ExpenseCategory_GetList", ExpenseCategory.DataReaderCreator);
        }

        public void AddExpense(Expense expense)
        {
            AddDataItem("Expense_Add", new List<Tuple<string, DbType, object>>()
            {
                new Tuple<string, DbType, object>("UserId", DbType.Int32, expense.UserId),
                new Tuple<string, DbType, object>("Date", DbType.DateTime, expense.Date),
                new Tuple<string, DbType, object>("CategoryId", DbType.Int32, expense.CategoryId),
                new Tuple<string, DbType, object>("Amount", DbType.Decimal, expense.Amount)
            });
        }
    }
}
