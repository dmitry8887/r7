﻿using r8.Models;
using r8.Services;
using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Http;

namespace r8.Controllers
{
    public class UserActivitiesController : ApiController
    {
        private static readonly string ConnectionString =
            ConfigurationManager.ConnectionStrings["DbConnectionString"].ConnectionString;

        public UserActivitiesResult Get()
        {
            string token;
            Utils.TryGetAuthorizationToken(Request, out token);

            if (!string.IsNullOrEmpty(token))
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    int appUserId;
                    if (UserServices.TryGetAppUserId(token, connection, out appUserId))
                    {
                        return new UserActivitiesResult()
                        {
                            LikesGiven = 100,
                            LikesReceived = 50,
                            CreatedDate = DateTime.Now
                        };
                    }
                    else
                    {
                        // TODO: throw & log
                        throw new Exception("Invalid Token.");
                    }

                }
            }
            else
            {
                throw new InvalidOperationException("Invalid Opration.");
            }
        }
    }
}