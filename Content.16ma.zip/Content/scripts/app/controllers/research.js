﻿"use strict";

r8.controllers.Research = class extends simple.Component {
  constructor({ resolver }) {
    super({
      resolver,
      init: ({ appContainer }) => {
        appContainer.querySelector("#app_view_container").innerHTML =
          simple.Utils.getHtmlImportText({ name: "Research" });

        return appContainer.querySelector("#research");
      },
      elements: {},
      states: []
    });
  }

  enter() {
    if (!this.initialized) {
      this.init();
    }
  }

  leave() {
    super.detach();
  }
}