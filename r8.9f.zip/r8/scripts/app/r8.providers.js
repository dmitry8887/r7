﻿r8.providers = {};

r8.providers.quotes = {
  name: "Quotes",
  fetch: (request) => r8.services.quotes.get(request).then(data => ({ data, provider: r8.providers.quotes })),
  merge: ({ container, data }) => {
    let existingData = container.expandos.data[r8.providers.quotes.name];

    if (existingData){
      //existingData = existingData.map((seria, index) => [seria, ...data[index]]);
    }
    else{
      container.expandos.data[r8.providers.quotes.name] = data;
    }
  },
  filter: ({ container, request }) => {
    const data = container.expandos.data[r8.providers.quotes.name];
    const { from, to } = request;
    
    const filteredData = data.map(seria => seria.points.filter(point => {
      //seria.minM = Math.min(seria.minM || Number.POSITIVE_INFINITY, point.m);
      //seria.maxM = Math.max(seria.maxM || Number.NEGATIVE_INFINITY, point.m);
      return point.o >= from && point.o <= to;
    })); 

    //filteredData.forEach((seria, index) => {
    //  seria.min = data[index].min;
    //  seria.max = data[index].max;
    //});

    filteredData.x = { min:request.from, max:request.to, step: request.frame };

    return filteredData;
  }
};
