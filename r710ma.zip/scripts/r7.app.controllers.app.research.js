﻿r7.app.controllers.app.research = new function (dependencies) {
    this.route = "app$app.research";
    this.hash = "research";

    this.header = "Research";

    var cache = dependencies.cache;

    this.enter = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                $("#view").html(cache.view);
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
}({
    cache: {
        view: r7.lib.state.getCasheItem({ name: "app.views.research" })
    }
});