﻿"use strict";

const ContributeController = class extends simple.Controller {
  constructor({ appContext }) {
    super({
      elements: {
        Contribute: { id: "contribute" },
        DateRange: {
          id: "date_range", init: ({ element }) => simple.DateRange.init({
            element, on: ({ name, descriptor }) => {
              if (name === "Activate") {
                const { from, to, hasToDate } = simple.DateRange.getOptions({ element: this.getElement({ name: "DateRange" }) });
                this.execute({ batch: { states: [{ descriptor: "DatesEditor$Enter", value: { descriptor, from, to, hasToDate } }] } });
              }
            }
          })
        },
        Names: {
          id: "names", init: ({ element }) => simple.List.init({
            element, getItems: r8.metadata.names,
            formatter: this.appContext.getController({ name: "App" }).export().formatter,
            on: ({ ids, selectedIds, name }) => {

              switch (name) {
                case "Change":
                case "Select":

                  // this.Update({stateL });

                  const request =
                    simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { names: simple.List.selectedIds.build({ ids, selectedId: selectedIds[0] }) }) });

                  if (name === "Change") {
                    this.UpdateData({ request });
                    this.load();
                  }
                  else {
                    const selectedName = selectedIds[0];
                    simple.Chart.setData({ element: this.getElement({ name: "Chart" }), selectedName });
                  }

                  break;
              }
            }
          })
        },
        Tags: {
          id: "tags",
          init: ({ element }) => simple.List.init({
            getItems: r8.metadata.tags, element, on: ({ ids, name }) => {
              switch (name) {
                case "Change":
                  simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { tags: ids }) });
                  this.request({ force: true });
                  this.load();
                  break;
                default:
                  throw `Invalid Event:${name}`;
              }
            }
          })
        },
        NamesEditorLauncher: { id: "names_editor_launcher" },
        NamesEditor: {
          id: "names_editor", init: ({ element }) => {
            simple.Picker.init({
              element, filter: { categories: r8.metadata.nameCategories(), handle: r8.metadata.match }, on: ({ selectedIds }) => {
                simple.Storage.setValue({ path: "r8.contribute", mutator: (value) => Object.assign(value, { names: simple.List.selectedIds.update({ ids: value.names, newIds: selectedIds }) }) });
                this.UpdateData();
                simple.App.apply();
              }
            });
          }
        },
        TagsEditorLauncher: { id: "tags_editor_launcher" },
        TagsEditor: {
          id: "tags_editor",
          init: ({ element }) => {
            simple.Picker.init({
              element, filter: { categories: r8.metadata.tagCategories(), handle: r8.metadata.match }, on: ({ selectedIds }) => {
                simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { tags: selectedIds }) });
                this.request({ force: true });
                this.load();
                simple.App.apply();
              }
            });
          }
        },
        Chart: {
          id: "chart", init: ({ element }) =>
            simple.Chart.init({
              element,
              formatter: this.appContext.getController({ name: "App" }).export().formatter,
              bands: [r8.bands.weekDays],
              on: ({ name, value, dX }) => {
                const { from, to } = value || {};

                const requestCache = {
                  get: () => element.expandos.request,
                  set: ({ request }) => element.expandos.request = request
                };

                const getRequest = () => Object.assign(requestCache.get(), { from, to });

                // TODO: pass state from outside
                const updateState = () => {
                  simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { from, to }) });
                  this.LoadState();
                };

                switch (name) {
                  case "DragStart":
                    requestCache.set({ request: this.GetState(), force: false });
                    break;
                  default:
                    switch (name) {
                      case "Drag":
                        this.UpdateData({ request: getRequest(), providers: [r8.QuotesProvider, r8.ContributionsProvider], force: false });
                        break;
                      case "DragStop":
                        if (dX !== 0) {
                          updateState();
                        }

                        break;
                    }

                    break;
                }
              }
            })
        },
        Contributions: {
          id: "contributions",
          init: ({ element }) => {
            simple.List.init({
              element, template: ({ item, mode }) => {
                return simple.Dom.evalTemplate({
                  name: {
                    "Range.Render": "Contribute.ContributionRangeRender",
                    "Range.Export": "Contribute.ContributionRangeExport",
                    "Point.Render": "Contribute.ContributionPointRender",
                    "Point.Export": "Contribute.ContributionPointExport"
                  }[`${item.type}.${mode}`],
                  context: { item }
                });
              },
              emptyText: "No Contributions.", commands:
                [
                  {
                    name: "Like",
                    execute: () => { }
                  }, // like
                  {
                    name: "Discuss",
                    execute: ({ id }) => simple.App.navigate({ hash: `contribute/contributions/discuss/${id}` })
                  },
                  {
                    name: "Share",
                    execute: () => {

                    }
                  }
                ]
            });
          }
        },
        ContributionsFilter: {
          id: "contributions_filter",
          init: ({ element }) =>
            simple.CheckboxList.init({
              element, items: r8.metadata.contributionsFilterCategories(), on: ({ value }) => simple.List.filter({
                element: this.getElement({ name: "Contributions" }),
                filter: ({ item }) => value.length === 0 || value.length === 2 || value.includes(item.type)
              })
            })
        },
        ContributionsLauncher: { id: "contributions_launcher" },
        DataLauncher: { id: "data_launcher" },
        ContributionsSummary: { id: "contributions_summary" },
        ContributionsPanel: { id: "contributions_panel" },
        DatesEditor: { id: "dates_editor" },
        DatesEditorSlider: {
          id: "dates_editor_slider",
          init: ({ element }) => simple.Slider.init({ element })
        },
        DatesEditorDateRange: {
          id: "dates_editor_date_range",
          init: ({ element }) => simple.DateRange.init({ element, getSlider: () => this.getElement({ name: "DatesEditorSlider" }) })
        },
        DatesEditorApply: { id: "dates_editor_apply" },
        DataPadding: { id: "data_padding" },
        DataZoom: { id: "data_zoom" },
        ContributionCreate: { id: "contribution_create" },
        ContributionEditorApply: { id: "contribution_editor_apply" },
        Contribution: { id: "contribution" },
        ContributionValidationSummary: { id: "contribution_validation_summary" },
        ContributionNames: { id: "contribution_names", init: ({ element }) => simple.List.init({ element, getItems: r8.metadata.names }) },
        ContributionTags: { id: "contribution_tags", init: ({ element }) => simple.List.init({ element, getItems: r8.metadata.tags }) },
        ContributionNamesEditor: {
          id: "contribution_names_editor",
          init: ({ element }) => {
            simple.Picker.init({
              element, filter: { categories: r8.metadata.nameCategories(), handle: r8.metadata.match },
              on: ({ name, selectedIds }) => {
                const items = r8.metadata.names().filter(name => selectedIds.includes(name.id));
                switch (name) {
                  case "Change":
                    simple.List.setItems({ element: this.getElement({ name: "ContributionNames" }), items, selectedIds });
                    simple.App.apply();
                    break;
                }
              }
            });
          }
        },
        ContributionTagsEditor: {
          id: "contribution_tags_editor",
          init: ({ element }) => {
            simple.Picker.init({
              element, filter: { categories: r8.metadata.tagCategories(), handle: r8.metadata.match },
              on: ({ name, selectedIds }) => {
                const items = r8.metadata.tags().filter(name => selectedIds.includes(name.id));
                switch (name) {
                  case "Change":
                    simple.List.setItems({ element: this.getElement({ name: "ContributionTags" }), items, selectedIds });
                    simple.App.apply();
                    break;
                }
              }
            });
          }
        },
        ContributionNamesEditorLauncher: { id: "contribution_names_editor_launcher" },
        ContributionTagsEditorLauncher: { id: "contribution_tags_editor_launcher" },
        ContributionOverlay: { id: "contribution_overlay" },
        ContributionDateRange: {
          id: "contribution_date_range",
          init: () => {
            simple.DateRange.init({
              element: this.getElement({ name: "ContributionDateRange" }), on: ({ name, descriptor }) => {
                if (name === "Activate") {
                  const { from, to, hasToDate } = simple.DateRange.getOptions({ element: this.getElement({ name: "ContributionDateRange" }) });
                  this.execute({ batch: { states: [{ descriptor: "ContributionDatesEditor$Enter", value: { descriptor, from, to, hasToDate } }] } });
                }
              }
            });
          }
        },
        ContributionDatesEditorDateRange: {
          id: "contribution_dates_editor_date_range",
          init: ({ element }) => simple.DateRange.init({ element, getSlider: () => this.getElement({ name: "ContributionDatesEditorSlider" }) })
        },
        ContributionDatesEditor: { id: "contribution_dates_editor" },
        ContributionDatesEditorSlider: { id: "contribution_dates_editor_slider", init: ({ element }) => simple.Slider.init({ element }) },
        ContributionType: {
          id: "contribution_type",
          init: ({ element }) => {
            simple.RadioList.init({
              element, items: r8.metadata.contributionTypes(), selectedId: "Range", on: ({ name, id }) => {
                switch (name) {
                  case "Select":
                    const descriptor = { Range: "ContributionRange$Enter", Point: "ContributionPoint$Enter" }[id];
                    if (!descriptor) {
                      throw `Invalid Contribution Type: '${id}'`;
                    }
                    this.execute({ batch: { descriptors: [descriptor], transient: true } });
                    break;
                  default:
                    throw `Invalid Command: '${name}'`;
                }
              }
            });
          }
        },
        ContributionPointDirection: {
          id: "contribution_point_direction",
          init: ({ element }) => simple.RadioList.init({ element, items: r8.metadata.contributionPointDirections(), selectedId: "Buy" })
        },
        ContributionPoint: { id: "contribution_point" },
        ContributionPointCloseMode: {
          id: "contribution_point_close_mode",
          init: ({ element }) => simple.RadioList.init({ element, items: r8.metadata.contributionPointCloseModes(), selectedId: "Manual" })
        },
        ContributionPointRiskEstimate: {
          id: "contribution_point_risk_estimate",
          init: ({ element }) => simple.Spinner.init({ element, items: r8.metadata.estimates() })
        },
        ContributionPointVolumeEstimate: {
          id: "contribution_point_volume_estimate",
          init: ({ element }) => simple.Spinner.init({ element, items: r8.metadata.estimates() })
        },
        ContributionPointLeverageEstimate: {
          id: "contribution_point_leverage_estimate",
          init: ({ element }) => simple.Spinner.init({ element, items: r8.metadata.estimates() })
        },
        ContributionPointAddCloseButton: { id: "contribution_point_add_close_button" },
        ContributionPointRemoveCloseButton: { id: "contribution_point_remove_close_button" },
        ContributionPointCloseRow: { id: "contribution_point_close_row" },
        ContributionPointMoreButton: { id: "contribution_point_more_button" },
        ContributionPointLessButton: { id: "contribution_point_less_button" },
        ContributionPointVolumeRow: { id: "contribution_point_volume_row" },
        ContributionPointLeverageRow: { id: "contribution_point_leverage_row" },
        ContributionPointOpenLower: { id: "contribution_point_open_lower" },
        ContributionPointOpenHigher: { id: "contribution_point_open_higher" },
        ContributionDatesEditorApply: { id: "contribution_dates_editor_apply" },
        DiscussionOverlay: { id: "discussion_overlay" },
        DiscussionContext: { id: "discussion_context" },
        Discussion: {
          id: "discussion", init: ({ element, appContext }) => {
            simple.Discussion.init({
              element, appContext, template: ({ item, mode }) => {
                const name = {
                  "Post.Render": "Contribute.DiscussionPostRender",
                  "Post.Export": "Contribute.DiscussionPostExport"
                }[`Post.${mode}`];

                return simple.Dom.evalTemplate({ name, context: { item } });
              },
              commands: [{ name: "Like", execute: () => { } }],
              on: ({ name: mode, value: post }) => {
                let { authenticate, run } = this.appContext.getController({ name: "App" }).export();

                authenticate({ allowGuestLogin: true }).then(() => {
                  const action = ({ post }) => r8.services.posts[mode.toLowerCase()](post);
                  const reget = () => this.request({ providers: [r8.PostsProvider], force: true, request: { externalId: post.externalId } });
                  const close = () => simple.App.apply();

                  run({
                    handle: () => action({ post }).then(reget).then(close),
                    options: { text: "Getting Posts..." }
                  });
                });
              }
            });
          }
        },
        Bar: { id: "bar" },
        ContributionBar: { id: "contributions_bar" }
      },
      states: {
        Contributions: {
          group: "Main",
        },
        Chart: {
          group: "Main"
        },
        Discussions: {
          group: "Main"
        },
        NamesEditor: {
          group: "Editors",
          enter: () => simple.Picker.setItems({
            element: this.getElement({ name: "NamesEditor" }), items: r8.metadata.names(),
            selectedIds: simple.List.selectedIds.parse({ ids: this.GetState().names }).ids
          })
        },
        TagsEditor: {
          group: "Editors",
          enter: () => simple.Picker.setItems({
            element: this.getElement({ name: "TagsEditor" }), items: r8.metadata.tags(), selectedIds: simple.Storage.getValue({ path: "r8.contribute" }).tags
          })
        },
        DatesEditor: {
          enter: ({ value }) => {
            const { descriptor, from, to, hasToDate } = value; // TODO: use input
            simple.DateRange.setOptions({ element: this.getElement({ name: "DatesEditorDateRange" }), descriptor, from, to, hasToDate });
          },
          leave: () => simple.DateRange.deactivate({ element: this.getElement({ name: "DateRange" }) })
        },
        Contribution: {
          enter: ({ value }) => {
            const { names, tags } = simple.Storage.getValue({ path: "r8.contribute" });

            const { contribution = {
              names: simple.List.selectedIds.parse({ ids: names }).ids, tags, type: "Range", direction: "Sell",
              range: simple.Chart.getSelectedRange({ element: this.getElement({ name: "Chart" }) }),
            }, mode } = value;

            simple.Screen.set({ element: this.getElement({ name: "Contribution" }), object: contribution, mode });

            const descriptors = [];

            const hasClose = !isNaN(contribution.close) && contribution.type === "Point";
            if (hasClose) {
              descriptors.push("ContributionPointHasClose$Enter");
            }

            const more = contribution.type === "Point"; // TODO: fix
            if (more) {
              descriptors.push("ContributionPointMore$Enter");
            }

            if (descriptors.length > 0) {
              this.execute({ batch: { descriptors } });
            }
          }
        },
        ContributionRange: {
          group: "ContributionType",
          enter: function () {
            this.execute({ batch: { descriptors: ["ContributionHasToDate$Enter"], transient: true } });
            simple.RadioList.setSelectedId({ element: this.getElement({ name: "ContributionType" }), id: "Range" });
          },
          reEntryAction: "Ignore"
        },
        ContributionPoint: {
          group: "ContributionType",
          enter: () => this.execute({ batch: { descriptors: ["ContributionPointMore$Leave", "ContributionPointHasClose$Leave"], transient: true } }),
        },
        ContributionPointHasClose: {
          enter: () => simple.DateRange.setHasToDate({ element: this.getElement({ name: "ContributionDateRange" }), hasToDate: true }),
          leave: () => simple.DateRange.setHasToDate({ element: this.getElement({ name: "ContributionDateRange" }), hasToDate: false })
        },
        ContributionDatesEditor: {
          enter: ({ value }) => {
            const { descriptor } = value;
            const { from, to, hasToDate } = simple.DateRange.getOptions({ element: this.getElement({ name: "ContributionDateRange" }) });
            simple.DateRange.setOptions({ element: this.getElement({ name: "ContributionDatesEditorDateRange" }), descriptor, hasToDate, from, to });
          },
          leave: () => simple.DateRange.deactivate({ element: this.getElement({ name: "ContributionDateRange" }) })
        },
        ContributionNamesEditor: {
          group: "ContributionEditors",
          enter: () => simple.Picker.setItems({
            element: this.getElement({ name: "ContributionNamesEditor" }),
            items: r8.metadata.names(), selectedIds: simple.List.getSelectedIds({ element: this.getElement({ name: "ContributionNames" }) })
          })
        },
        ContributionTagsEditor: {
          group: "ContributionEditors",
          enter: () => simple.Picker.setItems({
            element: this.getElement({ name: "ContributionTagsEditor" }),
            items: r8.metadata.tags(), selectedIds: simple.List.getSelectedIds({ element: this.getElement({ name: "ContributionTags" }) })
          })
        }
      },
      commands: {
        // TODO: check why do we need it
        GetState: {
          execute: () => simple.Storage.getValue({ path: "r8.contribute", defaultValue: r8.services.app.getDefaultState() })
        },
        SetState: {
          execute: ({ value }) => simple.Storage.setValue({ path: "r8.contribute", mutator: state => Object.assign(state, value) })
        },
        // TODO: do it via on();
        Like: {
          execute: ({ originator, id }) => {
            debugger;

            let elementId;
            let elements;
            let targetType;

            switch (originator) {
              case "Contribution":
                elements = ["Contributions"].map(name => this.getElement({ name }));
                elementId = `contribution_like_count_${id}`;
                targetType = "Contribution";
                break;
              case "ContributionExport":
                elements = ["DiscussionContext", "Contributions"].map(name => this.getElement({ name }));
                elementId = `contribution_like_count_${id}`;
                targetType = "Contribution";
                break;
              case "Post":
                elements = [simple.Discussion.getPostList({ element: this.getElement({ name: "Discussion" }) })];
                elementId = `post_like_count_${id}`;
                targetType = "Post";
                break;
              case "PostExport":
                elements = [
                  simple.Discussion.getPostList({ element: this.getElement({ name: "Discussion" }) }),
                  simple.Discussion.getParentPost({ element: this.getElement({ name: "Discussion" }) })
                ];

                elementId = `post_like_count_${id}`;
                targetType = "Post";

                break;
            }

            const update = ({ count }) => {
              elements.forEach(element => {
                const items = element.expandos.items;
                if (items) {
                  const item = items.find(item => item.id === id);
                  if (item) {
                    item.likeCount = count;
                  }
                }

                simple.Dom.getById({ element, id: elementId }).innerHTML = count;
              });
            };

            const { authenticate } = this.appContext.getController({ name: "App" }).export();
            authenticate({ allowGuestLogin: false }).then(r8.services.reactions.add({ targetId: id, targetType, reactionType: "Like" }).then(update));
          }
        },
        Share: {
          execute: () => { }
        },
        ContributionDatesEditorApply: {
          execute: () => {
            const { from, to, hasToDate } = simple.DateRange.getOptions({ element: this.getElement({ name: "ContributionDatesEditorDateRange" }) }); // TODO: use input

            // TODO: use Screen.set()
            simple.DateRange.setOptions({ element: this.getElement({ name: "ContributionDateRange" }), from, to, hasToDate });
            simple.App.apply();
          }
        },
        // do it via simple.Screen.apply()
        DatesEditorApply: {
          execute: () => {
            const { from, to, frame } = simple.Date.coerceRange(simple.DateRange.getOptions({ element: this.getElement({ name: "DatesEditorDateRange" }) }));
            simple.Storage.setValue({ path: "r8.contribute", mutator: value => Object.assign(value, { from, to, frame }) });

            this.UpdateData();
            this.LoadState();

            simple.App.apply();
          }
        },
        // DO it via screen simple.Screen.apply() and then call apply
        ContributionApply: {
          execute: () => {
            debugger;

            const { object: contribution, valid, mode } = simple.Screen.get({
              element: this.getElement({ name: "Contribution" }),
              postprocess: ({ object, valid }) => {
                if (valid) {
                  return Object.assign(object, object.range); // TODO: change object to contain range
                }
              }
            });

            if (valid) {
              const { authenticate, run } = this.appContext.getController({ name: "App" }).export();

              const reget = () => this.UpdateData({ providers: [r8.ContributionsProvider] });
              const close = () => simple.App.apply;
              const action = r8.services.contributions[mode.toLowerCase()];

              authenticate({ allowGuestLogin: (mode === "Add") }).then(run({
                handle: () => action(contribution).then(reget).then(close),
                options: {
                  text: {
                    Add: "Adding Contribution...",
                    Update: "Updating Contribution...",
                    Delete: "Deleting Contribution..."
                  }[mode]
                }
              }));
            }
          }
        },
        Update: {
          execute: () => {
            const { state, request = this.GetState(), providers = [r8.QuotesProvider, r8.ContributionsProvider], force = false } = arguments || {};

            if (state) {
              request = this.SetState({ value: state });
            }

            if (request) {
              simple.Data.request({ element: this.getElement({ name: "Contribute" }), request, providers, force }).then(object => {

                simple.Screen.set({
                  element: this.getElement({ name: "Contribute" }),
                  object,
                  preprocess: ({ object }) => {
                    const { from, to } = object;
                    return Object.assign(object, { range: { from, to } });
                  }
                });
              });
            }

            /*
            
            UpdateData: {
                      execute: (parameters) => {
                        const { request, providers, force } = parameters || {};
                        const get = () => simple.Data.request({ element: this.getElement({ name: "Contribute" }), providers, request, force });
                        const set = ({ data, padding }) => {
                          // TODO: use Screen.set + custom handle, padding=>info
                          this.getElement({ name: "DataPadding" }).innerHTML = simple.Dom.evalTemplate({ name: "Contribute.DataPadding", context: padding });
            
                          // TODO: use Screen.set()
                          [
                            { name: r8.QuotesProvider.name, action: ({ data }) => simple.Chart.setData({ element: this.getElement({ name: "Chart" }), data }) },
                            { name: r8.ContributionsProvider.name, action: ({ data }) => simple.List.setItems({ element: this.getElement({ name: "Contributions" }), items: data }) },
                          ].forEach(({ name, action }) => action({ data: data[name] }));
            
                          Promise.resolve();
                        };
            
                        return get().then(set);
                      }
                    }
            
            */

            debugger;
          }
        }
      },
      routes: [
        {
          hash: "#contribute", default: true, fallBack: true,
          handle: () => this.Update().then(() => this.execute({ batch: { descriptors: ["Chart$Enter"] } }))
        },
        {
          hash: "#contribute/contributions", handle: () => {

            this.execute({ batch: { descriptors: ["Contributions$Enter"], transient: true } });
            return Promise.resolve();

            /*return this.UpdateData({ providers: [r8.ContributionsProvider], mode: "Force" }).then(() => {
              this.execute({ batch: { descriptors: ["Contributions$Enter"], transient: true } });
              return Promise.resolve();
            });*/
          }
        },
        {
          hash: "#contribute/contributions/discuss", handle: values => {
            debugger;

            // TODO: 
            return r8.services.contributions.get({ id: contributionId }).then(result => {
              const getDiscussionContextHtml = ({ contribution }) => simple.Dom.evalTemplate({
                name: {
                  Range: "Contribute.ContributionRangeExport",
                  Point: "Contribute.ContributionPointExport"
                }[`${contribution.type}`],
                context: { item: contribution }
              });

              // TODO: remove 
              this.process({ providers: [r8.PostsProvider], request: { externalId: contributionId }, force: true }).then(() => {

                this.getElement({ name: "DiscussionContext" }).innerHTML = getDiscussionContextHtml({ contribution: result[0] });
                this.execute({ batch: { descriptors: ["Discussion$Enter"], transient: true } });
              });

              return Promise.resolve();
            });
          }
        },
        {
          hash: "#contribute/contributions/create", handle: () => {
            this.execute({ batch: { states: [{ descriptor: "Contribution$Enter", value: { mode: "Add" } }] } });
            return Promise.resolve();
          }
        },
        {
          hash: "#contribute/contributions{id}/edit", handle: ({ values }) => {
            return r8.services.contributions.get({ id: contributionId }).then(result => {
              let contribution = result[0];
              const { from, to } = contribution;
              contribution = Object.assign(contribution, { range: { from, to } });

              this.execute({ batch: { states: [{ descriptor: "Contribution$Enter", value: { contribution, mode: "Update" } }] } });
              return Promise.resolve();
            });
          }
        },
        {
          hash: "#contribute/contributions/delete", handle: ({ values }) => {
            return r8.services.contributions.get({ id: contributionId }).then(result => {
              const contribution = result[0];
              this.execute({ batch: { states: [{ descriptor: "Contribution$Enter", value: { contribution, mode: "Delete" } }] } });
              return Promise.resolve();
            });
          }
        }
        // TODO: 
      ],
      name: "Contribute",
      appContext
    });
  }

  init() {
    super.init();
  }

  // in scope / out of scope
  create({ element }) {
    const placeholderElement = simple.Dom.getElement({ element, dataAttributeName: "data-app-view-placeholder" });
    const { content } = simple.Dom.setInnerHtml({ element: placeholderElement, name: this.name });
    return content;
  }

  on(message) {
    const { name, value } = message;
    debugger;
  }
};