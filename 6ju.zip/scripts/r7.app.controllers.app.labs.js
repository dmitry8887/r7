﻿r7.app.controllers.app.labs = new function (dependencies) {
    this.route = "app$app.labs";
    this.hash = "labs";

    this.header = "Labs";

    var cache = dependencies.cache;

    this.enter = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                $("#view").html(cache.view);
                console.log("entering labs...");
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };

    this.leave = function(context) {
        return new window.Promise(function(resolve, reject) {
            try {
                console.log("leaving labs...");
                resolve(context);
            } catch (error) {
                reject({ error: error });
            }
        });
    };
}({
    cache: {
        view: r7.lib.state.getCasheItem({ name: "app.views.labs" })
    }
});