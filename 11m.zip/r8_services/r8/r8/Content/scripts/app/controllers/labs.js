﻿"use strict";

r8.controllers.Labs = class extends simple.Controller {
  get properties() {
    return { route: "App$Labs", hash: "labs", view: () => "Labs", name: "Labs" };
  }

  constructor({ resolver }) {
    super({
      resolver,
      init: ({ appContainer }) => {
        appContainer.querySelector("#app_view_container").innerHTML = simple.Utils.getHtmlImportText({ name: "Labs" });
        return appContainer.querySelector("#labs");
      },
      elements: {},
      states: []
    });
  }

  enter() {
    if (!this.initialized) {
      this.init();
    }
  }

  leave() {
    this.initialized = false;
    super.detach();
  }
};